// Basic Node HTTP server for serving mock Collateral API
// No external dependencies (Express not required) to keep setup simple

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT ? Number(process.env.PORT) : 4300;
const MOCK_PATH = path.join(__dirname, 'mocks', 'collateral-list.json');
const RESP_PATH = path.join(__dirname, '..', 'mocks', 'json', 'resp-collateral-list.json');

function safeReadJson(filePath) {
  try {
    const file = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(file);
  } catch (err) {
    console.warn(`[mock] Failed to read ${filePath}:`, err.message);
    return null;
  }
}

function mapRespToCollateral(resp) {
  // resp expected shape: { value: [ { contract: { ... } } ] }
  const value = Array.isArray(resp?.value) ? resp.value : [];
  return value
    .map(v => v?.contract)
    .filter(Boolean)
    .map(c => ({
      id: Number(c.id ?? 0),
      contractKey: String(c.contractKey ?? c.timelineId ?? ''),
      type: String(c.type ?? ''),
      status: String(c.status ?? ''),
      createdDate: String(c.createdAt ?? ''),
      contractDate: String(c.contractDate ?? c.effectiveDate ?? ''),
      createdBy: String(c.createdBy ?? ''),
    }));
}

function unique(arr) {
  return Array.from(new Set(arr));
}

function synthesizeRows(baseRows, needed) {
  const result = [];
  const maxId = Math.max(0, ...baseRows.map(r => Number(r.id) || 0));
  const types = unique(baseRows.map(r => r.type).filter(Boolean));
  const statuses = unique(baseRows.map(r => r.status).filter(Boolean));
  const pick = list => list[Math.floor(Math.random() * list.length)] || '';

  for (let i = 0; i < needed; i++) {
    const id = maxId + i + 1;
    const created = new Date(Date.now() - i * 86400000);
    const trade = new Date(created.getTime() - 2 * 86400000);
    result.push({
      id,
      contractKey: `MOCK-${id}`,
      type: pick(types) || 'Orig',
      status: pick(statuses) || 'Pdct',
      createdDate: created.toISOString(),
      contractDate: trade.toISOString(),
      createdBy: 'MOCK.USER',
    });
  }
  return result;
}

function buildRows() {
  const fromMock = safeReadJson(MOCK_PATH);
  const mockRows = Array.isArray(fromMock) ? fromMock : [];

  // Priorizar o JSON estático se já tiver 60 ou mais itens
  if (mockRows.length >= 60) {
    return mockRows;
  }

  const fromResp = safeReadJson(RESP_PATH);
  const respRows = fromResp ? mapRespToCollateral(fromResp) : [];

  let combined = [...respRows, ...mockRows];
  if (combined.length < 60) {
    combined = [...combined, ...synthesizeRows(combined, 60 - combined.length)];
  }

  return combined;
}

let rows = buildRows();

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(payload));
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  if (req.method === 'GET' && parsedUrl.pathname === '/ticket') {
    // Basic filtering
    const q = parsedUrl.query || {};
    const toDate = v => (v ? new Date(v).getTime() : null);
    // Support legacy keys and new daterange arrays
    const toArray = v => (Array.isArray(v) ? v : v ? [v] : []);
    const [createdStartDate, createdEndDate] = toArray(q.createdDate);
    const [contractStartDate, contractEndDate] = toArray(q.contractDate);

    const createdStart = toDate(q.createdStartDate ?? createdStartDate);
    const createdEnd = toDate(q.createdEndDate ?? createdEndDate);
    const tradeStart = toDate(q.tradeStartDate ?? contractStartDate);
    const tradeEnd = toDate(q.tradeEndDate ?? contractEndDate);

    const filtered = rows.filter(r => {
      if (q.contractNumber && !String(r.contractKey).includes(String(q.contractNumber)))
        return false;
      if (q.contractKey && !String(r.contractKey).includes(String(q.contractKey))) return false;
      if (q.type && !String(r.type).toLowerCase().includes(String(q.type).toLowerCase()))
        return false;
      // Accept both 'operationStatus' and 'status' as arrays or single values
      const statuses = toArray(q.operationStatus).concat(toArray(q.status));
      if (statuses.length && !statuses.includes(String(r.status))) return false;
      if (
        q.createdBy &&
        !String(r.createdBy).toLowerCase().includes(String(q.createdBy).toLowerCase())
      )
        return false;

      const created = r.createdDate ? new Date(r.createdDate).getTime() : null;
      if (createdStart && (!created || created < createdStart)) return false;
      if (createdEnd && (!created || created > createdEnd)) return false;

      const traded = r.contractDate ? new Date(r.contractDate).getTime() : null;
      if (tradeStart && (!traded || traded < tradeStart)) return false;
      if (tradeEnd && (!traded || traded > tradeEnd)) return false;

      return true;
    });

    // Pagination
    const page = Number(q.page ?? 0);
    const limit = Number(q.limit ?? 10);
    const skip = Number(q.skip ?? page * limit);
    const paged = filtered.slice(skip, skip + limit);

    // Debug: log pagination meta
    try {
      console.info('[mock:/ticket] meta', {
        page,
        limit,
        skip,
        filtered: filtered.length,
        pageRows: paged.length,
      });
    } catch {}

    const response = {
      data: {
        rows: paged,
        skip,
        // Total deve refletir o número de registros elegíveis (sem paginação)
        // Para ambiente local, garantimos o total baseado no filtro aplicado.
        total: filtered.length,
      },
      errors: [],
      statusCode: 200,
    };
    return sendJson(res, 200, response);
  }

  // Health endpoint
  if (req.method === 'GET' && parsedUrl.pathname === '/health') {
    return sendJson(res, 200, { status: 'ok' });
  }

  // Not found
  sendJson(res, 404, { message: 'Not Found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[mock] Collateral API server running at http://localhost:${PORT}/`);
  console.log('[mock] Endpoints: GET /ticket?limit=10&page=0, GET /health');
});
