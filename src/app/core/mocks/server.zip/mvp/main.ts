import * as bootstrap from 'bootstrap';
// expõe no window para compatibilidade com código que usa window.bootstrap
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(window as any).bootstrap = bootstrap;

import { initFederation } from '@angular-architects/native-federation';

initFederation()
  // eslint-disable-next-line no-console
  .catch(err => console.error(err))
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  .then(_ => import('./bootstrap'))
  // eslint-disable-next-line no-console
  .catch(err => console.error(err));
