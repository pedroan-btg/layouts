import { RightOfPreferenceTranslationType } from '../en/right-of-preference.translation';

export const RightOfPreferenceTranslation: RightOfPreferenceTranslationType = {
  label: 'Direito de Preferência',
  pending: 'Pendente',
  product: 'Produto',
  rate: 'Taxa',
  limitDate: 'Data Limite',
  client: 'Cliente',
  clientIsOnboarded: 'Cliente está integrado',
  actions: 'Ações',
  clientName: 'Nome do Cliente',
  deleteWarning: 'Tem certeza de que deseja excluir este direito de preferência?',
  modal: {
    add: 'Adicionar Direito de Preferência',
    edit: 'Editar Direito de Preferência',
  },
  emptyList: 'Nenhum direito de preferência adicionado.',
};
