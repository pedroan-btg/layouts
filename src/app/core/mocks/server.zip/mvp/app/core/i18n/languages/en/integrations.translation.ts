export type IntegrationsTranslationType = typeof IntegrationsTranslations;

export const IntegrationsTranslations = {
  label: 'Integrations',
  dealRas: {
    label: 'DealRas',
  },
  hasCommitment: {
    label: 'Commitment',
  },
};
