import { CashflowTranslationType } from '../en/cashflow.translation';

export const CashflowTranslation: CashflowTranslationType = {
  label: 'Cashflow',
  pending: 'Pendente',
  installments: 'Parcelas',
  maturityType: {
    label: 'Tipo de vencimento',
    values: {
      INMS: 'Início do mês',
      FMMS: 'Fim do mês',
      AFTR: 'Próximo dia útil',
      BFOR: 'Dia útil anterior',
    },
  },
  paymentDay: {
    label: 'Dia',
  },
  startAccrual: {
    label: 'Start accrual',
  },
  calculationType: {
    label: 'Tipo de correção',
    values: {
      PRIC: 'PRICE',
      BAND: 'SAC',
    },
  },
  valorizationMethod: {
    label: 'Tipo de valorização',
    values: {
      INST: 'Fluxo Parcela',
      BAND: 'Saldo Devedor',
    },
  },
  accrualOnBusinessDay: 'Período de referência em dia útil',
  interest: 'Juros',
  interestFrequency: {
    label: 'Frequência',
  },
  interestGracePeriod: {
    label: 'Carência (Meses)',
  },
  interestRate: {
    label: 'Taxa',
  },
  incorporate: 'Incorporar',
  interestIndex: {
    label: 'Índice',
  },
  indexerRate: {
    label: '% Índice',
  },
  interestLag: {
    label: 'Lag',
  },
  round: {
    label: 'Round',
  },
  spreadType: {
    label: 'Capitalização',
    values: {
      ECMP: 'Exponencial',
      SIMP: 'Linear',
    },
  },
  spreadBase: {
    label: 'Base',
  },
  principal: 'Principal',
  amortizationFrequency: {
    label: 'Frequência',
  },
  amortizationGracePeriod: {
    label: 'Carência (Meses)',
  },
  import: 'Importar',
  generate: 'Gerar',
  table: {
    maturityDate: 'Data de vencimento',
    startDate: 'Data de início',
    endDate: 'Data de fim',
    amortization: 'Amortização',
    grv: 'VRG',
    indexer: 'Indexador',
    spreadRate: 'Taxa',
    spreadType: 'Tipo',
    spreadBase: 'Base',
    incorporate: 'Incorporar',
    amountDueAtMaturity: 'Valor no Vencimento ',
    interestAmount: 'Montante de juros',
    actions: {
      label: 'Ações',
      delete: 'Excluir',
      edit: 'Editar',
    },
    total: 'Total',
    summary: 'Resumo',
    totalAmortization: 'Total Amortização',
    totalIOF: 'Total IOF',
  },
  alert: {
    remove: 'Tem certeza de que deseja remover esta parcela?',
  },
  empty: 'Nenhum fluxo de caixa adicionado.',
  error: {
    firstPaymentDate: 'A data do primeiro pagamento deve ser posterior à data de início.',
    maturityDateIsBeforeStartDate: 'A data de vencimento deve ser posterior à data de início.',
    interestIndex: 'O índice de juros é obrigatório.',
    error: 'Por favor, preencha todos os campos obrigatórios corretamente.',
    maturityDate: 'A data de vencimento é obrigatória.',
    title: 'Erro de validação',
    invalidForm: 'Por favor, preencha todos os campos obrigatórios corretamente.',
  },
};
