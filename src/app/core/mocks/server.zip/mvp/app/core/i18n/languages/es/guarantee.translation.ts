import { GuaranteeTranslationType } from '../en/guarantee.translation';

export const GuaranteeTranslation: GuaranteeTranslationType = {
  label: 'Avalistas',
  pending: 'Pendiente',
  modal: {
    add: 'Agregar avalista',
    edit: 'Editar avalista',
  },
  instrument: 'Instrumento',
  guarantor: 'Garante',
  intervening: 'Interviniente',
  amount: 'Monto',
  obligationType: 'Tipo de obligación',
  coverType: 'Tipo de cobertura',
  actions: 'Acciones',
  deleteWarning: '¿Está seguro de que desea eliminar esta garantía?',
  rate: 'Tasa',
  value: 'Valor',
  empty: 'No hay avalistas agregados.',
  rateOrValue: 'Tasa o Valor',
};
