export type SearchCommitmentTranslationType = typeof SearchCommitmentTranslation | null;

export const SearchCommitmentTranslation = {
  label: 'Commitment',
  title: 'Pesquisar Commitment',
  searchButton: 'Pesquisar',
  form: {
    contractNumber: {
      label: 'Número do Contrato',
    },
    tradeId: {
      label: 'ID da Operação',
    },
    maturityDate: {
      label: 'Data de Vencimento',
    },
    undefinedPeriod: 'Período Indefinido',
    createdByMe: 'Criado por Mim',
  },
  commitment: {
    counterparty: 'Contraparte',
    cge: 'CGE',
    contractNumber: 'Número do Contrato',
    maturityDate: 'Data de Vencimento',
    currency: 'Moeda',
    amount: 'Valor',
    tradeId: 'ID da Operação',
  },
};
