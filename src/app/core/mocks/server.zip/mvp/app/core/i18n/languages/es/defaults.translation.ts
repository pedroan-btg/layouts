import { DefaultsTranslationType } from '../en/defaults.translation';

export const DefaultsTranslation: DefaultsTranslationType = {
  ok: 'Aceptar',
  cancel: 'Cancelar',
  close: 'Cerrar',
  save: 'Guardar',
  loading: 'Cargando',
  creating: 'Creando...',
  validating: 'Validando...',
  warning: 'Advertencia',
  serverError: {
    title: 'Error del servidor',
    message:
      'Ocurrió un error inesperado en el servidor. Por favor, inténtelo de nuevo más tarde. Si el problema persiste, contacte con el soporte.',
  },
  noRecords: 'Sin registros',
  yes: 'Sí',
  no: 'No',
  send: 'Enviar',
  edit: 'Editar',
  configured: 'Configurado',
  completed: 'Completado',
  pending: 'Pendiente',
  alertService: {
    errorTitle: 'Error',
    tryAgain: 'Por favor, inténtelo de nuevo más tarde.',
  },
  actions: 'Acciones',
  remove: 'Are you sure you would like to remove this item?',
};
