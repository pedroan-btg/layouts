export type CommonTranslationType = typeof CommonTranslation;

export const CommonTranslation = {
  cancel: 'Cancel',
  apply: 'Apply',
  delete: 'Delete',
  selected: 'Selected',
  select: 'Select',
};
