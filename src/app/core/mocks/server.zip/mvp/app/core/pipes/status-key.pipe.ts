import { Pipe, PipeTransform } from '@angular/core';
import { Status } from '../enums';

@Pipe({ name: 'statusKey', pure: true })
export class StatusKeyPipe implements PipeTransform {
  transform(status: Status | null): string | null {
    if (status == null) return null;

    const statusEnum = Status[status];

    if (typeof statusEnum !== 'string') return status.toString();

    return `enums.status.${statusEnum.charAt(0).toLowerCase() + statusEnum.slice(1)}`;
  }
}
