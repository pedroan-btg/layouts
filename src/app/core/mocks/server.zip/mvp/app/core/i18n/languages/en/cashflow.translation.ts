export type CashflowTranslationType = typeof CashflowTranslation;

export const CashflowTranslation = {
  label: 'Cashflow',
  pending: 'Pending',
  installments: 'Installments',
  maturityType: {
    label: 'Maturity type',
    values: {
      INMS: 'Initial Day',
      FMMS: 'End of Month',
      AFTR: 'Next Business Day',
      BFOR: 'Previous Business Day',
    },
  },
  paymentDay: {
    label: 'Day',
  },
  startAccrual: {
    label: 'Start accrual',
  },
  calculationType: {
    label: 'Correction type',
    values: {
      PRIC: 'PRICE',
      BAND: 'SAC',
    },
  },
  valorizationMethod: {
    label: 'Valuation type',
    values: {
      INST: 'Installment',
      BAND: 'BalanceDue',
    },
  },
  accrualOnBusinessDay: 'Reference period on business day',
  interest: 'Interest',
  interestFrequency: {
    label: 'Frequency',
  },
  interestGracePeriod: {
    label: 'Grace (Months)',
  },
  interestRate: {
    label: 'Rate',
  },
  incorporate: 'Incorporate',
  interestIndex: {
    label: 'Index',
  },
  indexerRate: {
    label: '% Index',
  },
  interestLag: {
    label: 'Lag',
  },
  round: {
    label: 'Round',
  },
  spreadType: {
    label: 'Capitalization',
    values: {
      ECMP: 'Exponencial',
      SIMP: 'Linear',
    },
  },
  spreadBase: {
    label: 'Base',
  },
  principal: 'Principal',
  amortizationFrequency: {
    label: 'Frequency',
  },
  amortizationGracePeriod: {
    label: 'Grace (Months)',
  },
  import: 'Import',
  generate: 'Generate',
  table: {
    maturityDate: 'Maturity date',
    startDate: 'Start date',
    endDate: 'End date',
    amortization: 'Amortization',
    grv: 'GRV',
    indexer: 'Index',
    spreadRate: 'Rate',
    spreadType: 'Type',
    spreadBase: 'Base',
    incorporate: 'Incorporate',
    amountDueAtMaturity: 'Amount due at maturity',
    interestAmount: 'Interest amount',
    actions: {
      label: 'Actions',
      delete: 'Delete',
      edit: 'Edit',
    },
    total: 'Total',
    summary: 'Summary',
    totalAmortization: 'Total Amortization',
    totalIOF: 'Total IOF',
  },
  alert: {
    remove: 'Are you sure you want to remove this installment?',
  },
  empty: 'No cashflow added.',
  error: {
    firstPaymentDate: 'The first payment date must be after the accrual start date.',
    maturityDateIsBeforeStartDate: 'The maturity date must be after the accrual start date.',
    interestIndex: 'Interest index is required.',
    error: 'Please fill in all required fields correctly.',
    maturityDate: 'Maturity date is required.',
    title: 'Validation Error',
    invalidForm: 'Please fill in all required fields correctly.',
  },
};
