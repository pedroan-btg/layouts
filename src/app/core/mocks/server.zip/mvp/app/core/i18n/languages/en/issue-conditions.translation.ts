export type IssueConditionsTranslationType = typeof IssueConditionsTranslation | null;

export const IssueConditionsTranslation = {
  label: 'Issue Conditions',
  pending: 'Pending',
  amount: {
    label: 'Amount',
  },
  grossNotional: {
    label: 'Gross Notional',
  },
  netNotional: {
    label: 'Net Notional',
  },
  tradeCurrency: {
    label: 'Currency',
  },
  disbursementCurrency: {
    label: ' Disbursement currency',
  },
  exchangeRate: {
    label: 'Exchange Rate',
  },
  calendars: {
    label: 'Calendars',
  },
  contractDate: {
    label: 'Contract Date',
  },
  letterOfCreditDate: {
    label: 'Letter of Credit Date',
  },
  tradeDate: {
    label: 'Trade Date',
  },
  maturityDate: {
    label: 'Maturity Date',
    info: 'You can enter shortcuts like 1y (1 year), 12m (12 months), or 365d (365 days) to automatically fill in the date',
  },
  disbursementDate: {
    label: 'Disbursement Date',
  },
  useOfProceeds: {
    label: 'Use of Proceeds',
  },
  isRollout: {
    label: 'Is Rollout',
  },
  swapFundingRate: {
    label: 'Swap Funding Rate',
  },
  isLiability: {
    label: 'Is Liability',
  },
  lastRolloutMaturityDate: {
    label: 'Last Rollout Maturity Date',
  },
  nextRolloutDate: {
    label: 'Next revolving Date',
  },
  exchangeRateLag: {
    label: 'Exchange rate lag',
  },
  impuestos: {
    label: 'Taxes',
  },
  hasStampTaxes: {
    label: 'Has stamp taxes?',
  },
  stampTaxesExchangeRate: {
    label: 'Exchange rate - CLP',
  },
  stampTaxes: {
    label: 'Stamp Taxes',
  },
  hasWithholdingTax: {
    label: 'Does it have?',
  },
  withholdingTax: {
    label: 'Withholding Tax',
  },
  fundingForm: {
    label: 'Funding',
  },
  funding: {
    label: 'Funding %',
  },
  iofFinanced: {
    label: 'IOF Financed',
    value: 'IOF Value:',
    toCalculate: '*Value calculated after generating flow',
    info: 'It will be calculated by the simulator',
  },
  iofType: {
    label: 'IOF Type',
    values: {
      PAIDCOLLECTED: 'Paid Collected',
      DUE: 'Due',
      EXEMPT: 'Exempt',
      PAIDNOTCOLLECTED: 'Paid Not Collected',
      undefined: 'N/A',
      null: 'null',
    },
  },
  alert: {
    errorLoadHolidays: 'Error loading holidays',
  },
};
