export type DefaultsTranslationType = typeof DefaultsTranslation | null;

export const DefaultsTranslation = {
  ok: 'Ok',
  cancel: 'Cancelar',
  close: 'Fechar',
  save: 'Salvar',
  loading: 'Carregando',
  creating: 'Criando...',
  validating: 'Validando...',
  warning: 'Aviso',
  serverError: {
    title: 'Erro no servidor',
    message:
      'Ocorreu um erro inesperado no servidor. Por favor, tente novamente mais tarde. Se o problema persistir, entre em contato com o suporte.',
  },
  noRecords: 'Sem registros',
  yes: 'Sim',
  no: 'Não',
  send: 'Enviar',
  edit: 'Editar',
  configured: 'Configurado',
  completed: 'Concluído',
  pending: 'Pendente',
  alertService: {
    errorTitle: 'Erro',
    tryAgain: 'Por favor, tente novamente mais tarde.',
  },
  actions: 'Ações',
  remove: 'Tem certeza de que deseja remover este item?',
};
