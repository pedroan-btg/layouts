import { LoanTranslationType } from '../en';
import { IssueConditionsTranslation } from '../en/issue-conditions.translation';
import { CashflowTranslation } from './cashflow.translation';
import { DisbursementTranslation } from './disbursement.translation';
import { FeeTranslation } from './fee.translation';
import { GuaranteeTranslation } from './guarantee.translation';
import { HomeTranslation } from './home.translation';
import { IntegrationsTranslations } from './integrations.translation';
import { OverdueChargesTranslation } from './overdue-charges.translation';
import { ProvisionTranslation } from './provision.translation';
import { RightOfPreferenceTranslation } from './right-of-preference.translation';
import { ValidationsTranslation } from './validations.translation';

export const LoanTranslation: LoanTranslationType = {
  home: HomeTranslation,
  basicInformation: 'Información básica',
  conditions: 'Condiciones',
  additional: 'Información adicional',
  review: {
    title: 'Revisión',
    subtitle: 'Revisión y corrección de los datos ingresados en los pasos anteriores.',
    provision: {
      title: 'Provisión para pérdidas',
      status: {
        pending: 'Configuración pendiente',
        configured: 'Configurado',
      },
      empty: {
        title: 'Provisión no configurada',
        subtitle: 'Configure la provisión para pérdidas de esta operación',
      },
    },
  },
  ticketActions: {
    orig: 'Nueva operación',
    editOrig: 'Editar trade',
    adtv: 'Aditar operación',
    editAdtv: 'Editar trade',
    copy: 'Copiar como nueva operación',
    amend: 'Corrección de operación',
    editAmend: 'Editar Corrección de operación',
  },
  tradeForm: {
    mode: {
      stepper: 'Formulario por Etapas',
      unified: 'Formulario Unificado',
    },
    actions: {
      submit: 'Guardar',
      validate: 'Validar',
      back: 'Volver',
    },
    successCreated: 'Trade creado con éxito.',
    failedToCreate: 'Error al crear el trade.',
    integrations: IntegrationsTranslations,
    issueConditions: IssueConditionsTranslation,
    fee: FeeTranslation,
    overdueCharges: OverdueChargesTranslation,
    disbursement: DisbursementTranslation,
    provision: ProvisionTranslation,
    guarantee: GuaranteeTranslation,
    cashflow: CashflowTranslation,
    rightOfPreference: RightOfPreferenceTranslation,
  },
  validations: {
    issueConditionsDto: {
      tradeDate: {
        differentFromCashflowGeneratorStartDate:
          'La fecha de la operación es diferente de la fecha de inicio del generador de flujo de caja',
      },
      maturityDate: {
        empty: 'La fecha de vencimiento es obligatoria',
      },
    },
  },
  validationErrorsModal: ValidationsTranslation,
  view: {
    contractNumber: 'Contrato',
    tradeType: 'Tipo',
    section: {
      overview: 'Resumen',
    },
  },
};
