export type DisbursementTranslationType = typeof DisbursementTranslation | null;

export const DisbursementTranslation = {
  label: 'Desembolsos',
  pending: 'Pendente',
  amount: 'Valor',
  disbursementDate: {
    label: 'Data de desembolso',
  },
  maxAvailable: 'Máximo disponível',
  internalAccountIntermediation: 'Intermediação de conta interna',
  actions: 'Ações',
  deleteWarning: 'Tem certeza de que deseja excluir este desembolso?',
  types: {
    internal: 'Interno',
    external: 'Externo',
    ssis: 'SSIS',
  },
  errors: {
    maxValue: 'O valor não pode exceder {{max}}',
  },
  hasDisbursement: 'A creditar',
  remainingValue: 'Valor restante',
  client: 'Cliente',
  type: 'Tipo',
  bank: 'Banco',
  account: 'Conta',
  accountDigit: 'Dígito',
  agency: {
    label: 'Agência',
    info: 'Agência sem dígito',
  },
  modal: {
    add: 'Adicionar desembolso',
    edit: 'Editar desembolso',
  },
  addForm: 'Adicionar desembolso',
  empty: 'Sem desembolso cadastrado',
  errorNegativeRemaining: 'O valor restante para desembolso não pode ser negativo.',
};
