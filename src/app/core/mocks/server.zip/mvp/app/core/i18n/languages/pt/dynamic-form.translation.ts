export const DynamicFormTranslation = {
  form: {
    errors: {
      required: 'Este campo é obrigatório.',
      min: 'O valor deve ser maior ou igual a {{ min }}.',
      max: 'O valor deve ser menor ou igual a {{ max }}.',
      minLength: 'Mínimo de caracteres: {{ requiredLength }}.',
      maxLength: 'Máximo de caracteres: {{ requiredLength }}.',
      pattern: 'Formato inválido.',
      integerOnly: 'Somente números inteiros.',
      decimalPlaces: 'Número de casas decimais inválido.',
      notPast: 'A data não pode estar no passado.',
      notFuture: 'A data não pode estar no futuro.',
      maxDiffMonths: 'A diferença de meses excede o limite permitido.',
      multiSelectLimit: 'Selecione no máximo {{ limit }} itens.',
      invalid: 'Valor inválido.',
    },
  },
};
