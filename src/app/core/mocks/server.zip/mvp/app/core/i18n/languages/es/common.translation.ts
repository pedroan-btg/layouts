import type { CommonTranslationType as CommonTranslationTypeEn } from '../en/common.translation';

export type CommonTranslationType = CommonTranslationTypeEn | null;

export const CommonTranslation: CommonTranslationTypeEn = {
  cancel: 'Cancelar',
  apply: 'Aplicar',
  delete: 'Eliminar',
  selected: 'Seleccionado',
  select: 'Seleccionar',
};
