export type CollateralListTranslationType = typeof CollateralListTranslation;

export const CollateralListTranslation = {
  actions: {
    filter: 'Filters',
    add: 'New collateral',
  },
  filter: {
    contractNumber: 'Contract number',
    contractKey: 'Contract key',
    id: 'ID',
    type: 'Type',
    status: 'Status',
    createdBy: 'Created by',
    contractDate: 'Contract date',
    createdDate: 'Created date',
    resetButton: 'Clear filters',
    applyButton: 'Apply filters',
  },
  table: {
    id: 'ID',
    contractNumber: 'Contract number',
    type: 'Type',
    status: 'Status',
    createDateTime: 'Create date',
    tradeDate: 'Contract date',
    createLogin: 'Created by',
  },
};
