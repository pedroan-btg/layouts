import { ApiTranslationType } from '../en';

export const ApiTranslation: ApiTranslationType = {
  errors: {
    clientError: {
      title: 'Error de Solicitud',
      message:
        'Algunos de los datos enviados son incorrectos. Por favor, revise los campos y vuelva a intentarlo.',
    },
    unauthorized: {
      title: 'Sesión Expirada',
      message: 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente para continuar.',
    },
    forbidden: {
      title: 'Acceso Denegado',
      message: 'No tienes permiso para acceder a esta página o recurso.',
    },
    notFound: {
      title: 'Página No Encontrada',
      message: 'El recurso que estás intentando acceder no existe o ha sido eliminado.',
    },
    serverError: {
      title: 'Error en el Servidor',
      message:
        'Ocurrió un error inesperado en el servidor. Por favor, intenta nuevamente más tarde. Si el problema persiste, contacta con soporte.',
      confirmButton: 'OK',
    },
    serviceUnavailable: {
      title: 'Servicio No Disponible',
      message:
        'Actualmente estamos experimentando problemas temporales. El servicio estará disponible en breve. Por favor, intenta nuevamente más tarde.',
      confirmButton: 'OK',
    },
    timeout: {
      title: 'Tiempo de Solicitud Agotado',
      message: 'La solicitud tardó demasiado en procesarse. Por favor, intenta nuevamente.',
      confirmButton: 'OK',
    },
    pageExpired: {
      title: 'Sesión Expirada',
      message: 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente para continuar.',
      confirmButton: 'OK',
    },
    tooManyRequests: {
      title: 'Demasiadas Solicitudes',
      message:
        'Has realizado demasiadas solicitudes en un corto período de tiempo. Por favor, espera unos minutos e intenta nuevamente.',
      confirmButton: 'OK',
    },
    genericError: {
      title: 'Error Desconocido',
      message: 'Ocurrió un error inesperado. Por favor, intenta nuevamente más tarde.',
    },
  },
};
