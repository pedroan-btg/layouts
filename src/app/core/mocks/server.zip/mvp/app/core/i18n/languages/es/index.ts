export { es } from './es.translation';
