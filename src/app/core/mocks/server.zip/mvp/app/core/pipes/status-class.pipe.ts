import { Pipe, PipeTransform } from '@angular/core';
import { Status } from '../enums';

@Pipe({ name: 'statusClass', pure: true })
export class StatusClassPipe implements PipeTransform {
  transform(status: Status): string {
    const statusMap: Record<Status, string> = {
      [Status.Draft]: 'badge-dark',
      [Status.PendingInformation]: 'badge-light',
      [Status.PendingApproval]: 'badge-light-warning',
      [Status.Exporting]: 'badge-light-info',
      [Status.Exported]: 'badge-light-success',
      [Status.Canceled]: 'badge-light-danger',
      [Status.PendingInstrument]: 'badge-light',
      [Status.PendingGuaranteeBlock]: 'badge-light',
      [Status.FailedGuarantee]: 'badge-light',
      [Status.PendingGuaranteeCreate]: 'badge-light',
      [Status.PendingBackOfficeInput]: 'badge-light',
      [Status.CreditEngineValidation]: 'badge-light',
      [Status.SentToRegister]: 'badge-light',
      [Status.PendingApprovalRegister]: 'badge-light',
      [Status.Registered]: 'badge-light',
      [Status.Approved]: 'badge-light',
      [Status.OnSettlement]: 'badge-light',
    };

    return statusMap[status] || 'badge-light';
  }
}
