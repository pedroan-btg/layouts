import { RightOfPreferenceTranslationType } from '../en/right-of-preference.translation';

export const RightOfPreferenceTranslation: RightOfPreferenceTranslationType = {
  label: 'Derecho de Preferencia',
  pending: 'Pendiente',
  product: 'Producto',
  rate: 'Tasa',
  limitDate: 'Fecha Límite',
  client: 'Cliente',
  clientIsOnboarded: 'Cliente está integrado',
  actions: 'Acciones',
  clientName: 'Nombre del Cliente',
  deleteWarning: '¿Está seguro de que desea eliminar este derecho de preferencia?',
  modal: {
    add: 'Agregar Derecho de Preferencia',
    edit: 'Editar Derecho de Preferencia',
  },
  emptyList: 'No se han agregado derechos de preferencia.',
};
