import { PnlTranslationType } from '../en/pnl.translation';

export const PnlTranslation: PnlTranslationType = {
  book: {
    label: 'Book',
  },
  strategy: {
    label: 'Strategy',
  },
  errors: {
    searchBook:
      'Sorry, looks like there are some errors detected when searching books, please try again.',
    searchStrategy:
      'Sorry, looks like there are some errors detected when searching strategies, please try again.',
    forbidden: 'No tiene permiso para realizar esta acción.',
  },
};
