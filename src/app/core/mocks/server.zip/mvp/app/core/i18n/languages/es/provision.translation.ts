import { ProvisionTranslationType } from '../en/provision.translation';

export const ProvisionTranslation: ProvisionTranslationType = {
  label: 'Provisión de pérdidas',
  pending: 'Pendiente',
  reset: 'Restablecer información',
  portfolioClassification: 'Clasificación de cartera',
  ratingCounterparty: 'Calificación de contraparte',
  kead: 'kEAD',
  pd: 'PD',
  lgd: 'LGD',
  pe: 'PE',
  stage: 'Etapa',
  incurredLoss: 'Pérdida incurrida',
  import: {
    label: 'Importar PDF',
    loading: 'Importando...',
    title: '¿Usar datos encontrados?',
    error: 'Parece que ocurrió un error al importar datos, revise su archivo e intente nuevamente',
  },
  buildError: 'Parece que ocurrió un error, intente nuevamente más tarde',
  type: {
    label: 'Tipo',
    drt: 'Reestructuración de Débito',
    drn: 'Renegociación de Débito',
    ncr: 'Nuevo crédito',
    nc: 'NC',
  },
};
