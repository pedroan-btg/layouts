import { ApiTranslation, ApiTranslationType } from './api.translation';
import { CommonDomainTranslation, CommonDomainTranslationType } from './common-domain.translation';
import { DefaultsTranslation, DefaultsTranslationType } from './defaults.translation';
import { EnumsTranslation, EnumsTranslationType } from './enums.translation';
import { FeeTranslation, FeeTranslationType } from './fee.translation';
import { IntegrationsTranslations, IntegrationsTranslationType } from './integrations.translation';
import { LoanTranslation, LoanTranslationType } from './loan.translation';
import { PnlTranslation, PnlTranslationType } from './pnl.translation';
import { CommonTranslation, CommonTranslationType } from './common.translation';
import {
  SearchCommitmentTranslation,
  SearchCommitmentTranslationType,
} from './search-commitment.translation';
import {
  TradeInformationsTranslation,
  TradeInformationsTranslationType,
} from './trade-informations.translation';
import {
  CollateralListTranslation,
  CollateralListTranslationType,
} from './collateral-list.translation';
import {
  CollateralBasicTranslation,
  CollateralBasicTranslationType,
} from './collateral-basic.translation';
import {
  CollateralStepsTranslation,
  CollateralStepsTranslationType,
} from './collateral-steps.translation';

export interface TranslationType {
  language: string;
  api: ApiTranslationType;
  loan: LoanTranslationType;
  enums: EnumsTranslationType;
  searchCommitment: SearchCommitmentTranslationType;
  integrations: IntegrationsTranslationType;
  defaults: DefaultsTranslationType;
  pnl: PnlTranslationType;
  commonDomain: CommonDomainTranslationType;
  fee: FeeTranslationType;
  tradeInformationLoanBr: TradeInformationsTranslationType;
  common: CommonTranslationType;
  collateral: {
    list: CollateralListTranslationType;
    basic: CollateralBasicTranslationType;
    steps: CollateralStepsTranslationType;
  };
}

export const en: TranslationType = {
  language: 'English',
  api: ApiTranslation,
  loan: LoanTranslation,
  enums: EnumsTranslation,
  searchCommitment: SearchCommitmentTranslation,
  integrations: IntegrationsTranslations,
  defaults: DefaultsTranslation,
  pnl: PnlTranslation,
  commonDomain: CommonDomainTranslation,
  fee: FeeTranslation,
  tradeInformationLoanBr: TradeInformationsTranslation,
  common: CommonTranslation,
  collateral: {
    list: CollateralListTranslation,
    basic: CollateralBasicTranslation,
    steps: CollateralStepsTranslation,
  },
};
