import { OverdueChargesTranslationType } from '../en/overdue-charges.translation';

export const OverdueChargesTranslation: OverdueChargesTranslationType = {
  label: 'Cargos por mora',
  pending: 'Pendiente',
  interestArrears: {
    label: 'Intereses',
    rate: 'Tasa',
    base: 'Base',
  },
  penaltyFee: {
    label: 'Multa moratoria',
    rate: 'Tasa',
    lateInterest: 'Mora',
    onExecutive: 'Mora sobre ejecutivo',
  },
  latePaymentInterest: {
    label: 'Intereses compensatorios',
    index: 'Índice',
    indexPercentage: 'Índice %',
    rate: 'Tasa',
    capitalization: 'Capitalización',
    base: 'Base',
    correction: 'Corrección',
    frequency: 'Frecuencia',
    anniversary: 'Aniversario',
    lag: 'Desfase',
    enable: 'Habilitar formulario',
  },
  isLatePaymentEqualToRemuneration: {
    label: 'Igual a la tasa de remuneración',
  },
  alert: {
    loading: 'Cargando...',
    errorLoad: 'Lo sentimos, parece que se detectaron algunos errores, intente nuevamente.',
    errorLoadButton: '¡Está bien, entendido!',
    updateDelayChargesInterestRate:
      '¿Definir Intereses de Pago Tardío igual a Tasa de Remuneración?',
  },
};
