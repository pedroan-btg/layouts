export type FTSTranslationType = typeof FTSTranslation | null;

export const FTSTranslation = {
  loan: {
    home: {
      table: {
        contractKey: 'Key',
        type: 'Type',
        status: 'Status',
        createdAt: 'Created At',
        contractDate: 'Contract Date',
        createdBy: 'Created By',
      },
    },
  },
  commitment: {},
};
