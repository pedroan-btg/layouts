import { EnvironmentProviders, Provider } from '@angular/core';

import { Log } from 'fts-frontui/logs';
import { ENV_CONFIG } from 'fts-frontui/env';
import { provideI18n } from './i18n';
import { environment } from '@fts-collateral/environment';
import { provideHttpClientWithDateInterceptor } from 'fts-frontui/utils';

const appConfigProvider: (Provider | EnvironmentProviders)[] = [
  { provide: ENV_CONFIG, useValue: environment },
  { provide: Log },
  ...provideI18n(),
  provideHttpClientWithDateInterceptor(),
];

export const provideApp = (): (Provider | EnvironmentProviders)[] => appConfigProvider;
