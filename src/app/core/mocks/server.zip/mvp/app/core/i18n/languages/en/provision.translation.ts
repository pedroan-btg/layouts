export type ProvisionTranslationType = typeof ProvisionTranslation;

export const ProvisionTranslation = {
  label: 'Provision of losses',
  pending: 'Pending',
  reset: 'Reset info',
  portfolioClassification: 'Portfolio classification',
  ratingCounterparty: 'Rating counterparty',
  kead: 'kEAD',
  pd: 'PD',
  lgd: 'LGD',
  pe: 'PE',
  stage: 'Stage',
  incurredLoss: 'Incurred loss',
  import: {
    label: 'Import PDF',
    loading: 'Importing...',
    title: 'Use data found?',
    error: 'Looks like an error occurred to import data, please check your file and try again',
  },
  buildError: 'Looks like an error occurred, please try again later',
  type: {
    label: 'Type',
    drt: 'Debit Restructuring',
    drn: 'Debit Renegotiation',
    ncr: 'New credit',
    nc: 'NC',
  },
};
