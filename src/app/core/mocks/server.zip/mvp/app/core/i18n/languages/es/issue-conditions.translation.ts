import { IssueConditionsTranslationType } from '../en/issue-conditions.translation';

export const IssueConditionsTranslation: IssueConditionsTranslationType = {
  label: 'Condiciones de Emisión',
  pending: 'Pendiente',
  amount: {
    label: 'Monto',
  },
  grossNotional: {
    label: 'Nocional Bruto',
  },
  netNotional: {
    label: 'Nocional Neto',
  },
  tradeCurrency: {
    label: 'Moneda de la Operación',
  },
  disbursementCurrency: {
    label: 'Moneda de Desembolso',
  },
  exchangeRate: {
    label: 'Tipo de Cambio',
  },
  calendars: {
    label: 'Calendarios',
  },
  contractDate: {
    label: 'Fecha de Contrato',
  },
  letterOfCreditDate: {
    label: 'Fecha de Carta de Crédito',
  },
  tradeDate: {
    label: 'Fecha de Operación',
  },
  maturityDate: {
    label: 'Fecha de Vencimiento',
    info: 'Puede ingresar atajos como 1y (1 año), 12m (12 meses) o 365d (365 días) para completar automáticamente la fecha.',
  },
  disbursementDate: {
    label: 'Fecha de Desembolso',
  },
  useOfProceeds: {
    label: 'Destino de los Fondos',
  },
  isRollout: {
    label: 'Es Renovación',
  },
  swapFundingRate: {
    label: 'Tasa de Financiamiento del Swap',
  },
  isLiability: {
    label: 'Es Pasivo',
  },
  lastRolloutMaturityDate: {
    label: 'Última Fecha de Vencimiento de Renovación',
  },
  nextRolloutDate: {
    label: 'Próxima Fecha de Renovación',
  },
  exchangeRateLag: {
    label: 'Cambio lag',
  },
  impuestos: {
    label: 'Impuestos',
  },
  hasStampTaxes: {
    label: 'Tiene timbres y estampillas?',
  },
  stampTaxesExchangeRate: {
    label: 'Cambio - CLP',
  },
  stampTaxes: {
    label: 'Timbres y estampillas',
  },
  hasWithholdingTax: {
    label: 'Tiene With holding Tax?',
  },
  withholdingTax: {
    label: 'Withholding Tax',
  },
  fundingForm: {
    label: 'Costo de fondo',
  },
  funding: {
    label: 'Funding %',
  },
  iofFinanced: {
    label: 'IOF Financed',
    value: 'IOF Value:',
    toCalculate: '* Value calculated after generating flow',
    info: 'Será calculado por el simulador.',
  },
  iofType: {
    label: 'IOF Type',
    values: {
      PAIDCOLLECTED: 'Pagado y Recaudado',
      DUE: 'Vencido',
      EXEMPT: 'Exento',
      PAIDNOTCOLLECTED: 'Pagado y No Recaudado',
      undefined: 'N/A',
      null: 'null',
    },
  },
  alert: {
    errorLoadHolidays: 'Error al cargar los días festivos',
  },
};
