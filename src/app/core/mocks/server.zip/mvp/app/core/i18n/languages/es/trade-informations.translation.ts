import { TradeInformationsTranslationType } from '../en/trade-informations.translation';

export const TradeInformationsTranslation: TradeInformationsTranslationType = {
  label: 'Información de la Operación',
  pending: 'Pendiente',
  searchCommitment: {
    label: 'Compromiso',
  },
  aggregateGuarantees: {
    label: 'Garantías Consolidadas',
  },
  dealRas: {
    label: 'Acuerdo RAS',
  },
  product: {
    label: 'Producto',
  },
  contractNumber: {
    label: 'Número de Contrato',
  },
  party: {
    label: 'Parte',
  },
  partyAccount: {
    label: 'Cuenta',
  },
  counterparty: {
    label: 'Contraparte',
  },
  counterpartyAccount: {
    label: 'Cuenta',
  },
  counterpartyTaxId: {
    label: 'ID Fiscal de la Contraparte',
  },
  taxLocationCity: {
    label: 'Ciudad de Localización Fiscal',
  },
  agent: {
    label: 'Agente administrativo',
  },
  isMigration: {
    label: 'Carga masiva',
  },
  type: {
    label: 'Productos',
  },
  alert: {
    errorGetAccount: 'Error al cargar las cuentas de la contraparte',
  },
};
