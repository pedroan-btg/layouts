import { DisbursementTranslationType } from '../en/disbursement.translation';

export const DisbursementTranslation: DisbursementTranslationType = {
  label: 'Desembolsos',
  pending: 'Pendiente',
  amount: 'Monto',
  disbursementDate: {
    label: 'Fecha de desembolso',
  },
  maxAvailable: 'Máximo disponible',
  internalAccountIntermediation: 'Intermediación de cuenta interna',
  actions: 'Acciones',
  deleteWarning: '¿Está seguro de que desea eliminar este desembolso?',
  types: {
    internal: 'Interno',
    external: 'Externo',
    ssis: 'SSIS',
  },
  errors: {
    maxValue: 'El valor no puede exceder {{max}}',
  },
  hasDisbursement: 'A acreditar',
  remainingValue: 'Valor restante',
  client: 'Cliente',
  type: 'Tipo',
  bank: 'Banco',
  account: 'Cuenta',
  accountDigit: 'Dígito',
  agency: {
    label: 'Agencia',
    info: 'Agencia sin dígito',
  },
  modal: {
    add: 'Agregar desembolso',
    edit: 'Editar desembolso',
  },
  addForm: 'Agregar desembolso',
  empty: 'Sin desembolso registrado',
  errorNegativeRemaining: 'El valor restante para desembolso no puede ser negativo.',
};
