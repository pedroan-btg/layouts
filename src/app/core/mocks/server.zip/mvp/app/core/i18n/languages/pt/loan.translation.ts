import { CashflowTranslation } from './cashflow.translation';
import { DisbursementTranslation } from './disbursement.translation';
import { FeeTranslation } from './fee.translation';
import { GuaranteeTranslation } from './guarantee.translation';
import { HomeTranslation } from './home.translation';
import { IntegrationsTranslations } from './integrations.translation';
import { IssueConditionsTranslation } from './issue-conditions.translation';
import { OverdueChargesTranslation } from './overdue-charges.translation';
import { ProvisionTranslation } from './provision.translation';
import { RightOfPreferenceTranslation } from './right-of-preference.translation';
import { ValidationsTranslation } from './validations.translation';

export type LoanTranslationType = typeof LoanTranslation | null;

export const LoanTranslation = {
  home: HomeTranslation,
  basicInformation: 'Informações básicas',
  conditions: 'Condições',
  additional: 'Informações adicionais',
  review: {
    title: 'Revisão',
    subtitle: 'Revisão e correção dos dados inputados nas etapas anteriores.',
    edit: 'Editar',
    disbursement: {
      title: 'Desembolso',
      status: {
        noDisbursement: 'Sem desembolso',
        pending: 'Pendente configuração',
        configured: 'Configurado',
      },
      totalDisbursements: 'Total de desembolsos',
      empty: {
        noDisbursement: 'Esta operação não possui desembolso',
        pending: 'Nenhum desembolso configurado ainda',
      },
    },
    overdueCharges: {
      title: 'Encargos de Mora',
      status: {
        pending: 'Pendente configuração',
        configured: 'Configurado',
      },
      noLatePaymentInterest: 'Sem juros de mora configurados',
      empty: {
        title: 'Encargos de mora não configurados',
        subtitle: 'Configure os encargos para operações em atraso',
      },
    },
    provision: {
      title: 'Provisão de perdas',
      status: {
        pending: 'Pendente configuração',
        configured: 'Configurado',
      },
      empty: {
        title: 'Provisão não configurada',
        subtitle: 'Configure a provisão de perdas para esta operação',
      },
    },
  },
  ticketActions: {
    orig: 'Nova operação',
    editOrig: 'Editar operação',
    adtv: 'Operação aditiva',
    editAdtv: 'Editar operação',
    copy: 'Copiar como nova operação',
    amend: 'Reparar operação',
    editAmend: 'Editar operação de reparo',
  },
  tradeForm: {
    mode: {
      stepper: 'Formulário em Etapas',
      unified: 'Formulário Unificado',
    },
    actions: {
      submit: 'Salvar',
      validate: 'Validar',
      back: 'Voltar',
    },
    successCreated: 'Trade criado com sucesso.',
    failedToCreate: 'Erro ao criar o trade.',
    integrations: IntegrationsTranslations,
    issueConditions: IssueConditionsTranslation,
    fee: FeeTranslation,
    overdueCharges: OverdueChargesTranslation,
    disbursement: DisbursementTranslation,
    provision: ProvisionTranslation,
    guarantee: GuaranteeTranslation,
    cashflow: CashflowTranslation,
    rightOfPreference: RightOfPreferenceTranslation,
  },
  validations: {
    issueConditionsDto: {
      tradeDate: {
        differentFromCashflowGeneratorStartDate:
          'A data da operação é diferente da data de início do gerador de fluxo de caixa',
      },
      maturityDate: {
        empty: 'A data de vencimento é obrigatória',
      },
    },
  },
  validationErrorsModal: ValidationsTranslation,
  view: {
    contractNumber: 'Contrato',
    tradeType: 'Tipo',
    section: {
      overview: 'Visão Geral',
    },
  },
};
