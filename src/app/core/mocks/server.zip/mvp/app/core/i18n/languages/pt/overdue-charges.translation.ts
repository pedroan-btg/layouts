export type OverdueChargesTranslationType = typeof OverdueChargesTranslation | null;

export const OverdueChargesTranslation = {
  label: 'Encargos de atraso',
  pending: 'Pendente',
  interestArrears: {
    label: 'Juros',
    rate: 'Taxa',
    base: 'Base',
  },
  penaltyFee: {
    label: 'Multa moratória',
    rate: 'Taxa',
    lateInterest: 'Mora',
    onExecutive: 'Mora sobre executivo',
  },
  latePaymentInterest: {
    label: 'Juros compensatórios',
    index: 'Índice',
    indexPercentage: 'Índice %',
    rate: 'Taxa',
    capitalization: 'Capitalização',
    base: 'Base',
    correction: 'Correção',
    frequency: 'Frequência',
    anniversary: 'Aniversário',
    lag: 'Lag',
    enable: 'Habilitar formulário',
  },
  isLatePaymentEqualToRemuneration: {
    label: 'Igual à taxa de remuneração',
  },
  alert: {
    loading: 'Carregando...',
    errorLoad: 'Desculpe, parece que alguns erros foram detectados, tente novamente.',
    errorLoadButton: 'Ok, entendi!',
    updateDelayChargesInterestRate:
      'Definir Juros de Pagamento em Atraso igual à Taxa de Remuneração?',
  },
};
