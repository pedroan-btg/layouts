import { Injectable } from '@angular/core';

import { I18nLanguages, Translation } from 'fts-frontui/i18n';
import { en } from './languages/en';
import { es } from './languages/es';
import { pt } from './languages/pt';
import {
  DynamicFormEnFields,
  DynamicFormEnValidations,
  DynamicFormEsFields,
  DynamicFormEsValidations,
  DynamicFormPtFields,
  DynamicFormPtValidations,
} from '../../dynamic-form/translations';

@Injectable({
  providedIn: 'root',
})
export class Languages extends I18nLanguages {
  override availableLanguages(): { language: string; translate: Translation }[] {
    const mergeDynamicForm = (base: any, fields: any, validations: any): any => ({
      ...base,
      form: {
        ...(base.form ?? {}),
        errors: { ...(base.form?.errors ?? {}), ...(validations.form?.errors ?? {}) },
        fields: { ...(base.form?.fields ?? {}), ...(fields.form?.fields ?? {}) },
      },
    });

    const languages = [
      {
        language: 'es',
        translate: mergeDynamicForm(
          es,
          DynamicFormEsFields,
          DynamicFormEsValidations,
        ) as unknown as Translation,
      },
      {
        language: 'pt',
        translate: mergeDynamicForm(
          pt,
          DynamicFormPtFields,
          DynamicFormPtValidations,
        ) as unknown as Translation,
      },
      {
        language: 'en',
        translate: mergeDynamicForm(
          en,
          DynamicFormEnFields,
          DynamicFormEnValidations,
        ) as unknown as Translation,
      },
    ];

    return languages;
  }
}
