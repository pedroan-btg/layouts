import { FTSTranslationType } from '../en';

export const FTSTranslation: FTSTranslationType = null;
