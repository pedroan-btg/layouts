export type PnlTranslationType = typeof PnlTranslation | null;

export const PnlTranslation = {
  book: {
    label: 'Book',
  },
  strategy: {
    label: 'Strategy',
  },
  errors: {
    searchBook:
      'Desculpe, parece que ocorreram alguns erros ao buscar os books. Por favor, tente novamente.',
    searchStrategy:
      'Desculpe, parece que ocorreram alguns erros ao buscar as estratégias. Por favor, tente novamente.',
    forbidden: 'Você não tem permissão em books para realizar esta ação.',
  },
};
