export type CollateralStepsTranslationType = typeof CollateralStepsTranslation;

export const CollateralStepsTranslation = {
  actions: {
    cancel: 'Cancel',
    back: 'Back',
    next: 'Next',
  },
};
