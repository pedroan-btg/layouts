import type { CollateralListTranslationType as CollateralListTranslationTypeEn } from '../en/collateral-list.translation';

export type CollateralListTranslationType = CollateralListTranslationTypeEn | null;

export const CollateralListTranslation: CollateralListTranslationTypeEn = {
  actions: {
    filter: 'Filtros',
    add: 'Nueva garantía',
  },
  filter: {
    contractNumber: 'Número de contrato',
    contractKey: 'Clave del contrato',
    id: 'ID',
    type: 'Tipo',
    status: 'Estado',
    createdBy: 'Creado por',
    contractDate: 'Fecha del contrato',
    createdDate: 'Fecha de creación',
    resetButton: 'Limpiar filtros',
    applyButton: 'Aplicar filtros',
  },
  table: {
    id: 'ID',
    contractNumber: 'Número de contrato',
    type: 'Tipo',
    status: 'Estado',
    createDateTime: 'Fecha de creación',
    tradeDate: 'Fecha del contrato',
    createLogin: 'Creado por',
  },
};
