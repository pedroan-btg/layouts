import type { CollateralListTranslationType as CollateralListTranslationTypeEn } from '../en/collateral-list.translation';

export type CollateralListTranslationType = CollateralListTranslationTypeEn | null;

export const CollateralListTranslation: CollateralListTranslationTypeEn = {
  actions: {
    filter: 'Filtros',
    add: 'Nova garantia',
  },
  filter: {
    contractNumber: 'Número do contrato',
    contractKey: 'Chave do contrato',
    id: 'ID',
    type: 'Tipo',
    status: 'Status',
    createdBy: 'Criado por',
    contractDate: 'Data do contrato',
    createdDate: 'Data de criação',
    resetButton: 'Limpar filtros',
    applyButton: 'Aplicar filtros',
  },
  table: {
    id: 'ID',
    contractNumber: 'Número do contrato',
    type: 'Tipo',
    status: 'Status',
    createDateTime: 'Data de criação',
    tradeDate: 'Data do contrato',
    createLogin: 'Criado por',
  },
};
