export type IntegrationsTranslationType = typeof IntegrationsTranslations | null;

export const IntegrationsTranslations = {
  label: 'Integrações ',
  dealRas: {
    label: 'DealRas',
  },
  hasCommitment: {
    label: 'Commitment',
  },
};
