import { ValitationsTranslationType } from '../en/validations.translation';

export const ValidationsTranslation: ValitationsTranslationType = {
  label: 'Validaciones',
  hasErrors: 'Errores',
  hasWarnings: 'Advertencias',
  hasWarningsToSave: '¿Desea continuar?',
  denyButton: 'Regresar',
  conffirmButton: 'Editar Operación',
  denyTrade: 'No',
  saveTrade: 'Guardar operación',
};
