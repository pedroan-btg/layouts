export const TradeInformationsTranslation = {
  label: 'Informações da Operação',
  pending: 'Pendente',
  searchCommitment: {
    label: 'Compromisso',
  },
  aggregateGuarantees: {
    label: 'Garantias Consolidadas',
  },
  dealRas: {
    label: 'Acordo RAS',
  },
  product: {
    label: 'Produto',
  },
  contractNumber: {
    label: 'Número do Contrato',
  },
  party: {
    label: 'Parte',
  },
  partyAccount: {
    label: 'Conta',
  },
  counterparty: {
    label: 'Contraparte',
  },
  counterpartyTaxId: {
    label: 'CPF/CNPJ da Contraparte',
  },
  counterpartyAccount: {
    label: 'Conta',
  },
  taxLocationCity: {
    label: 'Cidade de Localização Fiscal',
  },
  agent: {
    label: 'Agente administrativo',
  },
  isMigration: {
    label: 'Carga masiva',
  },
  type: {
    label: 'Productos',
  },
  alert: {
    errorGetAccount: 'Erro ao carregar as contas da contraparte',
  },
};
