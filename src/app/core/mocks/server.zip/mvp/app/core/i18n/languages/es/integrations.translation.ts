import { IntegrationsTranslationType } from '../en/integrations.translation';

export const IntegrationsTranslations: IntegrationsTranslationType = {
  label: 'Integraciones ',
  dealRas: {
    label: 'DealRas',
  },
  hasCommitment: {
    label: 'Commitment',
  },
};
