export type OverdueChargesTranslationType = typeof OverdueChargesTranslation;

export const OverdueChargesTranslation = {
  label: 'Overdue Charges',
  pending: 'Pending',
  interestArrears: {
    label: 'Interest arrears',
    rate: 'Rate',
    base: 'Base',
  },
  penaltyFee: {
    label: 'Moratorium fine',
    rate: 'Rate',
    lateInterest: 'Late interest',
    onExecutive: 'Late payment interest on executive',
  },
  latePaymentInterest: {
    label: 'Compensatory interest',
    index: 'Index',
    indexPercentage: 'Index %',
    rate: 'Rate',
    capitalization: 'Capitalization',
    base: 'Base',
    correction: 'Correction',
    frequency: 'Frequency',
    anniversary: 'Anniversary',
    lag: 'Lag',
    enable: 'Enable form',
  },
  isLatePaymentEqualToRemuneration: {
    label: 'Equal to remuneration rate',
  },
  alert: {
    loading: 'Loading...',
    errorLoad: 'Sorry, looks like there are some errors detected, please try again.',
    errorLoadButton: 'Ok, got it!',
    updateDelayChargesInterestRate: 'Define Late Payment Interest equal to Remuneration Rate?',
  },
};
