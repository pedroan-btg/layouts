import { Pipe, PipeTransform } from '@angular/core';
import { OperationType } from '../enums';

@Pipe({ name: 'operationTypeKey', pure: true })
export class OperationTypeKeyPipe implements PipeTransform {
  transform(operationType: OperationType | null): string | null {
    if (operationType == null) return null;

    const operationTypeEnum = OperationType[operationType];

    if (typeof operationTypeEnum !== 'string') return operationType.toString();

    return `enums.operationType.${operationTypeEnum.charAt(0).toLowerCase() + operationTypeEnum.slice(1)}`;
  }
}
