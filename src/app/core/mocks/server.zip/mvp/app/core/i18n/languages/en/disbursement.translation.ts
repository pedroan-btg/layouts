export type DisbursementTranslationType = typeof DisbursementTranslation;

export const DisbursementTranslation = {
  label: 'Disbursements',
  pending: 'Pending',
  amount: 'Amount',
  disbursementDate: {
    label: 'Disbursement date',
  },
  maxAvailable: 'Max available',
  internalAccountIntermediation: 'Internal account intermediation',
  actions: 'Actions',
  deleteWarning: 'Are you sure you want to delete this disbursement?',
  types: {
    internal: 'Internal',
    external: 'External',
    ssis: 'SSIS',
  },
  errors: {
    maxValue: 'Value cannot exceed {{max}}',
  },
  hasDisbursement: 'To credit',
  remainingValue: 'Remaining value',
  client: 'Client',
  type: 'Type',
  bank: 'Bank',
  account: 'Account',
  accountDigit: 'Digit',
  agency: {
    label: 'Agency',
    info: 'Agency without digit',
  },
  modal: {
    add: 'Add disbursement',
    edit: 'Edit disbursement',
  },
  addForm: 'Add disbursement',
  empty: 'No disbursement added.',
  errorNegativeRemaining: 'The remaining value for disbursement cannot be negative.',
};
