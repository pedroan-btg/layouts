export type TradeInformationsTranslationType = typeof TradeInformationsTranslation;

export const TradeInformationsTranslation = {
  label: 'Trade Informations',
  pending: 'Pending',
  searchCommitment: {
    label: 'Commitment',
  },
  aggregateGuarantees: {
    label: 'Agregate Guarantees',
  },
  dealRas: {
    label: 'Deal RAS',
  },
  product: {
    label: 'Product',
  },
  contractNumber: {
    label: 'Contract Number',
  },
  party: {
    label: 'Party',
  },
  partyAccount: {
    label: 'Account',
  },
  counterparty: {
    label: 'Counterparty',
  },
  counterpartyAccount: {
    label: 'Account',
  },
  counterpartyTaxId: {
    label: 'Counterparty Tax ID',
  },
  taxLocationCity: {
    label: 'Tax Location City',
  },
  agent: {
    label: 'Administrative agent',
  },
  isMigration: {
    label: 'Is Migration',
  },
  type: {
    label: 'Products',
  },
  alert: {
    errorGetAccount: 'Error loading counterparty accounts',
  },
};
