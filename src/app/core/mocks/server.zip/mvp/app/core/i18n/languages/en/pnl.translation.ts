export type PnlTranslationType = typeof PnlTranslation | null;

export const PnlTranslation = {
  book: {
    label: 'Book',
  },
  strategy: {
    label: 'Strategy',
  },
  errors: {
    searchBook:
      'Sorry, looks like there are some errors detected when searching books, please try again.',
    searchStrategy:
      'Sorry, looks like there are some errors detected when searching strategies, please try again.',
    forbidden: 'You do not have permission to perform this action.',
  },
};
