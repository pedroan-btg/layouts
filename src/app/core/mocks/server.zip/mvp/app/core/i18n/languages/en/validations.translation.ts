export type ValitationsTranslationType = typeof ValidationsTranslation;

export const ValidationsTranslation = {
  label: 'Validations',
  hasErrors: 'Errors',
  hasWarnings: 'Warnings',
  hasWarningsToSave: 'Would you like to proceed?',
  denyButton: 'Return',
  conffirmButton: 'Edit Trade',
  denyTrade: 'No',
  saveTrade: 'Save trade',
};
