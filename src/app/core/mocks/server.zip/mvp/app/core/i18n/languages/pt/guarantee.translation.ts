import { GuaranteeTranslationType } from '../en/guarantee.translation';

export const GuaranteeTranslation: GuaranteeTranslationType = {
  label: 'Avalistas',
  pending: 'Pendente',
  modal: {
    add: 'Adicionar avalista',
    edit: 'Editar avalista',
  },
  instrument: 'Instrumento',
  guarantor: 'Garantidor',
  intervening: 'Interveniente',
  amount: 'Valor',
  obligationType: 'Tipo de obrigação',
  coverType: 'Tipo de cobertura',
  actions: 'Ações',
  deleteWarning: 'Tem certeza que deseja excluir esta avalista?',
  rate: 'Taxa',
  value: 'Valor',
  empty: 'Nenhum avalista adicionado.',
  rateOrValue: 'Taxa ou Valor',
};
