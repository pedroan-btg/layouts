export type DefaultsTranslationType = typeof DefaultsTranslation | null;

export const DefaultsTranslation = {
  ok: 'Ok',
  cancel: 'Cancel',
  close: 'Close',
  save: 'Save',
  loading: 'Loading',
  creating: 'Creating...',
  validating: 'Validating...',
  warning: 'Warning',
  serverError: {
    title: 'Server Error',
    message:
      'An unexpected error occurred on the server. Please try again later. If the problem persists, contact support.',
  },
  noRecords: 'No records',
  yes: 'Yes',
  no: 'No',
  send: 'Send',
  edit: 'Edit',
  configured: 'Configured',
  completed: 'Completed',
  pending: 'Pending',
  alertService: {
    errorTitle: 'Error',
    tryAgain: 'Please try again later.',
  },
  actions: 'Actions',
  remove: 'Are you sure you would like to remove this item?',
};
