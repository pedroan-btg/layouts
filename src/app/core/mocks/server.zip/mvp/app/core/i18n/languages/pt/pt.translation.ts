import { TranslationType } from '../en';
import { ApiTranslation } from './api.translation';
import { CommonDomainTranslation } from './common-domain.translation';
import { DefaultsTranslation } from './defaults.translation';
import { EnumsTranslation } from './enums.translation';
import { FeeTranslation } from './fee.translation';
import { IntegrationsTranslations } from './integrations.translation';
import { LoanTranslation } from './loan.translation';
import { PnlTranslation } from './pnl.translation';
import { SearchCommitmentTranslation } from './search-commitment.translation';
import { TradeInformationsTranslation } from './trade-informations.translation';
import { CollateralListTranslation } from './collateral-list.translation';
import { CollateralBasicTranslation } from './collateral-basic.translation';
import { CommonTranslation } from './common.translation';
import { CollateralStepsTranslation } from './collateral-steps.translation';

export const pt: TranslationType = {
  language: 'Português',
  api: ApiTranslation,
  loan: LoanTranslation,
  enums: EnumsTranslation,
  searchCommitment: SearchCommitmentTranslation,
  pnl: PnlTranslation,
  integrations: IntegrationsTranslations,
  defaults: DefaultsTranslation,
  fee: FeeTranslation,
  commonDomain: CommonDomainTranslation,
  tradeInformationLoanBr: TradeInformationsTranslation,
  common: CommonTranslation,
  collateral: {
    list: CollateralListTranslation,
    basic: CollateralBasicTranslation,
    steps: CollateralStepsTranslation,
  },
};
