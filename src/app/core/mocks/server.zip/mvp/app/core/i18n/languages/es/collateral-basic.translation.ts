import type { CollateralBasicTranslationType as CollateralBasicTranslationTypeEn } from '../en/collateral-basic.translation';

export type CollateralBasicTranslationType = CollateralBasicTranslationTypeEn | null;

export const CollateralBasicTranslation: CollateralBasicTranslationTypeEn = {
  title: 'Información básica',
  description: 'Complete la información básica del colateral.',
  integrations: {
    title: 'Integraciones',
    prefillFromDealRAS: 'Precompletar campos con el Deal RAS',
    dealRAS: { label: 'Deal RAS', placeholder: 'Ingrese el ID del Deal RAS' },
    dealRASStatus: 'Estado del Deal RAS',
    applyButton: 'Aplicar',
    confirmApplyTitle: '¿Aplicar datos del Deal RAS?',
    confirmApplyBody:
      'Esto completará campos utilizando la información del Deal RAS. ¿Desea continuar?',
  },
  contract: {
    title: 'Contrato',
    searchByKey: { text: 'Buscar por clave', leasing: 'Leasing' },
    searchPlaceholder: 'Buscar',
    clearSearch: 'Limpiar búsqueda',
    onlyNotLinked: 'Solo no vinculados',
    searchButton: 'Buscar',
    table: {
      key: 'Clave',
      operation: 'Operación',
      linkedToTrade: 'Vinculado a trade',
      action: 'Acción',
    },
    form: {
      contractDate: 'Fecha del contrato',
      startDate: 'Inicio de vigencia',
      writeOffType: { label: 'Tipo de baja', placeholder: 'Seleccione un tipo' },
    },
  },
};
