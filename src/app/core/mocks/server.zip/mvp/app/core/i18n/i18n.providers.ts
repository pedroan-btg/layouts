import { ClassProvider, EnvironmentProviders, importProvidersFrom } from '@angular/core';

import { I18nLanguages, i18n } from 'fts-frontui/i18n';
import { Languages } from './i18n.languages';

const i18nProviders: (EnvironmentProviders | ClassProvider)[] = [
  importProvidersFrom([i18n]),
  { provide: I18nLanguages, useClass: Languages },
];

export const provideI18n = (): (EnvironmentProviders | ClassProvider)[] => i18nProviders;
