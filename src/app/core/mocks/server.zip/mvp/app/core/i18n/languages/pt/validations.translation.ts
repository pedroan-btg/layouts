export type ValitationsTranslationType = typeof ValidationsTranslation | null;

export const ValidationsTranslation = {
  label: 'Validações',
  hasErrors: 'Erros',
  hasWarnings: 'Avisos',
  hasWarningsToSave: 'Deseja continuar?',
  denyButton: 'Voltar',
  conffirmButton: 'Editar Operação',
  denyTrade: 'Não',
  saveTrade: 'Salvar operação',
};
