export type CollateralBasicTranslationType = typeof CollateralBasicTranslation;

export const CollateralBasicTranslation = {
  title: 'Basic Information',
  description: 'Fill in basic collateral information.',
  integrations: {
    title: 'Integrations',
    prefillFromDealRAS: 'Prefill fields with Deal RAS',
    dealRAS: { label: 'Deal RAS', placeholder: 'Enter the Deal RAS ID' },
    dealRASStatus: 'Deal RAS Status',
    applyButton: 'Apply',
    confirmApplyTitle: 'Apply Deal RAS Data?',
    confirmApplyBody:
      'This will prefill fields using the Deal RAS information. Do you want to continue?',
  },
  contract: {
    title: 'Contract',
    searchByKey: { text: 'Search by key', leasing: 'Leasing' },
    searchPlaceholder: 'Search',
    clearSearch: 'Clear search',
    onlyNotLinked: 'Only not linked',
    searchButton: 'Search',
    table: {
      key: 'Key',
      operation: 'Operation',
      linkedToTrade: 'Linked to trade',
      action: 'Action',
    },
    form: {
      contractDate: 'Contract date',
      startDate: 'Start date',
      writeOffType: { label: 'Write-off type', placeholder: 'Select a type' },
    },
  },
};
