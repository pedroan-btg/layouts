import type { CollateralStepsTranslationType as CollateralStepsTranslationTypeEn } from '../en/collateral-steps.translation';

export type CollateralStepsTranslationType = CollateralStepsTranslationTypeEn | null;

export const CollateralStepsTranslation: CollateralStepsTranslationTypeEn = {
  actions: {
    cancel: 'Cancelar',
    back: 'Regresar',
    next: 'Avanzar',
  },
};
