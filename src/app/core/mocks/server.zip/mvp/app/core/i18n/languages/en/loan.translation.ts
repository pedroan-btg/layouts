import { CashflowTranslation } from './cashflow.translation';
import { DisbursementTranslation } from './disbursement.translation';
import { FeeTranslation } from './fee.translation';
import { GuaranteeTranslation } from './guarantee.translation';
import { HomeTranslation } from './home.translation';
import { IntegrationsTranslations } from './integrations.translation';
import { IssueConditionsTranslation } from './issue-conditions.translation';
import { OverdueChargesTranslation } from './overdue-charges.translation';
import { ProvisionTranslation } from './provision.translation';
import { RightOfPreferenceTranslation } from './right-of-preference.translation';
import { ValidationsTranslation } from './validations.translation';

export type LoanTranslationType = typeof LoanTranslation;

export const LoanTranslation = {
  home: HomeTranslation,
  basicInformation: 'Basic informations',
  conditions: 'Conditions',
  additional: 'Additional informations',
  review: {
    title: 'Review',
    subtitle: 'Review and correction of data entered in previous steps.',
    provision: {
      title: 'Provision for losses',
      status: {
        pending: 'Pending configuration',
        configured: 'Configured',
      },
      empty: {
        title: 'Provision not configured',
        subtitle: 'Configure provision for losses for this operation',
      },
    },
  },
  ticketActions: {
    orig: 'New trade',
    editOrig: 'Edit trade',
    adtv: 'Additive trade',
    editAdtv: 'Edit trade',
    copy: 'Copy as new trade',
    amend: 'Repair trade',
    editAmend: 'Edit repair trade',
  },
  tradeForm: {
    mode: {
      stepper: 'Step-by-Step Form',
      unified: 'Unified Form',
    },
    actions: {
      submit: 'Save',
      validate: 'Validate',
      back: 'Back',
    },
    successCreated: 'Trade created successfully.',
    failedToCreate: 'Error creating trade.',
    integrations: IntegrationsTranslations,
    issueConditions: IssueConditionsTranslation,
    fee: FeeTranslation,
    overdueCharges: OverdueChargesTranslation,
    disbursement: DisbursementTranslation,
    provision: ProvisionTranslation,
    guarantee: GuaranteeTranslation,
    cashflow: CashflowTranslation,
    rightOfPreference: RightOfPreferenceTranslation,
  },
  validations: {
    issueConditionsDto: {
      tradeDate: {
        differentFromCashflowGeneratorStartDate:
          'Trade date is different from cashflow generator start date',
      },
      maturityDate: {
        empty: 'Maturity date is required',
      },
    },
  },
  validationErrorsModal: ValidationsTranslation,
  view: {
    contractNumber: 'Contract',
    tradeType: 'Type',
    section: {
      overview: 'Overview',
    },
  },
};
