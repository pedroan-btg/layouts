export { en } from './en.translation';
export type { TranslationType } from './en.translation';
export type { ApiTranslationType } from './api.translation';
export type { HomeTranslationType } from './home.translation';
export type { LoanTranslationType } from './loan.translation';
export type { EnumsTranslationType } from './enums.translation';
