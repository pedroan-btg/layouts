import { CashflowTranslationType } from '../en/cashflow.translation';

export const CashflowTranslation: CashflowTranslationType = {
  label: 'Flujo de caja',
  pending: 'Pendiente',
  installments: 'Cuotas',
  maturityType: {
    label: 'Tipo de vencimiento',
    values: {
      INMS: 'Início do mês',
      FMMS: 'Fim do mês',
      AFTR: 'Próximo día hábil',
      BFOR: 'Día hábil anterior',
    },
  },
  paymentDay: {
    label: 'Día',
  },
  startAccrual: {
    label: 'Inicio',
  },
  calculationType: {
    label: 'Tipo de corrección',
    values: {
      PRIC: 'PRICE',
      BAND: 'SAC',
    },
  },
  valorizationMethod: {
    label: 'Tipo de valorización',
    values: {
      INST: 'Installment',
      BAND: 'BalanceDue',
    },
  },
  accrualOnBusinessDay: 'Período de referencia en día hábil',
  interest: 'Intereses',
  interestFrequency: {
    label: 'Frecuencia',
  },
  interestGracePeriod: {
    label: 'Gracia (Meses)',
  },
  interestRate: {
    label: 'Tasa',
  },
  incorporate: 'Incorporar',
  interestIndex: {
    label: 'Índice',
  },
  indexerRate: {
    label: '% Índice',
  },
  interestLag: {
    label: 'Desfase',
  },
  round: {
    label: 'Redondeo',
  },
  spreadType: {
    label: 'Capitalización',
    values: {
      ECMP: 'Exponencial',
      SIMP: 'Linear',
    },
  },
  spreadBase: {
    label: 'Base',
  },
  principal: 'Principal',
  amortizationFrequency: {
    label: 'Frecuencia',
  },
  amortizationGracePeriod: {
    label: 'Gracia (Meses)',
  },
  import: 'Importar',
  generate: 'Generar',
  table: {
    maturityDate: 'Fecha de vencimiento',
    startDate: 'Fecha de inicio',
    endDate: 'Fecha de fin',
    amortization: 'Amortización',
    grv: 'VRG',
    indexer: 'Indexador',
    spreadRate: 'Tasa',
    spreadType: 'Tipo',
    spreadBase: 'Base',
    incorporate: 'Incorporar',
    amountDueAtMaturity: 'Monto a vencer en el vencimiento',
    interestAmount: 'Monto de interés',
    actions: {
      label: 'Acciones',
      delete: 'Eliminar',
      edit: 'Editar',
    },
    total: 'Total',
    summary: 'Resumen',
    totalAmortization: 'Total Amortización',
    totalIOF: 'Total IOF',
  },
  alert: {
    remove: 'Está seguro de que desea eliminar esta cuota?',
  },
  empty: 'No se ha añadido ningún flujo de caja.',
  error: {
    firstPaymentDate:
      'La fecha del primer pago debe ser posterior a la fecha de inicio del devengo.',
    maturityDateIsBeforeStartDate:
      'La fecha de vencimiento debe ser posterior a la fecha de inicio del devengo.',
    interestIndex: 'El índice de interés es obligatorio.',
    error: 'Por favor, complete todos los campos obligatorios correctamente.',
    maturityDate: 'La fecha de vencimiento es obligatoria.',
    title: 'Error de validación',
    invalidForm: 'Por favor, complete todos los campos obligatorios correctamente.',
  },
};
