export type GuaranteeTranslationType = typeof GuaranteeTranslation;

export const GuaranteeTranslation = {
  label: 'Guarantors',
  pending: 'Pending',
  modal: {
    add: 'Add guarantor',
    edit: 'Edit guarantor',
  },
  instrument: 'Instrument',
  guarantor: 'Guarantor',
  intervening: 'Intervening',
  amount: 'Amount',
  obligationType: 'Obligation type',
  coverType: 'Cover type',
  actions: 'Actions',
  deleteWarning: 'Are you sure you want to delete this guarantee?',
  rate: 'Rate',
  value: 'Value',
  empty: 'No guarantors added.',
  rateOrValue: 'Rate or Value',
};
