export type ApiTranslationType = typeof ApiTranslation | null;

export const ApiTranslation = {
  errors: {
    clientError: {
      title: 'Request Error',
      message: 'Some of the data submitted is incorrect. Please review the fields and try again.',
    },
    unauthorized: {
      title: 'Session Expired',
      message: 'Your session has expired. Please log in again to continue.',
    },
    forbidden: {
      title: 'Access Denied',
      message: 'You do not have permission to access this page or resource.',
    },
    notFound: {
      title: 'Page Not Found',
      message: 'The resource you are trying to access does not exist or has been removed.',
    },
    serverError: {
      title: 'Server Error',
      message:
        'An unexpected error occurred on the server. Please try again later. If the problem persists, contact support.',
      confirmButton: 'OK',
    },
    serviceUnavailable: {
      title: 'Service Unavailable',
      message:
        'We are currently experiencing temporary issues. The service will be available shortly. Please try again later.',
      confirmButton: 'OK',
    },
    timeout: {
      title: 'Request Timeout',
      message: 'The request took too long to process. Please try again.',
      confirmButton: 'OK',
    },
    pageExpired: {
      title: 'Session Expired',
      message: 'Your session has expired. Please log in again to continue.',
      confirmButton: 'OK',
    },
    tooManyRequests: {
      title: 'Too Many Requests',
      message:
        'You have made too many requests in a short period of time. Please wait a few minutes and try again.',
      confirmButton: 'OK',
    },
    genericError: {
      title: 'Unknown Error',
      message: 'An unexpected error occurred. Please try again later.',
    },
  },
};
