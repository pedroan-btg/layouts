import { ApiTranslationType } from '../en';

export const ApiTranslation: ApiTranslationType = {
  errors: {
    clientError: {
      title: 'Erro de Solicitação',
      message:
        'Alguns dos dados enviados estão incorretos. Por favor, revise os campos e tente novamente.',
    },
    unauthorized: {
      title: 'Sessão Expirada',
      message: 'Sua sessão expirou. Por favor, faça login novamente para continuar.',
    },
    forbidden: {
      title: 'Acesso Negado',
      message: 'Você não tem permissão para acessar esta página ou recurso.',
    },
    notFound: {
      title: 'Página Não Encontrada',
      message: 'O recurso que você está tentando acessar não existe ou foi removido.',
    },
    serverError: {
      title: 'Erro no Servidor',
      message:
        'Ocorreu um erro inesperado no servidor. Por favor, tente novamente mais tarde. Se o problema persistir, entre em contato com o suporte.',
      confirmButton: 'OK',
    },
    serviceUnavailable: {
      title: 'Serviço Indisponível',
      message:
        'Estamos enfrentando problemas temporários. O serviço estará disponível em breve. Por favor, tente novamente mais tarde.',
      confirmButton: 'OK',
    },
    timeout: {
      title: 'Tempo de Solicitação Esgotado',
      message: 'A solicitação demorou muito para ser processada. Por favor, tente novamente.',
      confirmButton: 'OK',
    },
    pageExpired: {
      title: 'Sessão Expirada',
      message: 'Sua sessão expirou. Por favor, faça login novamente para continuar.',
      confirmButton: 'OK',
    },
    tooManyRequests: {
      title: 'Muitas Solicitações',
      message:
        'Você fez muitas solicitações em um curto período de tempo. Por favor, espere alguns minutos e tente novamente.',
      confirmButton: 'OK',
    },
    genericError: {
      title: 'Erro Desconhecido',
      message: 'Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.',
    },
  },
};
