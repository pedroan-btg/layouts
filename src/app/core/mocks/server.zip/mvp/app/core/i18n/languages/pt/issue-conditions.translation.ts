export type IssueConditionsTranslationType = typeof IssueConditionsTranslation | null;

export const IssueConditionsTranslation = {
  label: 'Condições de Emissão',
  pending: 'Pendente',
  amount: {
    label: 'Valor Principal',
  },
  grossNotional: {
    label: 'Valor Nominal Bruto',
  },
  netNotional: {
    label: 'Valor Liberado',
  },
  tradeCurrency: {
    label: 'Moeda da Operação',
  },
  disbursementCurrency: {
    label: 'Moeda de Desembolso',
  },
  exchangeRate: {
    label: 'Taxa de Câmbio',
  },
  calendars: {
    label: 'Calendários',
  },
  contractDate: {
    label: 'Data do Contrato',
  },
  letterOfCreditDate: {
    label: 'Data da Carta de Crédito',
  },
  tradeDate: {
    label: 'Data da Operação',
  },
  maturityDate: {
    label: 'Data de Vencimento',
    info: 'Você pode digitar atalhos como 1y (1 ano), 12m (12 meses) ou 365d (365 dias) para preencher automaticamente a data',
  },
  disbursementDate: {
    label: 'Data de Desembolso',
  },
  useOfProceeds: {
    label: 'Destino dos Recursos',
  },
  isRollout: {
    label: 'É Renovação',
  },
  swapFundingRate: {
    label: 'Taxa de Financiamento do Swap',
  },
  isLiability: {
    label: 'É Passivo',
  },
  lastRolloutMaturityDate: {
    label: 'Última Data de Vencimento da Renovação',
  },
  nextRolloutDate: {
    label: 'Próxima Data de Renovação',
  },
  exchangeRateLag: {
    label: 'Cambio lag',
  },
  impuestos: {
    label: 'Impostos',
  },
  hasStampTaxes: {
    label: 'Timbres y estampillas?',
  },
  stampTaxesExchangeRate: {
    label: 'Câmbio - CLP',
  },
  stampTaxes: {
    label: 'Timbres y estampillas',
  },
  hasWithholdingTax: {
    label: 'Tiene With holding Tax?',
  },
  withholdingTax: {
    label: 'Withholding Tax',
  },
  fundingForm: {
    label: 'Funding',
  },
  funding: {
    label: 'Funding %',
  },
  iofFinanced: {
    label: 'IOF Financiado',
    value: 'IOF Value:',
    toCalculate: '* Valor calculado após gerar o fluxo',
    info: 'Será calculado pelo simulador',
  },
  iofType: {
    label: 'IOF Type',
    values: {
      PAIDCOLLECTED: 'Já Pago e Já Recolhido',
      DUE: 'Devido',
      EXEMPT: 'Isento',
      PAIDNOTCOLLECTED: 'Já Pago e Não Recolhido',
      undefined: 'N/A',
      null: 'null',
    },
  },
  alert: {
    errorLoadHolidays: 'Error ao carregar os feriados',
  },
};
