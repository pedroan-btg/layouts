import { SearchCommitmentTranslationType } from '../en/search-commitment.translation';

export const SearchCommitmentTranslation: SearchCommitmentTranslationType = {
  label: 'Compromiso',
  title: 'Buscar Compromiso',
  searchButton: 'Buscar',
  form: {
    contractNumber: {
      label: 'Número de Contrato',
    },
    tradeId: {
      label: 'ID de Operación',
    },
    maturityDate: {
      label: 'Fecha de Vencimiento',
    },
    undefinedPeriod: 'Período Indefinido',
    createdByMe: 'Creado por Mí',
  },
  commitment: {
    counterparty: 'Contraparte',
    cge: 'CGE',
    contractNumber: 'Número de Contrato',
    maturityDate: 'Fecha de Vencimiento',
    currency: 'Moneda',
    amount: 'Importe',
    tradeId: 'ID de Operación',
  },
};
