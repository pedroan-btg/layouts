import { inject, Pipe, PipeTransform } from '@angular/core';

import { TranslatePipe } from 'fts-frontui/i18n';

@Pipe({
  name: 'enumKeyValue',
})
export class EnumKeyValuePipe implements PipeTransform {
  private readonly translate = inject(TranslatePipe);

  transform(value: object, i18nPrefix?: string): { key: string; value: number }[] {
    const entries = Object.keys(value)
      .filter(k => isNaN(Number(k)))
      .map(k => ({
        key: k,
        value: (value as Record<string, number>)[k],
        label: i18nPrefix
          ? this.translate.transform(`${i18nPrefix}.${k.charAt(0).toLowerCase() + k.slice(1)}`)
          : k,
      }));

    return entries;
  }
}
