import { inject } from '@angular/core';
import { Router } from '@angular/router';

export const connectRouter = (router = inject(Router), useHash = false): void => {
  goToRoute(router, useHash);

  if (!useHash) {
    window.addEventListener('popstate', () => goToRoute(router, useHash));
  } else {
    window.addEventListener('hashchange', () => goToRoute(router, useHash));
  }
};

const goToRoute = (router: Router, useHash = false): void => {
  let url: string;

  if (!useHash) {
    url = `${location.pathname.substring(1)}${location.search}`;
    router.navigateByUrl(url);
  } else {
    url = `${location.hash.substring(1)}${location.search}`;
    router.navigateByUrl(url);
  }
};
