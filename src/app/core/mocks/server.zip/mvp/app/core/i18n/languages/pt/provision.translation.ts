export type ProvisionTranslationType = typeof ProvisionTranslation | null;

export const ProvisionTranslation = {
  label: 'Provisão de perdas',
  pending: 'Pendente',
  reset: 'Resetar informações',
  portfolioClassification: 'Classificação de portfólio',
  ratingCounterparty: 'Rating da contraparte',
  kead: 'kEAD',
  pd: 'PD',
  lgd: 'LGD',
  pe: 'PE',
  stage: 'Stage',
  incurredLoss: 'Incurred loss',
  import: {
    label: 'Importar PDF',
    loading: 'Importando...',
    title: 'Usar dados encontrados?',
    error:
      'Parece que ocorreu um erro ao importar os dados, verifique seu arquivo e tente novamente',
  },
  buildError: 'Parece que ocorreu um erro, tente novamente mais tarde',
  type: {
    label: 'Tipo',
    drt: 'Reestruturação de Débito',
    drn: 'Renegociação de Débito',
    ncr: 'Novo crédito',
    nc: 'NC',
  },
};
