export type SearchCommitmentTranslationType = typeof SearchCommitmentTranslation | null;

export const SearchCommitmentTranslation = {
  label: 'Commitment',
  title: 'Search Commitment',
  searchButton: 'Search',
  form: {
    contractNumber: {
      label: 'Contract Number',
    },
    tradeId: {
      label: 'Trade Id',
    },
    maturityDate: {
      label: 'Maturity Date',
    },
    undefinedPeriod: 'Undefined Period',
    createdByMe: 'Created by Me',
  },
  commitment: {
    counterparty: 'Counterparty',
    cge: 'Cge',
    contractNumber: 'Contract Number',
    maturityDate: 'Maturity Date',
    currency: 'Currency',
    amount: 'Amount',
    tradeId: 'Trade Id',
  },
};
