import type { CollateralBasicTranslationType as CollateralBasicTranslationTypeEn } from '../en/collateral-basic.translation';

export type CollateralBasicTranslationType = CollateralBasicTranslationTypeEn | null;

export const CollateralBasicTranslation: CollateralBasicTranslationTypeEn = {
  title: 'Informações básicas',
  description: 'Preencha as informações básicas do colateral.',
  integrations: {
    title: 'Integrações',
    prefillFromDealRAS: 'Pré preencher campos com o Deal RAS',
    dealRAS: { label: 'Deal RAS', placeholder: 'Informe o ID do Deal RAS' },
    dealRASStatus: 'Status Deal RAS',
    applyButton: 'Aplicar',
    confirmApplyTitle: 'Aplicar dados do Deal RAS?',
    confirmApplyBody:
      'Isso irá pré preencher campos usando as informações do Deal RAS. Deseja continuar?',
  },
  contract: {
    title: 'Contrato',
    searchByKey: { text: 'Buscar por chave', leasing: 'Leasing' },
    searchPlaceholder: 'Buscar',
    clearSearch: 'Limpar busca',
    onlyNotLinked: 'Apenas não vinculados',
    searchButton: 'Buscar',
    table: {
      key: 'Chave',
      operation: 'Operação',
      linkedToTrade: 'Vínculo a trade',
      action: 'Ação',
    },
    form: {
      contractDate: 'Data do contrato',
      startDate: 'Data início vigência',
      writeOffType: { label: 'Tipo de baixa', placeholder: 'Selecione um tipo' },
    },
  },
};
