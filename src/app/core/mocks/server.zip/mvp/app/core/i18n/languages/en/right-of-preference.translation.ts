export type RightOfPreferenceTranslationType = typeof RightOfPreferenceTranslation;

export const RightOfPreferenceTranslation = {
  label: 'Right of Preference',
  pending: 'Pending',
  product: 'Product',
  rate: 'Rate',
  limitDate: 'Limit Date',
  client: 'Client',
  clientIsOnboarded: 'Client is Onboarded',
  actions: 'Actions',
  clientName: 'Client Name',
  deleteWarning: 'Are you sure you want to delete this right of preference?',
  modal: {
    add: 'Add Right of Preference',
    edit: 'Edit Right of Preference',
  },
  emptyList: 'No rights of preference added.',
};
