import { ApplicationConfig, provideZonelessChangeDetection } from '@angular/core';
import { provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideHttpClient, withInterceptors, withInterceptorsFromDi } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { provideRouterStore, routerReducer } from '@ngrx/router-store';
import { provideStoreDevtools } from '@ngrx/store-devtools';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';

import { provideHttpClientWithDateInterceptor } from 'fts-frontui/utils';
import { provideDevkit } from 'fts-frontui/devkit';
import { routes } from './app.routes';
import { provideApp } from './core';
import { rasMockInterceptor } from '../../mocks/interceptor/ras.interceptor';
import { manufacturersMockInterceptor } from '../../mocks/interceptor/manufacturers.interceptor';
import { modelsMockInterceptor } from '../../mocks/interceptor/models.interceptor';
import { collateralClientsMockInterceptor } from '../../mocks/interceptor/collateral-clients.interceptor';

const devConfig = [provideDevkit(), provideStoreDevtools()];

export const appConfig: ApplicationConfig = {
  providers: [
    provideApp(),
    provideHttpClientWithDateInterceptor(),
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes),
    provideAnimations(),
    // Registra os mocks de contratos e RAS no HttpClient de nível global
    // para garantir que serviços com providedIn 'root' também sejam interceptados.
    provideHttpClient(
      withInterceptors([
        rasMockInterceptor,
        manufacturersMockInterceptor,
        modelsMockInterceptor,
        collateralClientsMockInterceptor,
      ]),
      withInterceptorsFromDi(),
    ),
    provideStore({ router: routerReducer }),
    provideRouterStore(),
    provideEffects(),
    ...devConfig,
  ],
};
