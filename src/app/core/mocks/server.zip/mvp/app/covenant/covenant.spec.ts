import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Covenant } from './covenant';

describe('Covenant', () => {
  let component: Covenant;
  let fixture: ComponentFixture<Covenant>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Covenant],
    }).compileComponents();

    fixture = TestBed.createComponent(Covenant);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
