import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: '[fts-covenant]',
  imports: [],
  templateUrl: './covenant.html',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Covenant {}
