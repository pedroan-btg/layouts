import { Routes } from '@angular/router';
import { provideApp } from './core';
import { provideHttpClientWithPageLoadingInterceptor } from 'fts-frontui/loading';
import { provideHttpClient, withInterceptors, withInterceptorsFromDi } from '@angular/common/http';
import { contratosMockInterceptor } from '../../mocks/interceptor/contratos.interceptor';
import { rasMockInterceptor } from '../../mocks/interceptor/ras.interceptor';
import { manufacturersMockInterceptor } from '../../mocks/interceptor/manufacturers.interceptor';
import { modelsMockInterceptor } from '../../mocks/interceptor/models.interceptor';
import { statesMockInterceptor } from '../../mocks/interceptor/states.interceptor';
import { citiesMockInterceptor } from '../../mocks/interceptor/cities.interceptor';
import { neighborhoodsMockInterceptor } from '../../mocks/interceptor/neighborhoods.interceptor';
import { dynamicFormSchemaMockInterceptor } from '../../mocks/interceptor/dynamic-form-schema.interceptor';
import { editorFormSchemaMockInterceptor } from '../../mocks/interceptor/editor-form-schema.interceptor';
import { dynamicFormsListMockInterceptor } from '../../mocks/interceptor/dynamic-forms-list.interceptor';
import { draftsMockInterceptor } from '../../mocks/interceptor/drafts.interceptor';
import { collateralMockInterceptor } from '../../mocks/interceptor/collateral.interceptor';
import { collateralClientsMockInterceptor } from '../../mocks/interceptor/collateral-clients.interceptor';
import { ProdutoGarantiaApi } from './adm/list-dynamic-form/modal/api';

export const routes: Routes = [
  {
    path: '',
    providers: [
      provideApp(),
      provideHttpClient(withInterceptorsFromDi()),
      provideHttpClientWithPageLoadingInterceptor(),
    ],
    loadComponent: () => import('./list/list').then(m => m.List),
  },
  {
    path: 'list',
    providers: [
      provideApp(),
      provideHttpClient(withInterceptorsFromDi()),
      provideHttpClientWithPageLoadingInterceptor(),
    ],
    loadComponent: () => import('./list/list').then(m => m.List),
  },
  {
    path: 'adm/list-dynamic-form',
    providers: [
      provideApp(),
      ProdutoGarantiaApi,
      provideHttpClient(
        withInterceptors([
          draftsMockInterceptor,
          dynamicFormsListMockInterceptor,
          dynamicFormSchemaMockInterceptor,
          manufacturersMockInterceptor,
          modelsMockInterceptor,
          collateralMockInterceptor,
        ]),
        withInterceptorsFromDi(),
      ),
      provideHttpClientWithPageLoadingInterceptor(),
    ],
    loadComponent: () => import('./adm/list-dynamic-form').then(m => m.ListDynamicForm),
  },
  {
    path: 'adm',
    providers: [
      provideApp(),
      ProdutoGarantiaApi,
      provideHttpClient(
        withInterceptors([
          draftsMockInterceptor,
          dynamicFormsListMockInterceptor,
          dynamicFormSchemaMockInterceptor,
          manufacturersMockInterceptor,
          modelsMockInterceptor,
          collateralMockInterceptor,
        ]),
        withInterceptorsFromDi(),
      ),
      provideHttpClientWithPageLoadingInterceptor(),
    ],
    loadComponent: () => import('./adm/list-dynamic-form').then(m => m.ListDynamicForm),
  },
  {
    path: 'editor',
    providers: [
      provideApp(),
      provideHttpClient(
        withInterceptors([
          editorFormSchemaMockInterceptor,
          draftsMockInterceptor,
          manufacturersMockInterceptor,
          modelsMockInterceptor,
          statesMockInterceptor,
          citiesMockInterceptor,
          neighborhoodsMockInterceptor,
        ]),
        withInterceptorsFromDi(),
      ),
      provideHttpClientWithPageLoadingInterceptor(),
    ],
    loadComponent: () =>
      import('./form-builder/editor/form-schema-editor').then(m => m.FormSchemaEditor),
  },
  {
    path: 'covenant',
    loadComponent: () => import('./covenant/covenant').then(m => m.Covenant),
  },
  {
    path: 'new',
    providers: [
      provideApp(),
      provideHttpClient(
        withInterceptors([
          contratosMockInterceptor,
          rasMockInterceptor,
          collateralMockInterceptor,
          dynamicFormsListMockInterceptor,
          dynamicFormSchemaMockInterceptor,
          collateralClientsMockInterceptor,
        ]),
        withInterceptorsFromDi(),
      ),
    ],
    loadComponent: () => import('./steps-form/form').then(m => m.StepsForm),
  },
];
