import { ChangeDetectionStrategy, Component, Type } from '@angular/core';
import { CommonModule } from '@angular/common';
import { i18n } from 'fts-frontui/i18n';
import { StepperNextDirective } from '../features/widgets/stepper/directives/stepper-next.directive';
import { StepperPrevDirective } from '../features/widgets/stepper/directives/stepper-prev.directive';
import { RouterModule } from '@angular/router';
import { StepperModule } from '../features/widgets/stepper/stepper.module';

@Component({
  selector: '[fts-steps-form]',
  standalone: true,
  imports: [
    CommonModule,
    StepperModule,
    StepperNextDirective,
    StepperPrevDirective,
    i18n,
    RouterModule,
  ],
  templateUrl: './form.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StepsForm {
  loadBasicInformationLazy = async (): Promise<Type<unknown>> => {
    const mod = await import('./basic-information/basic-information');

    return mod.BasicInformation as Type<unknown>;
  };

  loadCollateralLazy = async (): Promise<Type<unknown>> => {
    const mod = await import('./collateral/collateral');

    return mod.Collateral as Type<unknown>;
  };

  loadCreditsLazy = async (): Promise<Type<unknown>> => {
    const mod = await import('./credit/credit');

    return mod.Credit as Type<unknown>;
  };

  loadReviewLazy = async (): Promise<Type<unknown>> => {
    const mod = await import('./review/review');

    return mod.Review as Type<unknown>;
  };

  loadDocumentsLazy = async (): Promise<Type<unknown>> => {
    const mod = await import('./document/document');

    return mod.Document as Type<unknown>;
  };
}
