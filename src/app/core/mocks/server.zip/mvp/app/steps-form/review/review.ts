import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: '[fts-review]',
  imports: [],
  templateUrl: './review.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Review {}
