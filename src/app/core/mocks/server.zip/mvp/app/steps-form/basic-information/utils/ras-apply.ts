import type { BasicInfoCtx } from './types';
import type { DealRasResponse } from '../models';
import type { Observable } from 'rxjs';
import { applyRasToForm as applyRasToFormUtil } from './form-helpers';
import { formatIsoToInput as formatIsoToInputUtil } from './date-formatter';
import { mapDealRasToContrato as mapDealRasToContratoUtil } from './deal-ras-mapper';
import { finalize } from 'rxjs/operators';

export function performApplyRas(
  self: BasicInfoCtx & {
    dealRasSvc: { getDealRas: (id: string) => Observable<DealRasResponse> };
  },
  id: string,
): void {
  self.dealRASStatus = 'Loading...';
  self.rasLoading.set(true);
  self.dealRasSvc
    .getDealRas(id)
    .pipe(finalize(() => self.rasLoading.set(false)))
    .subscribe({
      next: (res: DealRasResponse) => {
        applyRasToFormUtil(self.form, res, formatIsoToInputUtil);
        // Limpa qualquer lista pré-existente para evitar mistura com RAS
        const maybeSvc = self.svc as unknown as { resetList?: () => void };

        if (typeof maybeSvc.resetList === 'function') {
          maybeSvc.resetList();
        }

        self.lastProcessedPage = 0;
        self.rasLocked = true;
        self.manualLocked = false;
        self.manualContratos = [];
        self.svc.clearSelection();
        self.rasContratos = [mapDealRasToContratoUtil(self.dealRAS, res)];
        self.dealRASStatus = 'OK';
        // Força limpeza de caches internos do grid alternando o modo
        self.paginationMode = 'numbered';
        setTimeout(() => (self.paginationMode = 'infinite'));
        self.debugState('performApplyRAS success');
      },
      error: () => {
        self.dealRASStatus = 'Error fetching';
        self.debugState('performApplyRAS error');
      },
    });
}
