import './basic-info.spec.mock-base';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { setupBasicInfoTest } from './basic-info.spec.helpers';

describe('BasicInformation (compact spec)', () => {
  let mockBasicInfoService: any;
  let mockGetDealRasService: any;
  let createCmp: () => { fixture: any; cmp: any };

  beforeEach(async () => {
    ({ mockBasicInfoService, mockGetDealRasService, createCmp } = await setupBasicInfoTest());
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it('initializes, reflects loading, and triggers loadMore via handler', async () => {
    const { cmp } = createCmp();
    expect(cmp.form.get('dataContrato')).toBeDefined();
    expect(cmp.tiposBaixa?.length).toBeGreaterThan(0);

    mockBasicInfoService.loading$.next(true);
    expect(cmp.isLoading()).toBe(true);
    mockBasicInfoService.loading$.next(false);
    expect(cmp.isLoading()).toBe(false);

    mockBasicInfoService.loadNextPage.mockClear();
    cmp.rasLocked = false;
    cmp.manualLocked = false;
    cmp.onLoadMore();
    expect(mockBasicInfoService.loadNextPage).toHaveBeenCalledTimes(1);
  });

  it('pagination and locks', () => {
    const { cmp } = createCmp();

    mockBasicInfoService.page$ = new BehaviorSubject(1);
    mockBasicInfoService.getCurrentPage.mockReturnValue(1);
    mockBasicInfoService.loadNextPage.mockClear();
    cmp.onChangePage(2);
    expect(mockBasicInfoService.loadNextPage).toHaveBeenCalledTimes(1);
    expect(cmp.lastProcessedPage).toBe(2);

    mockBasicInfoService.loadNextPage.mockClear();
    mockBasicInfoService.getCurrentPage.mockReturnValue(1);
    cmp.onChangePage(2);
    expect(mockBasicInfoService.loadNextPage).not.toHaveBeenCalled();

    mockBasicInfoService.loadNextPage.mockClear();
    mockBasicInfoService.page$ = new BehaviorSubject(2);
    mockBasicInfoService.getCurrentPage.mockReturnValue(2);
    cmp.lastProcessedPage = 0;
    cmp.onChangePage(2);
    expect(mockBasicInfoService.loadNextPage).toHaveBeenCalledTimes(1);
    expect(cmp.lastProcessedPage).toBe(3);

    mockBasicInfoService.loadNextPage.mockClear();
    mockBasicInfoService.page$ = new BehaviorSubject(3);
    mockBasicInfoService.getCurrentPage.mockReturnValue(3);
    cmp.lastProcessedPage = 0;
    cmp.onChangePage('2' as any);
    expect(mockBasicInfoService.loadNextPage).toHaveBeenCalledTimes(1);

    cmp.rasLocked = true;
    cmp.onChangePageSize(24);
    expect(mockBasicInfoService.changePageSize).not.toHaveBeenCalled();
    cmp.rasLocked = false;
    cmp.manualLocked = false;
    cmp.onChangePageSize(24);
    expect(mockBasicInfoService.changePageSize).toHaveBeenCalledWith(24);

    cmp.page$ = new BehaviorSubject(3);
    cmp.rasLocked = false;
    cmp.manualLocked = false;
    cmp.onPrevPage();
    expect(mockBasicInfoService.changePage).toHaveBeenCalledWith(2);
    mockBasicInfoService.changePage.mockClear();
    cmp.page$ = new BehaviorSubject(1);
    cmp.onPrevPage();
    expect(mockBasicInfoService.changePage).not.toHaveBeenCalled();

    cmp.page$ = new BehaviorSubject(1);
    cmp.totalCount = 24;
    cmp.onNextPage();
    expect(mockBasicInfoService.changePage).toHaveBeenCalledWith(2);
    mockBasicInfoService.changePage.mockClear();
    cmp.page$ = new BehaviorSubject(2);
    cmp.totalCount = 24;
    cmp.onNextPage();
    expect(mockBasicInfoService.changePage).not.toHaveBeenCalled();

    mockBasicInfoService.changePage.mockClear();
    cmp.rasLocked = true;
    cmp.onNextPage();
    expect(mockBasicInfoService.changePage).not.toHaveBeenCalled();
    cmp.rasLocked = false;
    cmp.manualLocked = true;
    cmp.onNextPage();
    expect(mockBasicInfoService.changePage).not.toHaveBeenCalled();

    mockBasicInfoService.loadNextPage.mockClear();
    cmp.rasLocked = true;
    cmp.manualLocked = false;
    cmp.onLoadMore();
    expect(mockBasicInfoService.loadNextPage).not.toHaveBeenCalled();
    cmp.rasLocked = false;
    cmp.manualLocked = true;
    cmp.onLoadMore();
    expect(mockBasicInfoService.loadNextPage).not.toHaveBeenCalled();
  });

  it('selection and removals', () => {
    const { cmp } = createCmp();
    cmp.rasLocked = true;
    cmp.onSelect({ id: '1' } as any);
    expect(mockBasicInfoService.selectContrato).not.toHaveBeenCalled();
    cmp.rasLocked = false;
    cmp.onSelect({ id: '1' } as any);
    expect(cmp.manualLocked).toBe(true);
    expect(cmp.manualContratos.length).toBe(1);

    cmp.rasLocked = true;
    cmp.rasContratos = [{ id: 'x' }];
    cmp.dealRASStatus = 'OK';
    cmp.onExcluirRAS();
    expect(cmp.rasLocked).toBe(false);
    expect(cmp.rasContratos).toEqual([]);
    expect(cmp.dealRASStatus).toBe('-');

    cmp.manualLocked = true;
    cmp.manualContratos = [{ id: 'x' }];
    cmp.onExcluirSelecionado();
    expect(cmp.manualLocked).toBe(false);
    expect(cmp.manualContratos).toEqual([]);
    expect(mockBasicInfoService.clearSelection).toHaveBeenCalled();
  });

  it('applyRAS with valid id and trim', async () => {
    const { cmp } = createCmp();
    cmp.dealRAS = '  XYZ  ';
    cmp.manualLocked = false;
    mockGetDealRasService.getDealRas.mockReturnValue(of({} as any));
    cmp.applyRAS();
    await Promise.resolve();
    expect(mockGetDealRasService.getDealRas).toHaveBeenCalledWith('XYZ');
  });

  it('apply/confirm/cancel RAS', () => {
    const { cmp } = createCmp();
    cmp.dealRAS = '';
    cmp.applyRAS();
    expect(cmp.dealRASStatus).toBe('Enter the Deal RAS');

    cmp.dealRAS = 'ABC123';
    cmp.manualLocked = true;
    cmp.applyRAS();
    expect(cmp.showConfirmRas).toBe(true);

    cmp.dealRAS = '';
    cmp.showConfirmRas = true;
    cmp.confirmApplyRAS();
    expect(cmp.showConfirmRas).toBe(false);

    const res: any = {
      DisbursementDate: '2024-01-20T00:00:00Z',
      MaturityDate: '2024-12-05T00:00:00Z',
      NewContract: 'NC001',
    };
    mockGetDealRasService.getDealRas.mockReturnValue(of(res));
    cmp.dealRAS = 'ABC123';
    cmp.manualLocked = true;
    cmp.manualContratos = [{ id: 'x' }];
    cmp.showConfirmRas = true;
    cmp.confirmApplyRAS();
    expect(cmp.showConfirmRas).toBe(false);
    expect(cmp.manualLocked).toBe(false);
    expect(cmp.manualContratos).toEqual([]);
    expect(mockBasicInfoService.clearSelection).toHaveBeenCalled();

    cmp.showConfirmRas = true;
    cmp.cancelApplyRAS();
    expect(cmp.showConfirmRas).toBe(false);
  });

  it('performApplyRAS success and error', async () => {
    const { cmp } = createCmp();

    const res: any = {
      DisbursementDate: '2024-01-20T00:00:00Z',
      MaturityDate: '2024-12-05T00:00:00Z',
      NewContract: 'NC001',
      ProductCanonical: 'ProdutoX',
    };
    mockGetDealRasService.getDealRas.mockReturnValue(of(res));

    cmp.performApplyRAS('ABC123');
    await new Promise(resolve => setTimeout(resolve, 10));

    expect(cmp.rasLocked).toBe(true);
    expect(cmp.manualLocked).toBe(false);
    expect((cmp.rasContratos || []).length).toBe(1);
    expect(cmp.dealRASStatus).toBe('OK');
    expect(mockBasicInfoService.clearSelection).toHaveBeenCalled();
    expect(mockBasicInfoService.resetList).toHaveBeenCalled();

    mockGetDealRasService.getDealRas.mockReturnValue(throwError(() => new Error('x')));
    cmp.performApplyRAS('ABC123');
    await new Promise(r => setTimeout(r, 10));
    expect(cmp.dealRASStatus).toBe('Error fetching');
  });

  it('reseta paginação quando contratos$ passa de não-vazio para vazio', async () => {
    vi.useFakeTimers();
    const { cmp } = createCmp();
    cmp.rasLocked = false;
    cmp.manualLocked = false;

    // Emite não-vazio e depois vazio
    mockBasicInfoService.contratos$.next([{ id: '1' }]);
    mockBasicInfoService.contratos$.next([]);

    // Deve alternar para 'numbered' imediatamente
    expect(cmp.paginationMode).toBe('numbered');

    // Após o setTimeout, volta para 'infinite'
    vi.runAllTimers();
    expect(cmp.paginationMode).toBe('infinite');
    vi.useRealTimers();
  });

  it('formatIsoToInput cobre nulo, sentinela e isNaN', () => {
    const { cmp } = createCmp();
    expect(cmp.formatIsoToInput(null)).toBe('');
    expect(cmp.formatIsoToInput('0001-01-01T00:00:00Z')).toBe('');
    expect(cmp.formatIsoToInput('not a date')).toBe('');
    // também cobre um caso válido
    expect(cmp.formatIsoToInput('2024-02-10T03:04:05Z')).toBe('2024-02-10');
  });

  it('formatIsoToInput cobre ramo else (não-string)', () => {
    const { cmp } = createCmp();
    // true é não-string e vira "true"; new Date('true') é inválido => ''
    expect(cmp.formatIsoToInput(true as any)).toBe('');
  });

  it('toggleShowRAS toggles and resets locks', () => {
    const { cmp } = createCmp();
    cmp.toggleShowRAS({ target: { checked: true } } as any);
    expect(cmp.showras).toBe(true);
    cmp.rasLocked = true;
    cmp.dealRASStatus = 'OK';
    cmp.toggleShowRAS({ target: { checked: false } } as any);
    expect(cmp.showras).toBe(false);
    expect(cmp.rasLocked).toBe(false);
    expect(cmp.dealRASStatus).toBe('-');
  });

  it('search/clear respects locks and parameters', () => {
    const { cmp } = createCmp();
    vi.clearAllMocks();

    cmp.rasLocked = true;
    cmp.onBuscar();
    expect(mockBasicInfoService.searchContratos).not.toHaveBeenCalled();

    vi.clearAllMocks();
    cmp.rasLocked = false;
    cmp.searchText = 'termo';
    cmp.onlyNotLinked = true;
    cmp.onBuscar();
    expect(mockBasicInfoService.searchContratos).toHaveBeenCalledWith('termo', true, 1, 12);

    vi.clearAllMocks();
    cmp.rasLocked = true;
    cmp.searchText = 'x';
    cmp.clearSearch();
    expect(cmp.searchText).toBe('x');

    vi.clearAllMocks();
    cmp.rasLocked = false;
    cmp.onlyNotLinked = true;
    cmp.clearSearch();
    expect(cmp.searchText).toBe('');
    expect(cmp.onlyNotLinked).toBe(false);
    expect(mockBasicInfoService.searchContratos).toHaveBeenCalledWith('', false, 1, 12);
  });

  it.each([
    [{ NewContract: '   ', BaseContract: 'BCX' }, (c: any) => c.chave === 'BCX'],
    [{ NewContract: '', BaseContract: '', Account: 'ACCX' }, (c: any) => c.chave === 'ACCX'],
  ])('mapDealRasToContrato key by priority', (res: any, check: (c: any) => boolean) => {
    const { cmp } = createCmp();
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(check(c)).toBe(true);
  });

  it('mapDealRasToContrato key uses dealRAS when previous are null', () => {
    const { cmp } = createCmp();
    (cmp as any).dealRAS = 'DRS1';
    const res: any = { NewContract: null, BaseContract: null, Account: null };
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(c.chave).toBe('DRS1');
  });

  it.each([
    [{ ProductCanonical: 'OperX' }, (c: any) => c.operacao === 'OperX'],
    [
      { ProductCanonical: '   ', UseOfProceedsCanonical: 'UOPX' },
      (c: any) => c.operacao === 'UOPX',
    ],
    [
      { ProductCanonical: '', UseOfProceedsCanonical: '', Book: 'BKX' },
      (c: any) => c.operacao === 'BKX',
    ],
    [{ ProductCanonical: '', Book: 'BKX' }, (c: any) => c.operacao === 'BKX'],
  ])('mapDealRasToContrato operation by priority', (res: any, check: (c: any) => boolean) => {
    const { cmp } = createCmp();
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(check(c)).toBe(true);
  });

  it('mapDealRasToContrato id uses ras-DRS-ID when dealRAS is filled', () => {
    const { cmp } = createCmp();
    (cmp as any).dealRAS = 'DRS-ID';
    const res: any = { NewContract: null, BaseContract: null, Account: null };
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(c.id).toBe('ras-DRS-ID');
  });

  it("mapDealRasToContrato id uses 'ras-unk' when dealRAS is empty", () => {
    const { cmp } = createCmp();
    (cmp as any).dealRAS = '';
    const res: any = { NewContract: null, BaseContract: null, Account: null };
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(c.id).toBe('ras-unk');
  });

  it('mapDealRasToContrato key uses "-" when dealRAS is undefined', () => {
    const { cmp } = createCmp();
    (cmp as any).dealRAS = undefined;
    const res: any = { NewContract: null, BaseContract: null, Account: null };
    const c = (cmp as any).mapDealRasToContrato(res);
    expect(c.chave).toBe('-');
  });

  it('mapDealRasToContrato fallback when all are null', () => {
    const { cmp } = createCmp();
    cmp.dealRAS = '';
    const res: any = {
      NewContract: null,
      BaseContract: null,
      Account: null,
      ProductCanonical: null,
      UseOfProceedsCanonical: null,
      Book: null,
    };
    const contrato = cmp.mapDealRasToContrato(res);
    expect(contrato.chave).toBe('-');
    expect(contrato.operacao).toBe('-');
  });

  it.each([null, undefined])(
    'confirmApplyRAS returns early when dealRAS is invalid: %s',
    (val: any) => {
      const { cmp } = createCmp();
      (cmp as any).dealRAS = val;
      cmp.showConfirmRas = true;
      mockGetDealRasService.getDealRas.mockClear();
      cmp.confirmApplyRAS();
      expect(cmp.dealRASStatus).toBe('Enter the Deal RAS');
      expect(cmp.showConfirmRas).toBe(false);
      expect(mockGetDealRasService.getDealRas).not.toHaveBeenCalled();
    },
  );

  it('formatIsoToInput covers valid dates and sentinels', () => {
    const { cmp } = createCmp();
    expect(cmp.formatIsoToInput('2024-02-29T12:34:56Z')).toBe('2024-02-29');
    expect(cmp.formatIsoToInput('0001-01-01T00:00:00Z')).toBe('');
    expect(cmp.formatIsoToInput('not-a-date' as any)).toBe('');
    expect(cmp.formatIsoToInput(null as any)).toBe('');
  });

  it('formatIsoToInput catches via invalid Date', () => {
    const { cmp } = createCmp();
    const OriginalDate = Date;
    (globalThis as { Date: typeof Date }).Date = class extends OriginalDate {
      constructor(arg?: unknown) {
        if (arg === 'invalid-date-format') throw new Error('Invalid date');
        super(arg as string);
      }
    } as unknown as typeof Date;
    expect(cmp.formatIsoToInput('invalid-date-format' as any)).toBe('');
    global.Date = OriginalDate as any;
  });

  it.each([
    [true, false],
    [false, true],
  ])('onPrevPage respects locks', (rasLocked: boolean, manualLocked: boolean) => {
    const { cmp } = createCmp();
    cmp.page$ = new BehaviorSubject(3);
    cmp.rasLocked = rasLocked;
    cmp.manualLocked = manualLocked;
    mockBasicInfoService.changePage.mockClear();
    cmp.onPrevPage();
    expect(mockBasicInfoService.changePage).not.toHaveBeenCalled();
  });

  it.each([
    [true, false],
    [false, true],
  ])('onChangePage respects locks', (rasLocked: boolean, manualLocked: boolean) => {
    const { cmp } = createCmp();
    cmp.rasLocked = rasLocked;
    cmp.manualLocked = manualLocked;
    mockBasicInfoService.loadNextPage.mockClear();
    cmp.onChangePage(2);
    expect(mockBasicInfoService.loadNextPage).not.toHaveBeenCalled();
  });
});
