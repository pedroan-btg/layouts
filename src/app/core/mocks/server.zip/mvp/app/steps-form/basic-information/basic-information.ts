import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  Validators,
  FormGroup,
} from '@angular/forms';
import { Table, TableColumn } from 'fts-frontui/table';
import { Loading } from 'fts-frontui/loading';
import { i18n } from 'fts-frontui/i18n';
import { Input } from 'fts-frontui/input';
import { Select } from 'fts-frontui/select';
import { Selection } from 'fts-frontui/selection';
import { BasicInformationService } from './services/basic-information-service';
import { GetDealRasService } from './services/get-deal-ras';
import { DealRasResponse, Contrato } from './models';
import { formatIsoToInput as formatIsoToInputUtil } from './utils/date-formatter';
import { mapDealRasToContrato as mapDealRasToContratoUtil } from './utils/deal-ras-mapper';
import { performApplyRas } from './utils/ras-apply';
import {
  resetRasLockState,
  resetAllState,
  handleSelect,
  changePage,
  changePageSize,
  loadMore,
  prevPage,
  nextPage,
} from './utils/state-helpers';

@Component({
  selector: '[fts-basic-info]',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    i18n,
    Table,
    TableColumn,
    Loading,
    Input,
    Select,
    Selection,
  ],
  templateUrl: './basic-information.html',
})
export class BasicInformation {
  public readonly svc = inject(BasicInformationService);
  private readonly fb = inject(FormBuilder);
  public readonly dealRasSvc = inject(GetDealRasService);
  isLoading = signal(false);
  rasLoading = signal(false);
  showras = false;

  private currentCount = 0;
  public totalCount = 0;

  public dealRAS: string | null | undefined = '';
  public dealRASStatus = '-';
  public searchText = '';
  public onlyNotLinked = false;

  public rasLocked = false;
  public manualLocked = false;
  public manualContratos: Contrato[] = [];
  public rasContratos: Contrato[] = [];
  public showConfirmRas = false;

  public readonly contratos$ = this.svc.contratos$;
  public readonly total$ = this.svc.total$;
  public readonly page$ = this.svc.page$;
  public readonly pageSize$ = this.svc.pageSize$;
  public readonly selected$ = this.svc.selectedContrato$;
  public readonly loading$ = this.svc.loading$;

  // Controla o modo de paginação do componente de tabela (infinite/numbered)
  public paginationMode: 'infinite' | 'numbered' = 'infinite';

  public readonly form = this.fb.group({
    dataContrato: ['', [Validators.required]],
    dataInicioVigencia: ['', [Validators.required]],
    tipoBaixa: [null as unknown, [Validators.required]],
  });

  public readonly dealRasForm!: FormGroup;
  public readonly searchForm!: FormGroup;
  public readonly uiForm!: FormGroup;

  public readonly tiposBaixa = this.svc.tiposBaixa;

  private lastSelected: Contrato | null = null;

  public debugState(_label?: string): void {
    return;
  }

  constructor() {
    // Campos do formulário devem permanecer sempre editáveis
    this.form.enable({ emitEvent: false });

    // Inicializa formulários auxiliares
    this.dealRasForm = this.fb.group({
      dealRAS: [''],
    });
    this.searchForm = this.fb.group({
      searchText: [''],
    });
    // Form de UI para componentes de seleção (checkboxes)
    this.uiForm = this.fb.group({
      showras: [this.showras],
      onlyNotLinked: [this.onlyNotLinked],
    });

    // Mantém propriedades existentes sincronizadas com os controles
    this.uiForm.get('showras')?.valueChanges.subscribe((val: boolean) => {
      this.showras = !!val;

      if (!this.showras) {
        resetRasLockState(this);
        this.rasLoading.set(false);
      }

      this.debugState('ACTION toggleShowRAS');
    });
    this.uiForm.get('onlyNotLinked')?.valueChanges.subscribe((val: boolean) => {
      this.onlyNotLinked = !!val;
    });

    this.contratos$.subscribe(contratos => {
      const prevCount = this.currentCount;
      this.currentCount = contratos?.length || 0;
      this.debugState('contratos$ emit');

      // Se havia itens e agora está vazio, forçamos um reset do grid
      // alternando para paginação 'numbered' (que limpa caches internos)
      if (!this.rasLocked && !this.manualLocked && prevCount > 0 && this.currentCount === 0) {
        this.paginationMode = 'numbered';
        setTimeout(() => (this.paginationMode = 'infinite'));
      }
    });

    this.total$.subscribe(total => {
      this.totalCount = total || 0;
    });

    this.loading$.subscribe(isLoading => {
      this.isLoading.set(!!isLoading);
    });

    this.selected$.subscribe(sel => {
      this.lastSelected = sel;
      this.updateUiDisabled();
    });
  }

  onBuscar(): void {
    if (this.rasLocked || this.manualLocked) return;

    const text = (this.searchForm.get('searchText')?.value as string | null | undefined) ?? '';
    this.svc.searchContratos(text, this.onlyNotLinked, 1, 12);
    this.debugState('ACTION onBuscar');
  }

  clearSearch(): void {
    if (this.rasLocked || this.manualLocked) return;

    this.searchForm.reset({ searchText: '' }, { emitEvent: false });
    this.onlyNotLinked = false;
    this.svc.searchContratos('', this.onlyNotLinked, 1, 12);
    this.debugState('ACTION clearSearch');
  }

  toggleShowRAS(event: Event): void {
    const input = event.target as HTMLInputElement | null;
    this.showras = !!input?.checked;

    if (!this.showras) {
      resetRasLockState(this);
      this.rasLoading.set(false);
    }

    this.debugState('ACTION toggleShowRAS');
  }

  private formatIsoToInput = (iso: string | null | undefined): string => formatIsoToInputUtil(iso);

  private mapDealRasToContrato = (res: DealRasResponse): Contrato =>
    mapDealRasToContratoUtil(
      (this.dealRasForm.get('dealRAS')?.value as string | null | undefined) ?? '',
      res,
    );

  applyRAS(): void {
    const dealRAS = (this.dealRasForm.get('dealRAS')?.value as string | null | undefined)?.trim();

    if (!dealRAS) {
      this.dealRASStatus = 'Enter the Deal RAS';

      return;
    }

    if (this.manualLocked) {
      this.showConfirmRas = true;

      return;
    }

    this.performApplyRAS(dealRAS);
    this.debugState('ACTION applyRAS');
  }

  confirmApplyRAS(): void {
    const id = ((this.dealRasForm.get('dealRAS')?.value as string | null | undefined) ?? '').trim();

    if (!id) {
      this.dealRASStatus = 'Enter the Deal RAS';
      this.showConfirmRas = false;

      return;
    }

    this.onExcluirSelecionado();
    this.showConfirmRas = false;
    this.performApplyRAS(id);
    this.debugState('ACTION confirmApplyRAS');
  }

  cancelApplyRAS(): void {
    this.showConfirmRas = false;
  }

  private performApplyRAS(id: string): void {
    performApplyRas(this, id);
  }

  public lastProcessedPage = 0;

  onChangePage(): void {
    changePage(this);
  }

  onChangePageSize(size: number): void {
    changePageSize(this, size);
  }

  onLoadMore(): void {
    loadMore(this);
  }

  onSelect(row: Contrato): void {
    handleSelect(this, row);
  }

  onPrevPage(): void {
    prevPage(this);
  }

  onNextPage(): void {
    nextPage(this);
  }

  onExcluirRAS(): void {
    // Mantido para compatibilidade; delega para o handler unificado
    this.onExcluir();
  }

  onExcluirSelecionado(): void {
    // Mantido para compatibilidade; delega para o handler unificado
    this.onExcluir();
  }

  // resetRASLock movido para utils/state-helpers.ts

  /**
   * Reset total do estado, retornando a tela ao estado inicial.
   * Limpa seleção, filtros, listas, formulário e caches de paginação.
   */
  // resetAll movido para utils/state-helpers.ts

  /**
   * Handler único de exclusão que atua conforme o contexto atual (RAS ou Manual)
   * e garante que a tabela volte ao estado inicial vazio.
   */
  onExcluir(): void {
    this.debugState('ACTION onExcluir (before)');
    // Comportamento único: reseta toda a tela independentemente do contexto
    resetAllState(this);
    this.updateUiDisabled();
    this.debugState('STATE after onExcluir (initial screen)');
  }

  private updateUiDisabled(): void {
    const disable = this.rasLocked || this.manualLocked;
    const ctl = this.uiForm.get('onlyNotLinked');

    if (!ctl) return;

    if (disable) {
      if (!ctl.disabled) ctl.disable({ emitEvent: false });
    } else {
      if (ctl.disabled) ctl.enable({ emitEvent: false });
    }
  }
}
