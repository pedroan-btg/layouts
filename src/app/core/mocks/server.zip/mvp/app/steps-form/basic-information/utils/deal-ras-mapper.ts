import type { DealRasResponse, Contrato } from '../models';

export function mapDealRasToContrato(
  dealRAS: string | null | undefined,
  res: DealRasResponse,
): Contrato {
  const deal = String(dealRAS ?? '').trim();
  const chave =
    res?.NewContract?.trim() || res?.BaseContract?.trim() || res?.Account?.trim() || deal || '-';

  const operacao =
    res?.ProductCanonical?.trim() ||
    res?.UseOfProceedsCanonical?.trim() ||
    res?.Book?.trim() ||
    '-';

  return {
    id: `ras-${deal || 'unk'}`,
    chave,
    operacao,
    vinculoTrade: 'Não vinculado',
    acao: 'Excluir',
  };
}
