import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: '[fts-document]',
  imports: [],
  templateUrl: './document.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Document {}
