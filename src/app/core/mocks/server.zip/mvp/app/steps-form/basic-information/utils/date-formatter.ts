export function formatIsoToInput(iso: string | null | undefined): string {
  if (iso == null) return '';

  const value = typeof iso === 'string' ? iso : String(iso);

  if (value.startsWith('0001-01-01')) return '';

  try {
    const d = new Date(value);

    if (isNaN(d.getTime())) return '';

    const yyyy = d.getUTCFullYear();
    const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
    const dd = String(d.getUTCDate()).padStart(2, '0');

    return `${yyyy}-${mm}-${dd}`;
  } catch {
    return '';
  }
}
