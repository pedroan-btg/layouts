import { Component } from '@angular/core';
import { vitest } from 'vitest';

vitest.mock('fts-frontui/table', () => ({
  Table: Component({
    selector: 'fts-table',
    standalone: true,
    template: '<div><ng-content></ng-content></div>',
  })(class {}),
  TableColumn: Component({
    selector: 'fts-table-column',
    standalone: true,
    template: '<div><ng-content></ng-content></div>',
  })(class {}),
}));

vitest.mock('fts-frontui/loading', () => ({
  Loading: Component({
    selector: 'fts-loading',
    standalone: true,
    template: '<div></div>',
  })(class {}),
}));

vitest.mock('fts-frontui/i18n', () => ({
  i18n: Component({
    selector: 'fts-i18n',
    standalone: true,
    template: '<div><ng-content></ng-content></div>',
  })(class {}),
}));

vitest.mock('./services/basic-information-service', () => ({
  BasicInformationService: class {},
}));

vitest.mock('./services/get-deal-ras', () => ({
  GetDealRasService: class {},
}));

import { BasicInformationService } from './services/basic-information-service';
import { GetDealRasService } from './services/get-deal-ras';
void BasicInformationService;
void GetDealRasService;
