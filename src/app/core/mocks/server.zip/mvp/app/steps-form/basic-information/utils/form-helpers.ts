import type { DealRasResponse } from '../models';
import type { FormGroup } from '@angular/forms';

export function applyRasToForm(
  form: FormGroup,
  res: DealRasResponse,
  formatIsoToInput: (iso: string | null | undefined) => string,
): void {
  const disp = formatIsoToInput(res?.DisbursementDate);
  const mat = formatIsoToInput(res?.MaturityDate);

  form.patchValue({
    dataInicioVigencia: disp,
    dataContrato: mat,
  });
}
