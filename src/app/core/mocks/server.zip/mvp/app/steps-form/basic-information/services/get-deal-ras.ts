import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { DealRas, DealRasResponse } from '../models';

@Injectable({ providedIn: 'any' })
export class GetDealRasService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl =
    'https://webapp-ras-uat/API/CreditRisk/RAS/RAS-API/External/core/workflow/deals/';

  getDealRas(dealRAS: string | number): Observable<DealRasResponse> {
    const id = String(dealRAS).trim();
    const url = `${this.baseUrl}/${encodeURIComponent(id)}?username=ras_system`;

    return this.http.get<DealRas>(url).pipe(
      map(
        (res: DealRas): DealRasResponse => ({
          ...res,
          status: res?.DealStatus?.Description ?? 'OK',
        }),
      ),
    );
  }
}
