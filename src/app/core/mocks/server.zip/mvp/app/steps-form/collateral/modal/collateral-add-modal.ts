import {
  Component,
  EventEmitter,
  Input,
  Output,
  inject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Select as FtsSelect } from 'fts-frontui/select';
import { Input as FtsInput } from 'fts-frontui/input';
import { DynamicFormComponent } from '../../../dynamic-form/dynamic-form.component';
import { CollateralModalApi } from './api';
import type { CollateralPayload } from '../models';
import type { VinculoProdutoGarantia, Option } from './api';
import { forkJoin, tap } from 'rxjs';
import type { DynamicFormSchema } from '../../../dynamic-form/types';

@Component({
  selector: '[fts-collateral-add-modal]',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, FtsSelect, FtsInput, DynamicFormComponent],
  templateUrl: './collateral-add-modal.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CollateralAddModal implements OnChanges {
  @Input() open = false;
  @Input() collateralTypes: { label: string; value: string }[] = [];
  @Output() save = new EventEmitter<CollateralPayload>();
  @Output() closed = new EventEmitter<void>();

  private readonly fb = inject(FormBuilder);
  private readonly api = inject(CollateralModalApi);
  private readonly ref = inject(ChangeDetectorRef);

  markets: { label: string; value: string }[] = [];
  types: Option[] = [];
  subtypes: Option[] = [];
  assets: Option[] = [];
  linkOptions: { label: string; value: string; raw: VinculoProdutoGarantia }[] = [];
  schema: DynamicFormSchema | null = null;
  fetchClients = (query: string) => {
    console.log('Buscar clientes:', query);
    return this.api.getCollateralClients(query).pipe(tap(rows => console.log('Clientes response:', rows)));
  };

  readonly form = this.fb.group({
    marketId: [null as unknown],
    collateralTypeId: [{ value: null as unknown, disabled: true }],
    searchText: [''],
  });

  constructor() {
    this.api.getMarkets().subscribe(arr => {
      this.markets = arr;
      this.ref.markForCheck();
    });

    this.form.get('marketId')?.valueChanges.subscribe(marketId => {
      const hasMarket = !!marketId;
      const typeCtrl = this.form.get('collateralTypeId');

      if (hasMarket) typeCtrl?.enable();
      else typeCtrl?.disable();

      typeCtrl?.reset(null);
      this.schema = null;

      if (!hasMarket) {
        this.types = [];
        this.subtypes = [];
        this.assets = [];
        this.linkOptions = [];
        this.schema = null;
        this.ref.markForCheck();

        return;
      }

      const m = String(marketId);
      forkJoin({
        types: this.api.getCollateralTypes(m),
        subtypes: this.api.getCollateralSubtypes(m),
        assets: this.api.getAssets(m),
        links: this.api.getFinancialAssets(0, 12, m),
      }).subscribe(({ types, subtypes, assets, links }) => {
        this.types = types;
        this.subtypes = subtypes;
        this.assets = assets;
        const rows = links.rows ?? [];
        this.linkOptions = rows.map(r => {
          const tipo = this.labelForId(types, r.tipoGarantiaId);
          const subtipo = this.labelForId(subtypes, r.subtipoGarantiaId);
          const ativo = this.labelForId(assets, r.ativoId);
          const especifico = r.formType ? ` / ${r.formType}` : '';
          let custodia = '';
          if (r.custodiaBTG !== null) {
            custodia = r.custodiaBTG ? ' - Com custódia BTG' : ' - Sem custódia BTG';
          }

          return {
            label: `${tipo} / ${subtipo} / ${ativo}${especifico}${custodia}`.trim(),
            value: r.id,
            raw: r,
          };
        });
        this.ref.markForCheck();
      });
    });

    this.form.get('collateralTypeId')?.valueChanges.subscribe(selectedId => {
      const idStr = String(selectedId ?? '');
      const opt = this.linkOptions.find(o => o.value === idStr) || null;
      const formId = opt ? Number(opt.raw?.formId ?? 0) : 0;
      if (!formId) {
        this.schema = null;
        this.ref.markForCheck();
        return;
      }
      this.api.getSchemaById(formId).subscribe(schema => {
        this.schema = schema || null;
        this.ref.markForCheck();
      });
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open === true) {
      this.form.reset({ marketId: null, collateralTypeId: null });
      this.schema = null;
      this.ref.markForCheck();
    }
  }

  labelForId(arr: Option[], id: string): string {
    const f = arr.find(x => x.value === id);

    return f ? f.label : id;
  }

  onClose(): void {
    this.form.reset({ marketId: null, collateralTypeId: null });
    this.schema = null;
    this.ref.markForCheck();

    this.closed.emit();
  }

  onSave(): void {
    if (this.form.invalid) return;

    const payload: CollateralPayload = {
      type: '',
      tickerOrName: '',
      guarantor: '',
      account: '',
      linked: false,
      unitPrice: 0,
      allocatedQuantity: 0,
      value: 0,
      lendingValue: 0,
      issuer: '',
      isinCode: '',
      assetCode: '',
    };
    this.save.emit(payload);

    this.form.reset({ marketId: null, collateralTypeId: null });
    this.schema = null;
    this.ref.markForCheck();
  }
}
