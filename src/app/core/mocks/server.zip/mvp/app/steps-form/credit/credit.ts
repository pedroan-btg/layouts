import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: '[fts-credit]',
  imports: [],
  templateUrl: './credit.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Credit {}
