import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock todas as dependências do Angular e do projeto
vi.mock('@angular/common', () => ({
  CommonModule: class {},
}));
vi.mock('fts-frontui/i18n', () => ({
  i18n: class {},
}));
vi.mock('../widgets/stepper/directives/stepper-next.directive', () => ({
  StepperNextDirective: class {},
}));
vi.mock('../widgets/stepper/directives/stepper-prev.directive', () => ({
  StepperPrevDirective: class {},
}));
vi.mock('@angular/router', () => ({
  RouterModule: class {},
}));
vi.mock('../widgets/stepper/stepper.module', () => ({
  StepperModule: class {},
}));

// Mock dos imports dinâmicos
vi.mock('./basic-information/basic-information', () => ({
  BasicInformation: class {},
}));
vi.mock('./collateral/collateral', () => ({
  Collateral: class {},
}));
vi.mock('./credit/credit', () => ({
  Credit: class {},
}));
vi.mock('./review/review', () => ({
  Review: class {},
}));
vi.mock('./document/document', () => ({
  Document: class {},
}));

import { StepsForm } from './form';

describe('StepsForm (isolated)', () => {
  let component: StepsForm;

  beforeEach(() => {
    component = new StepsForm();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have loadBasicInformationLazy defined', () => {
    expect(component.loadBasicInformationLazy).toBeInstanceOf(Function);
  });

  it('should have loadCollateralLazy defined', () => {
    expect(component.loadCollateralLazy).toBeInstanceOf(Function);
  });

  it('should have loadCreditsLazy defined', () => {
    expect(component.loadCreditsLazy).toBeInstanceOf(Function);
  });

  it('should have loadReviewLazy defined', () => {
    expect(component.loadReviewLazy).toBeInstanceOf(Function);
  });

  it('should have loadDocumentsLazy defined', () => {
    expect(component.loadDocumentsLazy).toBeInstanceOf(Function);
  });

  it('should resolve lazy loaders', async () => {
    expect(await component.loadBasicInformationLazy()).toBeInstanceOf(Object);
    expect(await component.loadCollateralLazy()).toBeInstanceOf(Object);
    expect(await component.loadCreditsLazy()).toBeInstanceOf(Object);
    expect(await component.loadReviewLazy()).toBeInstanceOf(Object);
    expect(await component.loadDocumentsLazy()).toBeInstanceOf(Object);
  });
});
