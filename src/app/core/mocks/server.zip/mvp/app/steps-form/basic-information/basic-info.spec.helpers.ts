import { TestBed, ComponentFixture } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { ENV_CONFIG } from 'fts-frontui/env';
import { vi } from 'vitest';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BasicInformation } from './basic-information';
import { BasicInformationService } from './services/basic-information-service';
import { GetDealRasService } from './services/get-deal-ras';

export interface SetupCtx {
  mockBasicInfoService: {
    contratos$: BehaviorSubject<unknown[]>;
    total$: BehaviorSubject<number>;
    page$: BehaviorSubject<number>;
    pageSize$: BehaviorSubject<number>;
    selectedContrato$: BehaviorSubject<unknown>;
    loading$: BehaviorSubject<boolean>;
    tiposBaixa: { label: string; value: string }[];
    searchContratos: ReturnType<typeof vi.fn>;
    changePage: ReturnType<typeof vi.fn>;
    changePageSize: ReturnType<typeof vi.fn>;
    selectContrato: ReturnType<typeof vi.fn>;
    clearSelection: ReturnType<typeof vi.fn>;
    resetList: ReturnType<typeof vi.fn>;
    loadNextPage: ReturnType<typeof vi.fn>;
    getCurrentPage: ReturnType<typeof vi.fn>;
  };
  mockGetDealRasService: { getDealRas: ReturnType<typeof vi.fn> };
  createCmp: () => { fixture: unknown; cmp: unknown };
}

export async function setupBasicInfoTest(): Promise<SetupCtx> {
  const mockBasicInfoService: SetupCtx['mockBasicInfoService'] = {
    contratos$: new BehaviorSubject<unknown[]>([]),
    total$: new BehaviorSubject<number>(0),
    page$: new BehaviorSubject<number>(1),
    pageSize$: new BehaviorSubject<number>(12),
    selectedContrato$: new BehaviorSubject<unknown>(null),
    loading$: new BehaviorSubject<boolean>(false),
    tiposBaixa: [
      { label: 'Manual', value: 'manual' },
      { label: 'Automática', value: 'automatica' },
    ],
    searchContratos: vi.fn(),
    changePage: vi.fn(),
    changePageSize: vi.fn(),
    selectContrato: vi.fn(),
    clearSelection: vi.fn(),
    resetList: vi.fn(),
    loadNextPage: vi.fn(),
    getCurrentPage: vi.fn(() => mockBasicInfoService.page$.value),
  };
  const mockGetDealRasService: SetupCtx['mockGetDealRasService'] = {
    getDealRas: vi.fn(),
  };

  Object.defineProperty(window, 'IntersectionObserver', {
    writable: true,
    configurable: true,
    value: vi.fn(() => ({
      observe: vi.fn(),
      unobserve: vi.fn(),
      disconnect: vi.fn(),
    })),
  });

  const IO = (
    window as unknown as {
      IntersectionObserver: new (callback: IntersectionObserverCallback) => IntersectionObserver;
    }
  ).IntersectionObserver;
  const ioInstance = new IO(() => undefined);
  ioInstance.observe(document.createElement('div'));
  ioInstance.unobserve(document.createElement('div'));
  ioInstance.disconnect();

  await TestBed.configureTestingModule({
    imports: [
      ReactiveFormsModule,
      CommonModule,
      RouterModule.forRoot([{ path: 'basic-info', component: BasicInformation }]),
      NoopAnimationsModule,
      BasicInformation,
    ],
    providers: [
      FormBuilder,
      provideHttpClient(),
      provideHttpClientTesting(),
      { provide: BasicInformationService, useValue: mockBasicInfoService },
      { provide: GetDealRasService, useValue: mockGetDealRasService },
      {
        provide: ENV_CONFIG,
        useValue: { environment: 'test', version: '0.0.0', logDisabled: true },
      },
    ],
  })
    .overrideComponent(BasicInformation, {
      set: { schemas: [NO_ERRORS_SCHEMA] },
    })
    .overrideComponent(BasicInformation, {
      add: {
        providers: [{ provide: BasicInformationService, useValue: mockBasicInfoService }],
      },
    })
    .compileComponents();

  vi.clearAllMocks();

  function createCmp(): { fixture: unknown; cmp: unknown } {
    const fixture: ComponentFixture<BasicInformation> = TestBed.createComponent(BasicInformation);
    const cmp = fixture.componentInstance as unknown;
    Object.defineProperty(cmp as Record<string, unknown>, 'tableContainer', {
      value: { nativeElement: document.createElement('div') },
      configurable: true,
    });
    Object.defineProperty(cmp as Record<string, unknown>, 'infiniteSentinel', {
      value: { nativeElement: document.createElement('div') },
      configurable: true,
    });
    fixture.detectChanges();

    return { fixture, cmp };
  }

  return {
    mockBasicInfoService,
    mockGetDealRasService,
    createCmp,
  };
}
