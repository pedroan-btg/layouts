import type { WritableSignal } from '@angular/core';
import type { FormGroup } from '@angular/forms';
import type { Observable } from 'rxjs';
import type { BasicInformationService } from '../services/basic-information-service';
import type { Contrato } from '../models';

export interface BasicInfoCtx {
  rasLocked: boolean;
  manualLocked: boolean;
  rasContratos: Contrato[];
  manualContratos: Contrato[];
  dealRASStatus: string;
  dealRAS: string | null | undefined;
  rasLoading: WritableSignal<boolean>;
  searchText: string;
  onlyNotLinked: boolean;
  lastProcessedPage: number;
  paginationMode: 'infinite' | 'numbered';
  form: FormGroup;
  svc: BasicInformationService;
  page$: Observable<number>;
  totalCount: number;
  debugState: (label: string) => void;
}
