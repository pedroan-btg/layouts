import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable, tap } from 'rxjs';
import type { DynamicFormSchema } from '../../../dynamic-form/types';

export interface Option {
  label: string;
  value: string;
}

export interface VinculoProdutoGarantia {
  id: string;
  mercadoId: string;
  tipoGarantiaId: string;
  subtipoGarantiaId: string;
  ativoId: string;
  custodiaBTG: boolean | null;
  formType: string;
  formId: number;
  ordemPrioridade: number;
}

@Injectable({ providedIn: 'any' })
export class CollateralModalApi {
  private readonly http = inject(HttpClient);

  getMarkets(): Observable<Option[]> {
    return this.http
      .get<{
        statusCode: number;
        data: { rows: { id: string; name: string }[] };
      }>('/api/collateralmarkets')
      .pipe(map(resp => resp.data.rows.map(r => ({ label: r.name, value: r.id }))));
  }

  getCollateralTypes(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        statusCode: number;
        data: { rows: { id: string; name: string }[] };
      }>(`/api/collateraltypes?marketId=${encodeURIComponent(marketId)}`)
      .pipe(map(resp => resp.data.rows.map(r => ({ label: r.name, value: r.id }))));
  }

  getCollateralSubtypes(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        statusCode: number;
        data: { rows: { id: string; name: string }[] };
      }>(`/api/collateralsubtypes?marketId=${encodeURIComponent(marketId)}`)
      .pipe(map(resp => resp.data.rows.map(r => ({ label: r.name, value: r.id }))));
  }

  getAssets(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        statusCode: number;
        data: { rows: { id: string; name: string }[] };
      }>(`/api/collateralassets?marketId=${encodeURIComponent(marketId)}`)
      .pipe(map(resp => resp.data.rows.map(r => ({ label: r.name, value: r.id }))));
  }

  getFinancialAssets(
    page: number,
    limit: number,
    marketId?: string,
  ): Observable<{ rows: VinculoProdutoGarantia[]; total?: number }> {
    const search = new URLSearchParams({ page: String(page), limit: String(limit) });

    if (marketId) search.append('marketId', marketId);

    const url = `/api/financialasset?${search.toString()}`;

    return this.http
      .get<{ statusCode: number; data: { rows: VinculoProdutoGarantia[]; total?: number } }>(url)
      .pipe(map(resp => resp.data));
  }

  getFormsList(): Observable<Option[]> {
    return this.http
      .get<{ data: { rows: { id: number; type: string; name?: string; version?: string }[] } }>(
        '/api/dynamic-forms/schemas',
      )
      .pipe(
        map(response =>
          response.data.rows.map(row => ({
            label: row.type,
            value: String(row.id),
          })),
        ),
      );
  }

  getSchemaById(id: number): Observable<DynamicFormSchema> {
    return this.http.get<DynamicFormSchema>(`/api/dynamic-form-by-id/${id}`);
  }

  getCollateralClients(query: string): Observable<{
    clientId: string;
    fullName: string;
    documentType: 'CPF' | 'CNPJ';
    document: string;
  }[]> {
    const q = encodeURIComponent(query || '');
    return this.http
      .get<{ data: { rows: { clientId: string; fullName: string; documentType: 'CPF' | 'CNPJ'; document: string }[] } }>(
        `/api/collateral-clients?q=${q}`,
      )
      .pipe(
        tap(() => console.log('API /collateral-clients query:', query)),
        map(resp => resp.data.rows),
        tap(rows => console.log('API /collateral-clients result:', rows?.length)),
      );
  }
}
