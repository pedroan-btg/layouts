import type { Contrato } from '../models';
import type { BasicInfoCtx } from './types';

export function resetRasLockState(self: BasicInfoCtx): void {
  self.rasLocked = false;
  self.rasContratos = [];
  self.dealRASStatus = '-';
  self.dealRAS = '';

  if (typeof self.debugState === 'function') self.debugState('resetRASLock');
}

export function resetAllState(self: BasicInfoCtx): void {
  // Locks e listas
  self.rasLocked = false;
  self.manualLocked = false;
  self.rasContratos = [];
  self.manualContratos = [];

  // Estado do RAS e UI
  self.dealRASStatus = '-';
  self.dealRAS = '';
  self.rasLoading.set(false);

  // Filtros e paginação local
  self.searchText = '';
  self.onlyNotLinked = false;
  self.lastProcessedPage = 0;

  // Formulário
  self.form.reset(
    {
      dataContrato: '',
      dataInicioVigencia: '',
      tipoBaixa: null as unknown,
    },
    { emitEvent: false },
  );

  // Seleção e lista do serviço
  self.svc.clearSelection();
  const maybeSvc = self.svc as unknown as { resetList?: () => void };

  if (typeof maybeSvc.resetList === 'function') {
    maybeSvc.resetList();
  }

  // Força limpeza de caches internos do grid alterando o modo
  self.paginationMode = 'numbered';
  setTimeout(() => (self.paginationMode = 'infinite'));
}

export function handleSelect(self: BasicInfoCtx, row: Contrato): void {
  if (self.rasLocked) return;

  self.svc.selectContrato(row);
  self.manualLocked = true;
  self.manualContratos = [row];

  if (typeof self.debugState === 'function')
    self.debugState('STATE 3 after onSelect (manual locked)');
}

export function changePage(self: BasicInfoCtx): void {
  // Respeita locks apenas
  if (self.rasLocked || self.manualLocked) {
    return;
  }

  const currentPage = self.svc.getCurrentPage();
  const nextPage = currentPage + 1;

  if (self.lastProcessedPage === nextPage) {
    return;
  }

  self.lastProcessedPage = nextPage;
  self.svc.loadNextPage();
}

export function changePageSize(self: BasicInfoCtx, size: number): void {
  // Respeita locks apenas
  if (self.rasLocked || self.manualLocked) return;

  self.svc.changePageSize(Number(size));
}

export function loadMore(self: BasicInfoCtx): void {
  // Evita loadMore quando não há itens visíveis ou está bloqueado
  if (self.rasLocked || self.manualLocked) return;

  self.svc.loadNextPage();
}

export function prevPage(self: BasicInfoCtx): void {
  if (self.rasLocked || self.manualLocked) return;

  self.page$
    .subscribe((currentPage: number) => {
      if (currentPage > 1) {
        self.svc.changePage(currentPage - 1);
      }
    })
    .unsubscribe();
}

export function nextPage(self: BasicInfoCtx): void {
  if (self.rasLocked || self.manualLocked) return;

  self.page$
    .subscribe((currentPage: number) => {
      const nextPage = currentPage + 1;
      const maxPages = Math.ceil(self.totalCount / 12);

      if (nextPage <= maxPages) {
        self.svc.changePage(nextPage);
      }
    })
    .unsubscribe();
}
