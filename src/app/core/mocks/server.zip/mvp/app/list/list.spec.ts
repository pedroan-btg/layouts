import { ComponentFixture, TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vitest, vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { firstValueFrom, Observable, of } from 'rxjs';
import { ChangeDetectorRef, signal } from '@angular/core';
import type { FormGroup } from '@angular/forms';
import { StatusKeyPipe } from '../core/pipes/status-key.pipe';
import { TranslatePipe } from 'fts-frontui/i18n';

import { List } from './list';
import { CollateralApi } from './list.model';
import { Filter } from './filter';
import { Api } from './api';

vi.mock('./api', () => ({ Api: class {} }));
vi.mock('./filter', () => ({ Filter: class {} }));
vi.mock('./list.model', () => ({}));
vi.mock('../core/pipes/status-key.pipe', () => ({
  StatusKeyPipe: class {
    transform(value: unknown) {
      return value as any;
    }
  },
}));
vi.mock('../core/pipes/status-class.pipe', () => ({ StatusClassPipe: class {} }));

const getAllMock = vitest.fn(
  () =>
    of({ rows: undefined, total: 0 }) as Observable<{
      rows: CollateralApi[] | undefined;
      total: number;
    }>,
);
const mockFilter = { page: 2 } as any;

const filterMock = {
  next: vitest.fn(),
  setPage: vitest.fn(),
  onFilter: vitest.fn(),
  setup: vitest.fn(),
  clear: vitest.fn(),
  value: mockFilter,
  hasFilter: signal(false),
  filterChanges: of(true),
} as any as Filter;

const apiMock = {
  getAll: getAllMock,
} as any as Api;

describe('List', (): void => {
  let component: List;
  let componentPrivate: any;
  let fixture: ComponentFixture<List>;
  let ref: ChangeDetectorRef;

  beforeEach(async (): Promise<void> => {
    await TestBed.configureTestingModule({
      imports: [List],
      providers: [
        provideHttpClient(),
        provideRouter([]),
        { provide: Filter, useValue: filterMock },
        { provide: Api, useValue: apiMock },
        { provide: StatusKeyPipe, useValue: { transform: (value: unknown) => value } },
        {
          provide: TranslatePipe,
          useValue: { transform: (...args: unknown[]) => String(args[0]) },
        },
        {
          provide: ChangeDetectorRef,
          useValue: { markForCheck: vitest.fn(), detectChanges: vitest.fn() },
        },
      ],
    })
      .overrideComponent(List, {
        set: {
          template: '',
          providers: [],
          imports: [],
        },
      })
      .compileComponents();

    fixture = TestBed.createComponent(List);
    ref = fixture.debugElement.injector.get(ChangeDetectorRef);
    component = fixture.componentInstance;
    componentPrivate = component as any;
  });

  it('should create', (): void => {
    expect(component).toBeTruthy();
  });
  describe('ngOnInit', () => {
    it('should initialize core state without template side-effects', () => {
      componentPrivate.fetchEnums = vitest.fn();
      component.ngOnInit();
      expect(componentPrivate.form).toBeDefined();

      expect(filterMock.setup).toHaveBeenCalled();
      const args = (filterMock.setup as any).mock.calls[0][0] as {
        form: FormGroup;
        callback: () => void;
      };
      expect(args.form).toBe(componentPrivate.form);
      expect(typeof args.callback).toBe('function');

      args.callback();
      expect(componentPrivate.dataSource).toBeDefined();
    });
  });

  describe('loadData', () => {
    it('should call getAll with correct filter, update dataSource and markForCheck', async () => {
      const mockData = [
        {
          id: 1,
          contractKey: 'ABC-123',
          type: 'Orig',
          status: 'Orig' as any,
          createdDate: new Date(),
          contractDate: new Date(),
          createdBy: 'user',
        },
      ] as unknown as CollateralApi[];

      getAllMock.mockReturnValueOnce(of({ rows: mockData, total: 100 }));

      const markSpy = vitest
        .spyOn(componentPrivate.ref, 'markForCheck')
        .mockImplementation(() => {});
      componentPrivate.loadData();

      const result = await firstValueFrom(component.dataSource);

      expect(getAllMock).toHaveBeenCalledWith(mockFilter);
      expect(result).toEqual({
        pageToken: mockFilter.page + 1,
        rows: mockData,
      });
      expect(markSpy).toHaveBeenCalled();
    });

    it('should handle undefined data by normalizing to empty array', async () => {
      getAllMock.mockReturnValueOnce(of({ rows: undefined, total: 0 }));

      componentPrivate.loadData();

      const result = await firstValueFrom(component.dataSource);

      expect(getAllMock).toHaveBeenCalledWith(mockFilter);
      expect(result).toEqual({
        pageToken: mockFilter.page + 1,
        rows: [],
      });
    });
  });

  describe('public methods coverage', () => {
    it('onFilter should delegate to filter.onFilter', () => {
      const onFilterSpy = vitest.spyOn(componentPrivate.filter, 'onFilter');
      component.onFilter();
      expect(onFilterSpy).toHaveBeenCalled();
    });

    it('onReset should delegate to filter.clear', () => {
      const clearSpy = vitest.spyOn(componentPrivate.filter, 'clear');
      component.onReset();
      expect(clearSpy).toHaveBeenCalled();
    });

    it('setPage should delegate to filter.setPage converting string to number', () => {
      const spySetPage = vitest.spyOn(componentPrivate.filter, 'setPage');
      component.setPage('3');
      expect(spySetPage).toHaveBeenCalledWith('3');
    });

    it('setPage should delegate to filter.setPage with string token', () => {
      const spySetPage = vitest.spyOn(componentPrivate.filter, 'setPage');
      spySetPage.mockClear();
      componentPrivate.filter.value.page = 2;
      component.setPage('1');
      expect(spySetPage).toHaveBeenCalledWith('1');
    });
  });

  describe('private methods coverage', () => {
    it('initializeForm should create expected controls', () => {
      componentPrivate.initializeForm();
      const controls = componentPrivate.form.controls;
      expect(controls.contractKey).toBeDefined();
      expect(controls.type).toBeDefined();
      expect(controls.status).toBeDefined();
      expect(controls.createdDate).toBeDefined();
      expect(controls.contractDate).toBeDefined();
      expect(controls.createdBy).toBeDefined();
    });

    it('setupVariables should bind hasFilter and call setup', () => {
      componentPrivate.filter.value.limit = 10;
      componentPrivate.initializeForm();
      const setupSpy = vitest.spyOn(componentPrivate.filter, 'setup');
      componentPrivate.setupVariables();
      expect(typeof componentPrivate.hasFilter).toBe('function');
      expect(setupSpy).toHaveBeenCalled();
      const args = setupSpy.mock.calls[0][0] as { form: FormGroup; callback: () => void };
      expect(args.form).toBe(componentPrivate.form);
      expect(typeof args.callback).toBe('function');
    });

    it('fetchEnums should populate status options using translate + key pipes', () => {
      const translateSpy = vitest.spyOn(componentPrivate.translate, 'transform');
      translateSpy.mockImplementation((...args: unknown[]) => String(args[0]));
      componentPrivate.fetchEnums();
      expect(componentPrivate.statusOptions.length).toBeGreaterThan(0);
      expect(translateSpy).toHaveBeenCalled();
    });
  });
});
