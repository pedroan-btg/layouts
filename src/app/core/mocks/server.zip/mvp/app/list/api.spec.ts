import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpStatusCode } from '@angular/common/http';
import { Api } from './api';
import * as ListModel from './list.model';
import { FilterModel } from './filter';
import { Status } from '../core/enums';
import { environment } from '@fts-collateral/environment';
import { afterEach, beforeEach, describe, expect, it, vitest, vi } from 'vitest';

vi.mock('./list.model', () => ({
  toCollateral: (response: any) => response?.data?.rows ?? [],
}));
vi.mock('@fts-collateral/environment', () => ({
  environment: { collateralApi: 'http://mock' },
}));

describe('Api', () => {
  let api: Api;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [Api, provideHttpClient(), provideHttpClientTesting()],
    });
    api = TestBed.inject(Api);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  const run = (filter: FilterModel, response: any) => {
    let actual: { rows: any[] | undefined; total: number } | undefined;
    api.getAll(filter).subscribe(res => (actual = res));
    const req = httpMock.expectOne(r => r.url === `${environment.collateralApi}/ticket`);
    req.flush(response);
    return { req, actual: actual! };
  };

  const baseFilter = (): FilterModel => ({
    contractKey: 'CK123',
    type: 'Orig',
    status: Status.Approved,
    createdDate: [new Date('2023-01-01T00:00:00.000Z'), new Date('2023-02-01T00:00:00.000Z')],
    contractDate: null,
    createdBy: 'tester',
    page: 2,
    limit: 12 as any,
    skip: 24,
  });

  it('should call GET with correct URL and params, omitting skip, appending arrays', () => {
    const filter = baseFilter();
    const response = {
      data: {
        rows: [
          {
            id: 1,
            contractKey: 'A',
            type: 'Orig',
            status: Status.Approved,
            createdDate: new Date('2023-03-01T00:00:00.000Z'),
            contractDate: new Date('2023-03-02T00:00:00.000Z'),
            createdBy: 'userA',
          },
        ],
        skip: 0,
        total: 42,
      },
      statusCode: HttpStatusCode.Ok,
    };
    const { req, actual } = run(filter, response);
    expect(req.request.method).toBe('GET');

    expect(req.request.params.get('contractKey')).toBe('CK123');
    expect(req.request.params.get('type')).toBe('Orig');
    expect(req.request.params.get('status')).toBe(Status.Approved);
    expect(req.request.params.get('createdBy')).toBe('tester');
    expect(req.request.params.get('page')).toBe(String(filter.page));
    expect(req.request.params.get('limit')).toBe(String(filter.limit));
    expect(req.request.params.has('skip')).toBe(false);

    const createdDates = req.request.params.getAll('createdDate') || [];
    expect(createdDates.length).toBe(2);

    expect(actual).toBeDefined();
    expect(actual.total).toBe(42);
    expect(actual.rows?.length).toBe(1);
    expect(actual.rows?.[0].id).toBe(1);
  });

  it('should omit undefined and empty array values from HttpParams', () => {
    const filter: FilterModel = {
      contractKey: 'CK999',
      type: undefined as any,
      status: Status.Draft,
      createdDate: [],
      contractDate: undefined as any,
      createdBy: undefined as any,
      page: 1,
      limit: 10 as any,
      skip: 10,
    };
    const { req } = run(filter, {
      data: { rows: [], skip: 0, total: 0 },
      statusCode: HttpStatusCode.Ok,
    });
    expect(req.request.params.get('contractKey')).toBe('CK999');
    expect(req.request.params.get('status')).toBe(Status.Draft);
    expect(req.request.params.get('page')).toBe('1');
    expect(req.request.params.get('limit')).toBe('10');
    expect(req.request.params.has('type')).toBe(false);
    expect(req.request.params.has('createdBy')).toBe(false);
    expect(req.request.params.has('contractDate')).toBe(false);
    const createdDates = req.request.params.getAll('createdDate') || [];
    expect(createdDates.length).toBe(0);
  });

  it('should fallback total to rows length when server total is missing', () => {
    const filter = baseFilter();
    const response = {
      data: {
        rows: [
          {
            id: 2,
            contractKey: 'B',
            type: 'Orig',
            status: Status.Draft,
            createdDate: new Date('2023-04-01T00:00:00.000Z'),
            contractDate: new Date('2023-04-02T00:00:00.000Z'),
            createdBy: 'userB',
          },
          {
            id: 3,
            contractKey: 'C',
            type: 'Orig',
            status: Status.Draft,
            createdDate: new Date('2023-05-01T00:00:00.000Z'),
            contractDate: new Date('2023-05-02T00:00:00.000Z'),
            createdBy: 'userC',
          },
        ],
        skip: 0,
      },
      statusCode: HttpStatusCode.Ok,
    };
    const { actual } = run(filter, response);
    expect(actual).toBeDefined();
    expect(actual.total).toBe(2);
    expect(actual.rows?.length).toBe(2);
  });

  it('should compute total as 0 when rows are [] and total missing', () => {
    const filter = baseFilter();
    const response = {
      data: {
        rows: [],
        skip: 0,
      },
      statusCode: HttpStatusCode.Ok,
    };
    const { actual } = run(filter, response);
    expect(actual).toBeDefined();
    expect(actual.total).toBe(0);
    expect(actual.rows?.length).toBe(0);
  });

  it('should fallback total to 0 when rows are undefined', () => {
    const filter = baseFilter();
    const response = {
      data: {
        rows: undefined,
        skip: 0,
      },
      statusCode: HttpStatusCode.Ok,
    };
    const { actual } = run(filter, response);
    expect(actual).toBeDefined();
    expect(actual.total).toBe(0);
    expect(Array.isArray(actual.rows)).toBe(true);
    expect(actual.rows?.length).toBe(0);
  });

  it('should fallback total to rows length when server total is NaN', () => {
    const filter = baseFilter();
    const response = {
      data: {
        rows: [
          {
            id: 10,
            contractKey: 'Z',
            type: 'Orig',
            status: Status.Approved,
            createdDate: new Date(),
            contractDate: new Date(),
            createdBy: 'userZ',
          },
          {
            id: 11,
            contractKey: 'Y',
            type: 'Orig',
            status: Status.Draft,
            createdDate: new Date(),
            contractDate: new Date(),
            createdBy: 'userY',
          },
          {
            id: 12,
            contractKey: 'X',
            type: 'Orig',
            status: Status.Draft,
            createdDate: new Date(),
            contractDate: new Date(),
            createdBy: 'userX',
          },
        ],
        skip: 0,
        total: Number.NaN,
      },
      statusCode: HttpStatusCode.Ok,
    };
    const { actual } = run(filter, response);
    expect(actual).toBeDefined();
    expect(actual.total).toBe(3);
    expect(actual.rows?.length).toBe(3);
  });

  it('should compute total from rows length when total is NaN and toCollateral returns undefined', () => {
    const filter = baseFilter();
    const spy = vitest.spyOn(ListModel, 'toCollateral').mockImplementation(() => undefined as any);
    const response = {
      data: {
        rows: [],
        skip: 0,
        total: Number.NaN,
      },
      statusCode: HttpStatusCode.Ok,
    } as any;
    const { actual } = run(filter, response);
    expect(actual).toBeDefined();
    expect(actual.total).toBe(0);
    expect(actual.rows).toBeUndefined();

    spy.mockRestore();
  });
});
