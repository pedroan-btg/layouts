import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ApiResponse, CollateralApi, toCollateral } from './list.model';
import { FilterModel } from './filter';
import { environment } from '@fts-collateral/environment';

@Injectable()
export class Api {
  private readonly httpClient = inject(HttpClient);

  getAll(filter: FilterModel): Observable<{ rows: CollateralApi[] | undefined; total: number }> {
    let params = new HttpParams();

    Object.entries(filter).forEach(([key, value]) => {
      if (value === null || value === undefined) return;

      if (key === 'skip') return;

      if (Array.isArray(value)) {
        value.forEach(v => {
          params = params.append(key, v.toString());
        });
      } else {
        params = params.set(key, value.toString());
      }
    });

    return this.httpClient.get<ApiResponse>(`${environment.collateralApi}/ticket`, { params }).pipe(
      map(response => {
        const rows = toCollateral(response);
        const totalFromServer = response.data?.total;
        const total = Number.isFinite(totalFromServer as number)
          ? (totalFromServer as number)
          : (rows?.length ?? 0);

        return { rows, total };
      }),
    );
  }
}
