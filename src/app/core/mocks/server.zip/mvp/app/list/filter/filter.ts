import { DestroyRef, inject, Injectable, signal } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { formHasChanged } from 'fts-frontui/form';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject } from 'rxjs';
import { FilterModel } from './filter.model';

@Injectable()
export class Filter {
  private readonly destroyRef = inject(DestroyRef);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  private form!: FormGroup;
  private lastFormValuesSnapshot?: Record<string, unknown>;

  hasFilter = signal<boolean>(false);
  private readonly filterEventsSubject = new Subject<boolean>();
  readonly filterChanges = this.filterEventsSubject.asObservable();

  value: FilterModel = { page: 0, skip: 0, limit: 12 } as FilterModel;

  setup({ form, callback }: { form: FormGroup; callback: () => void }): void {
    this.form = form;
    this.lastFormValuesSnapshot = this.form.getRawValue();

    this.filterChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => callback());

    this.route.queryParamMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => this.onParamFilter(params));
  }

  setPage(currentPageToken: number): void {
    const isValid = Number.isFinite(currentPageToken) && currentPageToken > 0;
    const page = isValid ? currentPageToken : 0;
    this.value.page = page;
    this.value.skip = page * this.value.limit;
    this.filterEventsSubject.next(true);
  }

  onFilter(): void {
    const formValues = this.form.value;
    this.value = { ...this.value, ...formValues } as FilterModel;

    const hasActiveFilters = Object.values(formValues).some(value => {
      if (value == null) return false;

      if (Array.isArray(value)) return value.some(Boolean);

      return typeof value === 'string' ? value.trim() !== '' : true;
    });
    this.hasFilter.set(hasActiveFilters);

    const serializeDateListToParamString = (arr: Date[] | null | undefined): string | null =>
      arr && arr.length > 0 ? arr.map(date => date.toISOString()).join(',') : null;

    const normalizeStringParam = (value: string | null | undefined): string | null => {
      const trimmedValue = (value ?? '').trim();

      return trimmedValue.length > 0 ? trimmedValue : null;
    };

    const queryParams: Record<string, unknown> = {
      contractkey: normalizeStringParam(this.value.contractKey),
      type: normalizeStringParam(this.value.type),
      status: this.value.status ?? null,
      createdby: normalizeStringParam(this.value.createdBy),
      createddate: serializeDateListToParamString(this.value.createdDate),
      contractdate: serializeDateListToParamString(this.value.contractDate),
    };

    this.router.navigate([], {
      relativeTo: this.route,
      queryParams,
    });
  }

  clear(): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {},
    });
  }

  private getQueryParamIgnoreCase(params: ParamMap, key: string): string | null {
    const keys = (params as unknown as { keys?: string[] }).keys ?? [];
    const found = keys.find(k => k.toLowerCase() === key.toLowerCase());

    return params.get(found ?? key);
  }

  private parseDateListFromParamString(param: string | null): Date[] | null {
    if (!param) return null;

    const parts = param
      .split(',')
      .map(part => part.trim())
      .filter(Boolean);
    const dates = parts.map(part => new Date(part)).filter(date => !isNaN(date.getTime()));

    return dates.length > 0 ? dates : null;
  }

  private onParamFilter(params: ParamMap): void {
    let hasActive = false;
    const controlNames = Object.keys(this.form.controls ?? {});

    for (const name of controlNames) {
      const control = this.form.get(name);

      if (!control) continue;

      const param = this.getQueryParamIgnoreCase(params, name);

      if (name === 'createdDate' || name === 'contractDate') {
        const parsedDates = this.parseDateListFromParamString(param);
        control.setValue(parsedDates);
        const hasDatesValue = !!(parsedDates && parsedDates.length);
        hasActive = hasActive || hasDatesValue;
      } else {
        const trimmedParam = (param ?? '').trim();
        control.setValue(trimmedParam === '' ? null : param);
        const hasStringValue = trimmedParam !== '';
        hasActive = hasActive || hasStringValue;
      }
    }

    this.hasFilter.set(hasActive);
    this.value = {
      ...this.value,
      ...this.form.value,
      page: this.value.page,
      skip: this.value.skip,
      limit: this.value.limit,
    } as FilterModel;

    if (formHasChanged(this.form, this.lastFormValuesSnapshot ?? {})) {
      this.value.page = 0;
      this.value.skip = 0;
      this.lastFormValuesSnapshot = this.form.getRawValue();
    }

    this.filterEventsSubject.next(true);
  }
}
