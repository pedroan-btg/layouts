import { TestBed } from '@angular/core/testing';
import { provideRouter, Router, ActivatedRoute } from '@angular/router';
import { beforeEach, describe, expect, it, vitest } from 'vitest';

import { Filter } from './filter';
import { FormControl, FormGroup } from '@angular/forms';

interface ParamMapStub {
  keys?: string[];
  get: (key: string) => string | null;
}

const createForm = (values?: Partial<Record<string, unknown>>): FormGroup => {
  return new FormGroup({
    contractKey: new FormControl(values?.['contractKey'] ?? null),
    type: new FormControl(values?.['type'] ?? null),
    status: new FormControl(values?.['status'] ?? null),
    createdDate: new FormControl(values?.['createdDate'] ?? null),
    contractDate: new FormControl(values?.['contractDate'] ?? null),
    createdBy: new FormControl(values?.['createdBy'] ?? null),
  });
};

const getNavExtras = (spy: ReturnType<typeof vitest.spyOn> | unknown): Record<string, unknown> => {
  const spyObject = spy as { mock?: { calls?: unknown[][] } };
  return (spyObject?.mock?.calls?.[0]?.[1] as Record<string, unknown>) ?? {};
};

const setupAndNavigate = async (
  service: Filter,
  router: Router,
  url?: string,
  values?: Partial<Record<string, unknown>>,
): Promise<{ form: FormGroup; callback: () => void }> => {
  const form = createForm(values);
  const callback = vitest.fn();
  service.setup({ form, callback });
  if (url) {
    await router.navigateByUrl(url);
  }
  return { form, callback };
};

interface ActivatedRouteProviderStub {
  provide: typeof ActivatedRoute;
  useValue: {
    queryParamMap: {
      pipe: () => { subscribe: (fn: (v: ParamMapStub) => void) => void };
    };
  };
}

const provideActivatedRouteStub = (options: {
  keys?: string[];
  entries?: Record<string, string | null>;
}): ActivatedRouteProviderStub => ({
  provide: ActivatedRoute,
  useValue: {
    queryParamMap: {
      pipe: (): { subscribe: (subscriber: (paramMap: ParamMapStub) => void) => void } => ({
        subscribe: (subscriber: (paramMap: ParamMapStub) => void): void => {
          const paramMapObj: ParamMapStub = {
            get: (key: string) => (options.entries ? (options.entries[key] ?? null) : null),
          };
          paramMapObj.keys = options.keys;
          subscriber(paramMapObj);
        },
      }),
    },
  },
});

describe('Filter service', () => {
  let service: Filter;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [Filter, provideRouter([])],
    }).compileComponents();

    TestBed.runInInjectionContext(() => {
      service = TestBed.inject(Filter);
    });
    router = TestBed.inject(Router);
  });

  describe('setup', () => {
    it('handles invalid dates as null and applies limit fallback when = 0', async () => {
      const callback = vitest.fn();
      const form = createForm();

      service.setup({ form, callback });
      await router.navigateByUrl('/?page=0&limit=0&createdDate=invalid, &contractDate=not-a-date');

      expect(service.value.page).toBe(0);
      expect(service.value.limit).toBe(12 as any);
      expect(service.value.createdDate).toBeNull();
      expect(service.value.contractDate).toBeNull();
      expect(service.hasFilter()).toBe(false);
    });

    it.each([
      {
        keys: ['ConTractKeY', 'StAtUs'],
        entries: { ConTractKeY: 'ID123', StAtUs: '2' },
        expectKey: 'ID123',
        expectStatus: '2',
      },
      {
        entries: { contractKey: 'FALLBACK', status: '3' },
        expectKey: 'FALLBACK',
        expectStatus: '3',
      },
    ])(
      'reads params from ActivatedRoute (keys: $keys)',
      async ({ keys, entries, expectKey, expectStatus }) => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
          providers: [
            Filter,
            provideRouter([]),
            provideActivatedRouteStub({
              keys,
              entries: entries as unknown as Record<string, string | null>,
            }),
          ],
        });

        const filterService = TestBed.inject(Filter);
        const callback = vitest.fn();
        const form = createForm();
        filterService.setup({ form, callback });

        await Promise.resolve();

        expect(filterService.value.contractKey).toBe(expectKey);
        expect(filterService.value.status).toBe(expectStatus as any);
        expect(filterService.hasFilter()).toBe(true);
      },
    );

    it('blank status results in hasFilter=false', async () => {
      const callback = vitest.fn();
      const form = createForm();
      service.setup({ form, callback });
      await router.navigateByUrl('/?status=');

      expect(!service.value.status).toBe(true);
      expect(service.hasFilter()).toBe(false);
    });

    it.each([
      {
        name: 'valid createdDate from route activates hasFilter',
        url: '/?createddate=2024-01-01T00:00:00.000Z',
        assert: (s: Filter) => {
          expect(Array.isArray(s.value.createdDate)).toBe(true);
          expect(s.hasFilter()).toBe(true);
        },
      },
      {
        name: 'empty createdDate string from route yields null and hasFilter=false',
        url: '/?createddate=',
        assert: (s: Filter) => {
          expect(s.value.createdDate).toBeNull();
          expect(s.hasFilter()).toBe(false);
        },
      },
    ])('%s', async ({ url, assert }) => {
      await setupAndNavigate(service, router, url);
      assert(service);
    });
  });

  describe('helpers', () => {
    it('onParamFilter handles form without controls gracefully', async () => {
      (service as any).form = new FormGroup({});
      const paramMapWithoutEntries = { keys: [], get: (_: string) => null } as any;
      (service as any).onParamFilter(paramMapWithoutEntries);
      expect(service.hasFilter()).toBe(false);
    });

    it('onParamFilter skips controls when params are null', async () => {
      (service as any).form = createForm({});

      const paramMapWithNulls = {
        keys: ['contractKey', 'status'],
        get: (_: string) => null,
      } as any;

      (service as any).onParamFilter(paramMapWithNulls);
      expect(service.hasFilter()).toBe(false);
    });

    it('onParamFilter continues when control lookup returns null', async () => {
      const formLikeWithUnknownControl = {
        controls: { ghost: {} },
        get: (_: string) => null,
        value: {},
        getRawValue: () => ({}),
      } as any;
      (service as any).form = formLikeWithUnknownControl;
      const paramMapWithGhost = { keys: ['ghost'], get: (_: string) => 'value' } as any;
      (service as any).onParamFilter(paramMapWithGhost);
      expect(service.hasFilter()).toBe(false);
    });

    it('onParamFilter handles undefined controls object', async () => {
      const formLikeWithoutControlsProperty = {
        controls: undefined,
        get: (_: string) => null,
        value: {},
        getRawValue: () => ({}),
      } as any;
      (service as any).form = formLikeWithoutControlsProperty;
      const emptyParamMap = { keys: [], get: (_: string) => null } as any;
      try {
        (service as any).onParamFilter(emptyParamMap);
      } catch {
        const ok = true;
        expect(ok).toBe(true);
      }
      expect(service.hasFilter()).toBe(false);
    });
  });

  describe('onFilter', () => {
    it('serializes blank and undefined values to null', async () => {
      const form = createForm({
        contractKey: '   ',
        type: ' ',
        createdBy: '',
        createdDate: [],
        contractDate: [],
      });
      const callback = vitest.fn();
      service.setup({ form, callback });
      const navSpy = vitest.spyOn(router, 'navigate').mockResolvedValue(true as any);
      service.onFilter();
      let queryParams = getNavExtras(navSpy)['queryParams'] as Record<string, any>;
      expect(queryParams['contractkey']).toBeNull();
      expect(queryParams['type']).toBeNull();
      expect(queryParams['createdby']).toBeNull();
      expect(queryParams['createddate']).toBeNull();
      expect(queryParams['contractdate']).toBeNull();

      form.patchValue(
        { createdBy: undefined, createdDate: undefined, contractDate: undefined } as any,
        { emitEvent: false },
      );
      service.onFilter();
      queryParams = getNavExtras(navSpy)['queryParams'] as Record<string, any>;
      expect(queryParams['createdby']).toBeNull();
      expect(queryParams['createddate']).toBeNull();
      expect(queryParams['contractdate']).toBeNull();
    });

    it('undefined status is serialized as null', async () => {
      await setupAndNavigate(service, router);
      (service.value as any).status = undefined;

      const navSpy = vitest.spyOn(router, 'navigate').mockResolvedValue(true as any);
      service.onFilter();
      const queryParamsStatus = getNavExtras(navSpy)['queryParams'] as Record<string, any>;
      expect(queryParamsStatus['status']).toBeNull();
    });

    it('non-empty date arrays are serialized in ISO CSV', async () => {
      const { form } = await setupAndNavigate(service, router);
      const date1 = new Date('2022-01-01T00:00:00.000Z');
      const date2 = new Date('2022-01-02T00:00:00.000Z');
      form.patchValue(
        { createdDate: [date1, date2], contractDate: [date2, date1] },
        { emitEvent: false },
      );
      const navSpy = vitest.spyOn(router, 'navigate').mockResolvedValue(true as any);
      service.onFilter();
      const queryParamsDates = getNavExtras(navSpy)['queryParams'] as Record<string, any>;
      expect(String(queryParamsDates['createddate'])).toContain('2022-01-01T00:00:00.000Z');
      expect(String(queryParamsDates['createddate'])).toContain('2022-01-02T00:00:00.000Z');
      expect(String(queryParamsDates['contractdate'])).toContain('2022-01-01T00:00:00.000Z');
      expect(String(queryParamsDates['contractdate'])).toContain('2022-01-02T00:00:00.000Z');
    });

    it('patches createdDate from route when CSV is valid', async () => {
      const form = createForm({});
      const callback = vitest.fn();
      service.setup({ form, callback });
      const router = TestBed.inject(Router);
      await router.navigateByUrl('/?createddate=2020-01-01T00:00:00.000Z,2020-01-02T00:00:00.000Z');
      const createdDatesArray = form.get('createdDate')!.value as Date[] | null;
      expect(Array.isArray(createdDatesArray)).toBe(true);
      expect((createdDatesArray as Date[]).length).toBe(2);
    });

    it('status=0 is an active filter and serializes as 0', async () => {
      const form = createForm({ status: 0 as any });
      const callback = vitest.fn();
      service.setup({ form, callback });

      form.patchValue({ status: 0 as any }, { emitEvent: false });
      const navSpy = vitest.spyOn(router, 'navigate').mockResolvedValue(true as any);
      service.onFilter();
      const queryParamsStatusZero = getNavExtras(navSpy)['queryParams'] as Record<string, any>;
      expect(service.hasFilter()).toBe(true);
      expect(queryParamsStatusZero['status']).toBe(0);
    });

    it('merges form values, hasFilter=true, and navigates', async () => {
      const form = createForm({
        contractKey: ' ABC ',
        type: 'TypeA',
        createdDate: [new Date(), new Date()],
        createdBy: 'user',
      });
      const callback = vitest.fn();
      service.setup({ form, callback });
      const navSpy = vitest.spyOn(router, 'navigate');
      form.patchValue(
        {
          contractKey: ' ABC ',
          type: 'TypeA',
          createdDate: [new Date(), new Date()],
          createdBy: 'user',
        },
        { emitEvent: false },
      );
      service.onFilter();

      expect(service.value.type).toBe('TypeA');
      expect(Array.isArray(service.value.createdDate)).toBe(true);
      expect(service.hasFilter()).toBe(true);
      expect(navSpy).toHaveBeenCalled();
    });
  });

  describe('setPage', () => {
    it('sets a valid currentPageToken and recomputes skip, emitting change', async () => {
      const form = createForm({});
      const callback = vitest.fn();
      service.setup({ form, callback });
      const filterChangeEvents: boolean[] = [];
      service.filterChanges.subscribe(change => filterChangeEvents.push(change));

      service.value.limit = 12 as any;
      service.setPage(3);

      expect(service.value.page).toBe(3);
      expect(service.value.skip).toBe(36);
      expect(filterChangeEvents.length).toBeGreaterThan(0);
    });

    it('normalizes an invalid currentPageToken to 0 and emits change', async () => {
      const form = createForm({});
      const callback = vitest.fn();
      service.setup({ form, callback });
      const emittedChanges: boolean[] = [];
      service.filterChanges.subscribe(change => emittedChanges.push(change));

      service.value.limit = 10 as any;
      service.setPage(Number.NaN as number);

      expect(service.value.page).toBe(0);
      expect(service.value.skip).toBe(0);
      expect(emittedChanges.length).toBeGreaterThan(0);
    });
  });

  describe('clear', () => {
    it('navigates clearing query params', async () => {
      const formWithValues = createForm({
        contractKey: 'X',
        type: 'T',
        status: 1 as any,
        createdBy: 'u',
      });
      const callbackOnClear = vitest.fn();
      service.setup({ form: formWithValues, callback: callbackOnClear });
      const navigateSpy = vitest.spyOn(router, 'navigate');

      service.clear();

      expect(navigateSpy).toHaveBeenCalled();
      const navigationExtras = getNavExtras(navigateSpy);
      expect(navigationExtras['queryParams']).toMatchObject({});
    });
  });

  describe('onParamFilter change tracking', () => {
    it('resets page/skip and updates snapshot when form changes', async () => {
      await TestBed.resetTestingModule();
      await TestBed.configureTestingModule({
        providers: [
          Filter,
          provideRouter([]),
          provideActivatedRouteStub({ entries: { contractKey: 'NEWKEY' } }),
        ],
      }).compileComponents();

      const filterServiceChangeTracking = TestBed.inject(Filter);
      const formChangeTracking = createForm({ contractKey: null });
      const callbackChangeTracking = vitest.fn();
      filterServiceChangeTracking.setup({
        form: formChangeTracking,
        callback: callbackChangeTracking,
      });
      await Promise.resolve();

      expect(filterServiceChangeTracking.value.page).toBe(0);
      expect(filterServiceChangeTracking.value.skip).toBe(0);
      expect((filterServiceChangeTracking as any).lastFormValuesSnapshot).toBeDefined();
    });

    it('keeps page/skip when form values remain unchanged', async () => {
      const unchangedForm = createForm({ contractKey: null, createdBy: null, status: null });
      const unchangedCallback = vitest.fn();
      service.setup({ form: unchangedForm, callback: unchangedCallback });
      service.value.page = 2;
      service.value.limit = 12 as any;
      service.value.skip = 24;
      const emptyParams = {
        keys: ['contractKey', 'createdBy', 'status'],
        get: (_: string) => null,
      } as any;
      (service as any).onParamFilter(emptyParams);
      expect(service.value.page).toBe(2);
      expect(service.value.skip).toBe(24);
    });

    it('resets page/skip when snapshot differs from current form raw', async () => {
      const formWithNullContractKey = createForm({ contractKey: null });
      const callbackForSnapshotChange = vitest.fn();
      service.setup({ form: formWithNullContractKey, callback: callbackForSnapshotChange });
      (service as any).lastFormValuesSnapshot = { contractKey: 'DIFF' };
      service.value.page = 7;
      service.value.limit = 12 as any;
      service.value.skip = 84;
      const paramMap = {
        keys: ['contractKey'],
        get: (_: string) => 'NEWKEY',
        getAll: (_: string) => ['NEWKEY'],
      } as any;
      (service as any).onParamFilter(paramMap);
      expect(service.value.page).toBe(0);
      expect(service.value.skip).toBe(0);
    });
  });
});
