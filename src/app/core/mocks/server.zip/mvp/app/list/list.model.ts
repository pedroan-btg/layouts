import { HttpStatusCode } from '@angular/common/http';
import { Status } from '../core/enums';

export interface ApiResponse {
  data?: {
    rows: CollateralApi[];
    skip: number;
    total?: number;
  };
  errors?: string[];
  statusCode: HttpStatusCode;
}

export interface CollateralApi {
  id: number;
  contractKey: string;
  type: string;
  status: Status;
  createdDate: Date;
  contractDate: Date;
  createdBy: string;
}

export const toCollateral = (response: ApiResponse): CollateralApi[] => {
  return (response.data?.rows ?? []).map((s: CollateralApi) => ({
    id: s.id,
    contractKey: s.contractKey,
    type: s.type,
    status: s.status,
    createdDate: s.createdDate,
    contractDate: s.contractDate,
    createdBy: s.createdBy,
  }));
};
