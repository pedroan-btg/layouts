import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  OnInit,
  Signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Observable, map } from 'rxjs';
import { RouterModule } from '@angular/router';

import { DataTable, Table, TableColumn } from 'fts-frontui/table';
import { ToolbarActionButton } from 'fts-frontui/toolbar';
import { i18n, TranslatePipe } from 'fts-frontui/i18n';
import { Input } from 'fts-frontui/input';
import { DatePipe, EmptyPipe } from 'fts-frontui/pipes';
import { Select } from 'fts-frontui/select';
import { CollateralApi } from './list.model';
import { Filter } from './filter';
import { Api } from './api';
import { StatusClassPipe } from '../core/pipes/status-class.pipe';
import { StatusKeyPipe } from '../core/pipes/status-key.pipe';
import { Status } from '../core/enums';

@Component({
  selector: '[col-list]',
  templateUrl: './list.html',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    Table,
    TableColumn,
    Input,
    Select,
    i18n,
    ToolbarActionButton,
    DatePipe,
    StatusClassPipe,
    StatusKeyPipe,
    EmptyPipe,
  ],
  providers: [Api, Filter, StatusKeyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class List implements OnInit {
  private readonly api = inject(Api);
  private readonly filter = inject(Filter);
  private readonly fb = inject(FormBuilder);
  private readonly ref = inject(ChangeDetectorRef);
  private readonly translate = inject(TranslatePipe);
  private readonly statusKeyPipe = inject(StatusKeyPipe);

  form!: FormGroup;
  dataSource!: Observable<DataTable<CollateralApi>>;
  hasFilter!: Signal<boolean>;
  statusOptions!: { value: Status; label: string }[];

  ngOnInit(): void {
    this.initializeForm();
    this.setupVariables();
    this.loadData();
    this.fetchEnums();
  }

  onFilter(): void {
    this.filter.onFilter();
  }

  onReset(): void {
    this.filter.clear();
  }

  setPage(currenPageToken: number | string): void {
    this.filter.setPage(currenPageToken as number);
  }

  private initializeForm(): void {
    this.form = this.fb.group({
      contractKey: ['', Validators.maxLength(50)],
      type: ['', Validators.maxLength(50)],
      status: [null],
      createdDate: [null],
      contractDate: [null],
      createdBy: ['', Validators.maxLength(50)],
    });
  }

  private setupVariables(): void {
    this.hasFilter = this.filter.hasFilter;
    this.filter.setup({ form: this.form, callback: this.loadData.bind(this) });
  }

  private loadData(): void {
    this.dataSource = this.api.getAll(this.filter.value).pipe(
      map(data => {
        const rows = data.rows ?? [];
        const pageToken = this.filter.value.page + 1;

        return { pageToken, rows } as DataTable<CollateralApi>;
      }),
    );
    this.ref.markForCheck();
  }

  private fetchEnums(): void {
    this.statusOptions = Object.entries(Status)
      .filter(([, value]) => typeof value === 'string')
      .map(([, value]) => ({
        value: value as Status,
        label: String(this.translate.transform(this.statusKeyPipe.transform(value as Status))),
      }));
  }
}
