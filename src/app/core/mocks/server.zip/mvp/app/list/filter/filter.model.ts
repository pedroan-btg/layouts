import { ItemsPerPageType } from 'fts-frontui/table';
import { Status } from '../../core/enums';

export interface FilterModel {
  contractKey: string | null;
  type: string | null;
  status: Status | null;
  createdDate: Date[] | null;
  contractDate: Date[] | null;
  createdBy: string | null;
  page: number;
  limit: ItemsPerPageType;
  skip: number;
}
