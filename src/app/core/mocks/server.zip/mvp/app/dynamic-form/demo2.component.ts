import {
  Component,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject,
  OnInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicFormComponent } from './dynamic-form.component';
import { DynamicFormSchema } from './types';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: '[fts-dynamic-form-demo2]',
  standalone: true,
  imports: [CommonModule, DynamicFormComponent],
  template: `
    <div class="container py-3">
      <h5 class="mb-3">Dynamic Form Demo (JSON)</h5>

      @if (schema) {
        <div fts-dynamic-form [schema]="schema" (submitted)="onSubmitted($event)"></div>
      } @else {
        <div class="text-muted">Carregando schema...</div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DynamicFormDemo2Component implements OnInit {
  private http = inject(HttpClient);
  private cdr = inject(ChangeDetectorRef);

  schema: DynamicFormSchema | null = null;

  ngOnInit(): void {
    this.http.get<DynamicFormSchema>('/api/dynamic-form/motor-home').subscribe({
      next: s => {
        this.schema = s;
        this.cdr.markForCheck();
      },
      error: () => {
        this.schema = null;
        this.cdr.markForCheck();
      },
    });
  }

  onSubmitted(model: Record<string, unknown>): void {
    void model;
  }
}
