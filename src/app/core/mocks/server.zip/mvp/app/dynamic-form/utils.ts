import { FormControl, FormGroup } from '@angular/forms';
import { DynamicField, DynamicFormSchema } from './types';
import { DependenciesEngine } from './dependencies.engine';

export function orderFields(schema: DynamicFormSchema): DynamicField[] {
  return [...schema.fields].sort((a, b) => {
    const ao = a.order ?? Number.MAX_SAFE_INTEGER;
    const bo = b.order ?? Number.MAX_SAFE_INTEGER;

    if (ao !== bo) return ao - bo;

    return schema.fields.indexOf(a) - schema.fields.indexOf(b);
  });
}

export function isVisible(engine: DependenciesEngine, field: DynamicField): boolean {
  return engine.isVisible(field.name);
}

export function control(form: FormGroup, name: string): FormControl | null {
  return (form.get(name) as FormControl) ?? null;
}

export function firstErrorMessage(form: FormGroup, name: string, field: DynamicField): string {
  const fieldControl = control(form, name);

  if (!fieldControl) return '';

  const shouldShowError = fieldControl.touched && fieldControl.invalid;

  if (!shouldShowError) return '';

  const currentErrors = fieldControl.errors;

  if (!currentErrors) return '';

  const custom = field.validations?.find(v => v.message && currentErrors[v.name]);

  if (custom?.message) return custom.message;

  const key = Object.keys(currentErrors)[0];

  switch (key) {
    case 'required':
      return 'form.errors.required';
    case 'min':
      return 'form.errors.min';
    case 'max':
      return 'form.errors.max';
    case 'minlength':
      return 'form.errors.minLength';
    case 'maxlength':
      return 'form.errors.maxLength';
    case 'pattern':
      return 'form.errors.pattern';
    case 'integerOnly':
      return 'form.errors.integerOnly';
    case 'decimalPlaces':
      return 'form.errors.decimalPlaces';
    case 'notPast':
      return 'form.errors.notPast';
    case 'notFuture':
      return 'form.errors.notFuture';
    case 'maxDiffDays':
      return 'form.errors.maxDiffDays';
    case 'maxDiffMonths':
      return 'form.errors.maxDiffMonths';
    case 'enumMatch':
      return 'form.errors.enumMatch';
    case 'multiSelectLimit':
      return 'form.errors.multiSelectLimit';
    default:
      return 'form.errors.invalid';
  }
}
