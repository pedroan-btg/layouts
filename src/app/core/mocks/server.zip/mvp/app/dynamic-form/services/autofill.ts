import { Injectable, inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, filter, Subscription } from 'rxjs';
import { DynamicField, DynamicFormSchema } from '../types';

@Injectable({ providedIn: 'root' })
export class AutofillService {
  private subs: Subscription[] = [];
  private http = inject(HttpClient);

  register(form: FormGroup, schema: DynamicFormSchema): void {
    schema.fields.filter(f => !!f.autoFill).forEach(f => this.setupForField(form, schema, f));
  }

  cleanup(): void {
    this.subs.forEach(s => s.unsubscribe());
    this.subs = [];
  }

  private setupForField(form: FormGroup, schema: DynamicFormSchema, field: DynamicField): void {
    const cfg = field.autoFill!;
    const trigger = form.get(cfg.triggerField);

    if (!trigger) return;

    const pattern = this.findTriggerPattern(schema, cfg.triggerField);

    const sub = trigger.valueChanges
      .pipe(
        debounceTime(cfg.debounceMs ?? 400),
        distinctUntilChanged(),
        filter(v => (pattern ? new RegExp(pattern).test(String(v ?? '')) : !!v)),
      )
      .subscribe(val => {
        const url = this.interpolate(cfg.api, cfg.triggerField, String(val ?? ''));
        this.http.get<Record<string, unknown>>(url).subscribe({
          next: resp => this.applyBehavior(form, field, resp),
          error: () => {
            // eslint-disable-next-line no-console
            console.warn('AutoFill request failed for', field.name);
          },
        });
      });

    this.subs.push(sub);
  }

  private interpolate(api: string, key: string, value: string): string {
    let toSend = String(value ?? '');

    // CEP: remover caracteres não numéricos para garantir compatibilidade com a API (ViaCEP aceita sem hífen)
    if (key.toLowerCase().includes('zip')) {
      toSend = toSend.replace(/\D/g, '');
    }

    const encoded = encodeURIComponent(toSend);

    return api.replace(`{{${key}}}`, encoded);
  }

  private applyBehavior(form: FormGroup, field: DynamicField, resp: Record<string, unknown>): void {
    const cfg = field.autoFill!;
    const shouldFill = cfg.behavior === 'ask' ? this.askConfirm(field) : true;

    if (!shouldFill) return;

    Object.entries(cfg.map).forEach(([dest, src]) => {
      const ctrl = form.get(dest);
      const value = resp[src];

      if (!ctrl) {
        // eslint-disable-next-line no-console
        console.warn('AutoFill destination not found:', dest);

        return;
      }

      if (cfg.behavior === 'fillEmpty') {
        const empty = ctrl.value === null || ctrl.value === undefined || ctrl.value === '';

        if (empty) ctrl.setValue(value ?? null);
      } else {
        ctrl.setValue(value ?? null);
      }
    });
  }

  private askConfirm(field: DynamicField): boolean {
    const text = field.ui?.confirmationText ?? 'Preencher dados automaticamente?';

    return window.confirm(text);
  }

  private findTriggerPattern(schema: DynamicFormSchema, name: string): string | null {
    const triggerField = schema.fields.find(f => f.name === name);
    const patternVal = triggerField?.validations?.find(v => v.name === 'pattern')?.value;

    return patternVal ? String(patternVal) : null;
  }
}
