import { Injectable, inject } from '@angular/core';
import { DynamicField } from '../types';
import { TranslatePipe } from 'fts-frontui/i18n';

interface SelectItem {
  label: string;
  value: string;
}

@Injectable()
export class FieldMapperService {
  private readonly translatePipe = inject(TranslatePipe);
  private readonly selectCache = new Map<string, SelectItem[]>();
  isInput(field: DynamicField): boolean {
    return field.widget === 'text' || field.widget === 'number' || field.widget === 'textarea';
  }

  inputType(field: DynamicField): 'text' | 'textarea' | 'date' | 'autocomplete' {
    if (field.widget === 'textarea') return 'textarea';

    if (field.widget === 'datepicker' || field.widget === 'calendar') return 'date';

    if (field.widget === 'autocomplete') return 'autocomplete';

    return 'text';
  }

  maskFor(field: DynamicField): string | null {
    if (field.ui?.mask) return field.ui.mask;

    if (field.widget === 'number') return 'number';

    return null;
  }

  selectItems(field: DynamicField): SelectItem[] {
    const key = `${field.name}|${(field.values ?? []).join(',')}`;
    const cached = this.selectCache.get(key);

    if (cached) return cached;

    const values = field.values ?? [];
    const built = values.map(rawValue => {
      const code = String(rawValue);
      const parts = code.split('.');
      const label =
        parts.length === 2
          ? this.translatePipe.transform(
              `enums.${parts[0].toLowerCase()}.${parts[1].toLowerCase()}`,
            )
          : this.translatePipe.transform(code);

      return { label, value: code };
    });

    this.selectCache.set(key, built);

    return built;
  }
}
