export { DynamicFormEnValidations } from './en/validations.translation';
export { DynamicFormEnFields } from './en/fields.translation';
export { DynamicFormEsValidations } from './es/validations.translation';
export { DynamicFormEsFields } from './es/fields.translation';
export { DynamicFormPtValidations } from './pt/validations.translation';
export { DynamicFormPtFields } from './pt/fields.translation';
