export const DynamicFormPtValidations = {
  form: {
    errors: {
      required: 'Campo obrigatório',
      min: 'Valor abaixo do mínimo permitido',
      max: 'Valor acima do máximo permitido',
      minLength: 'Texto menor do que o permitido',
      maxLength: 'Texto maior do que o permitido',
      pattern: 'Valor não corresponde ao formato esperado',
      integerOnly: 'Apenas números inteiros são permitidos',
      decimalPlaces: 'Muitas casas decimais',
      notPast: 'Data não pode estar no passado',
      notFuture: 'Data não pode estar no futuro',
      maxDiffDays: 'Diferença excede os dias permitidos',
      multiSelectLimit: 'Você selecionou mais itens que o permitido',
      maxDiffMonths: 'Diferença excede os meses permitidos',
      enumMatch: 'Valor não corresponde às opções permitidas',
      invalid: 'Valor inválido',
    },
  },
};
