import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChildren,
  ElementRef,
  QueryList,
  inject,
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { debounceTime, Subscription, Observable } from 'rxjs';
import { SimpleChanges, OnChanges } from '@angular/core';
import { Input as FtsInput } from 'fts-frontui/input';
import { Selection as FtsSelection } from 'fts-frontui/selection';
import { Select as FtsSelect } from 'fts-frontui/select';
import { TranslatePipe } from 'fts-frontui/i18n';
import { DynamicFormSchema, DynamicField } from './types';
import { ValidatorsFactory } from './validators.factory';
import { initialValueOf } from './models';
import { DependenciesEngine } from './dependencies.engine';
import { orderFields, firstErrorMessage } from './utils';
import { FieldMapperService } from './services/field-mapper';
import { AutofillService } from './services/autofill';

@Component({
  selector: '[fts-dynamic-form]',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FtsInput, FtsSelection, FtsSelect, TranslatePipe],
  providers: [FieldMapperService, TranslatePipe],
  templateUrl: './dynamic-form.component.html',
  styles: [':host ::ng-deep .invalid-feedback{display:none!important}'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DynamicFormComponent implements OnInit, OnDestroy, OnChanges {
  @Input() schema!: DynamicFormSchema;
  @Input() initialModel: Record<string, unknown> = {};
  @Input() showSubmit = true;
  @Input() reorderMode = false;
  @Output() modelChange = new EventEmitter<Record<string, unknown>>();
  @Output() validityChange = new EventEmitter<boolean>();
  @Output() submitted = new EventEmitter<Record<string, unknown>>();
  @Output() orderChange = new EventEmitter<string[]>();

  form!: FormGroup;
  fields: DynamicField[] = [];
  private dragFromIndex: number | null = null;
  @ViewChildren('card') cards!: QueryList<ElementRef<HTMLElement>>;

  private subs: Subscription[] = [];
  private selectItems = new Map<string, { label: string; value: string }[]>();
  private selectDeps = new Map<string, Subscription[]>();

  private fb = inject(FormBuilder);
  private validators = inject(ValidatorsFactory);
  public mapper = inject(FieldMapperService);
  readonly deps = inject(DependenciesEngine);
  private autoFill = inject(AutofillService);
  private http = inject(HttpClient);

  private setupForm(): void {
    this.fields = orderFields(this.schema);
    this.form = this.fb.group({});
    this.fields.forEach(field => {
      const init = initialValueOf(field, this.initialModel);
      const ctrl = this.fb.control(init, {
        validators: this.validators.buildValidators(field),
        updateOn: 'change',
      });

      if (field.disabled) ctrl.disable({ emitEvent: false });

      this.form.addControl(field.name, ctrl);

      if ((this.isSelect(field) || this.isMultiSelect(field)) && field.ui?.dataSource) {
        this.loadSelectItems(field);
      }
    });

    this.deps.setup(this.form, this.schema);
    this.autoFill.register(this.form, this.schema);

    const vSub = this.form.valueChanges
      .pipe(debounceTime(150))
      .subscribe(v => this.modelChange.emit(v));
    const sSub = this.form.statusChanges.subscribe(() => this.validityChange.emit(this.form.valid));
    this.subs.push(vSub, sSub);
  }

  ngOnInit(): void {
    this.setupForm();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['schema']) {
      this.subs.forEach(s => s.unsubscribe());
      this.subs = [];
      this.autoFill.cleanup();
      this.selectDeps.forEach(list => list.forEach(s => s.unsubscribe()));
      this.selectDeps.clear();
      this.setupForm();
    }

    if (changes['reorderMode']) {
      const active = this.reorderMode === true;
      this.fields.forEach(f => {
        const ctrl = this.form.get(f.name);

        if (!ctrl) return;

        if (active) ctrl.disable({ emitEvent: false });
        else if (!f.disabled) ctrl.enable({ emitEvent: false });
      });
    }
  }

  ngOnDestroy(): void {
    this.subs.forEach(s => s.unsubscribe());
    this.autoFill.cleanup();
    this.selectDeps.forEach(list => list.forEach(s => s.unsubscribe()));
  }

  isText(f: DynamicField): boolean {
    return f.widget === 'text';
  }

  isNumber(f: DynamicField): boolean {
    return f.widget === 'number';
  }

  isTextarea(f: DynamicField): boolean {
    return f.widget === 'textarea';
  }

  isCheckbox(f: DynamicField): boolean {
    return f.widget === 'checkbox';
  }

  isSelect(f: DynamicField): boolean {
    return f.widget === 'select';
  }

  isMultiSelect(f: DynamicField): boolean {
    return f.widget === 'multiselect';
  }

  isDate(f: DynamicField): boolean {
    return f.widget === 'datepicker' || f.widget === 'calendar';
  }

  isColor(f: DynamicField): boolean {
    return f.widget === 'color';
  }

  isAutocomplete(f: DynamicField): boolean {
    return f.widget === 'autocomplete';
  }

  isConfirmDialog(f: DynamicField): boolean {
    return f.widget === 'confirmDialog';
  }

  maxLengthOf(field: DynamicField): string | number {
    const rules = field.validations ?? [];
    const rule = rules.find(r => r.name === 'maxLength');

    if (!rule) return '';

    const n = Number(rule.value);

    return Number.isFinite(n) && n > 0 ? n : '';
  }

  isFile(f: DynamicField): boolean {
    return f.widget === 'fileupload';
  }

  errorOf(field: DynamicField): string {
    return firstErrorMessage(this.form, field.name, field);
  }

  isKey(msg: string): boolean {
    return /^(?:[a-zA-Z]+\.)[\w.]+$/.test(String(msg ?? ''));
  }

  hasCustomMessage(field: DynamicField): boolean {
    return (field.validations ?? []).some(
      v => typeof v.message === 'string' && v.message.trim().length > 0,
    );
  }

  labelKeyOf(field: DynamicField): string {
    const explicit = field.labelKey;

    if (explicit && explicit.startsWith('FIELDS.')) {
      const raw = explicit.substring('FIELDS.'.length);
      const camel = raw
        .toLowerCase()
        .split('_')
        .map((part, idx) => (idx === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1)))
        .join('');

      return `form.fields.${camel}`;
    }

    if (explicit) return explicit;

    return `form.fields.${field.name}`;
  }

  typeaheadMinLength(field: DynamicField): number {
    const rule = (field.validations ?? []).find(r => r.name === 'minLength');
    const n = Number(rule?.value);

    return Number.isFinite(n) && n > 0 ? n : 2;
  }

  onFileChange(event: Event, name: string): void {
    const input = event.target as HTMLInputElement;
    this.form.get(name)?.setValue(input.files ?? null);
  }

  dataSource(field: DynamicField): (q: string) => Observable<unknown[]> {
    // Preferir autoFill.api como fonte para sugestões quando widget=autocomplete
    let baseUrl = '';
    const ds = field.ui?.dataSource;

    if (typeof ds === 'string') baseUrl = ds;
    else if (ds && typeof ds === 'object') baseUrl = ds.url ?? '';

    if (!baseUrl && field.autoFill?.api) baseUrl = field.autoFill.api;

    if (!baseUrl)
      return () =>
        new Observable<unknown[]>(obs => {
          obs.next([]);
          obs.complete();
        });

    const isAbsolute = /^https?:\/\//i.test(baseUrl);

    if (!isAbsolute && !baseUrl.startsWith('/')) baseUrl = `/${baseUrl}`;

    const minLenRule = (field.validations ?? []).find(r => r.name === 'minLength');
    const minLenVal = Number(minLenRule?.value);
    const minLen = Number.isFinite(minLenVal) && minLenVal > 0 ? minLenVal : 2;
    const qp = 'q';

    return (q: string) => {
      const queryText = String(q ?? '');

      if (queryText.length < minLen)
        return new Observable<unknown[]>(obs => {
          obs.next([]);
          obs.complete();
        });

      const sep = baseUrl.includes('?') ? '&' : '?';

      return this.http.get<unknown[]>(`${baseUrl}${sep}${qp}=${encodeURIComponent(queryText)}`);
    };
  }

  itemsOf(field: DynamicField): { label: string; value: string }[] {
    const cached = this.selectItems.get(field.name);

    if (cached && cached.length > 0) return cached;

    return this.mapper.selectItems(field);
  }

  private loadSelectItems(field: DynamicField): void {
    let baseUrl = '';
    const ds = field.ui?.dataSource;

    if (typeof ds === 'string') baseUrl = ds;
    else if (ds && typeof ds === 'object') baseUrl = ds.url ?? '';

    if (!baseUrl) return;

    const isAbsolute = /^https?:\/\//i.test(baseUrl);

    if (!isAbsolute && !baseUrl.startsWith('/')) baseUrl = `/${baseUrl}`;

    const tokenRegex = /\{\{([a-zA-Z0-9_]+)\}\}/g;
    const tokens: string[] = [];
    let m: RegExpExecArray | null;

    while ((m = tokenRegex.exec(baseUrl)) !== null) tokens.push(m[1]);

    const fetch = (): void => {
      let url = baseUrl;

      for (const t of tokens) {
        const ctrl = this.form.get(t);
        const val = String(ctrl?.value ?? '');

        if (!val) {
          this.selectItems.set(field.name, []);

          return;
        }

        url = url.replace(`{{${t}}}`, encodeURIComponent(val));
      }

      this.http.get<Record<string, unknown>[]>(url).subscribe({
        next: rows => {
          const keyProp = field.ui?.bindKey || 'id';
          const labelProp = field.ui?.bindLabel || 'label';

          const mapped = rows
            .map(obj => {
              const v = String(obj[keyProp] ?? '');
              const l = String(obj[labelProp] ?? v);

              if (!v) return null;

              return { label: l, value: v };
            })
            .filter((x): x is { label: string; value: string } => !!x);

          this.selectItems.set(field.name, mapped);
        },
        error: () => {
          this.selectItems.set(field.name, []);
        },
      });
    };

    if (tokens.length === 0) fetch();
    else {
      const subs: Subscription[] = [];
      tokens.forEach(t => {
        const ctrl = this.form.get(t);

        if (!ctrl) return;

        const s = ctrl.valueChanges.subscribe(() => fetch());
        subs.push(s);
      });
      this.selectDeps.set(field.name, subs);
      fetch();
    }
  }

  onSubmit(): void {
    const mustConfirm = this.schema.submit?.confirm === true;
    const text = this.schema.submit?.confirmationText ?? 'Confirmar envio?';

    if (mustConfirm && !window.confirm(text)) return;

    this.submitted.emit(this.form.getRawValue());
  }

  onConfirmField(name: string): void {
    const field = this.fields.find(f => f.name === name);

    if (!field) return;

    const text = String(field.ui?.confirmationText ?? 'Confirmar ação?');

    if (window.confirm(text)) this.form.get(name)?.setValue(true);
    else this.form.get(name)?.setValue(false);
  }

  onDragStart(index: number): void {
    if (!this.reorderMode) return;

    this.dragFromIndex = index;
  }

  onDragOver(index: number, event: DragEvent): void {
    if (!this.reorderMode) return;

    event.preventDefault();
  }

  onDrop(index: number): void {
    if (!this.reorderMode) return;

    if (this.dragFromIndex === null) return;

    const list = [...this.fields];
    const prevRects = new Map<string, DOMRect>();
    this.cards.forEach((el, idx) =>
      prevRects.set(this.fields[idx].name, el.nativeElement.getBoundingClientRect()),
    );

    if (index === this.dragFromIndex) {
      this.dragFromIndex = null;

      return;
    }

    const a = this.dragFromIndex;
    const b = index;
    const tmp = list[b];
    list[b] = list[a];
    list[a] = tmp;
    this.fields = list.slice();
    this.dragFromIndex = null;
    this.orderChange.emit(this.fields.map(f => f.name));

    setTimeout(() => {
      if (!this.reorderMode) return;

      this.cards.forEach((el, idx) => {
        const name = this.fields[idx].name;
        const prev = prevRects.get(name);

        if (!prev) return;

        const now = el.nativeElement.getBoundingClientRect();
        const dx = prev.left - now.left;
        const dy = prev.top - now.top;

        if (dx === 0 && dy === 0) return;

        const node = el.nativeElement;
        node.style.transition = 'none';
        node.style.transform = `translate(${dx}px, ${dy}px) scale(1.02)`;
        node.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
        node.style.willChange = 'transform, box-shadow';
        requestAnimationFrame(() => {
          node.style.transition = 'transform 350ms ease-in-out, box-shadow 350ms ease-in-out';
          node.style.transform = 'translate(0, 0) scale(1)';
          node.style.boxShadow = '';
          setTimeout(() => {
            node.style.transition = '';
            node.style.willChange = '';
          }, 360);
        });
      });
    }, 0);
  }
}
