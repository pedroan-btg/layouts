export type WidgetType =
  | 'text'
  | 'number'
  | 'textarea'
  | 'checkbox'
  | 'select'
  | 'multiselect'
  | 'datepicker'
  | 'calendar'
  | 'fileupload'
  | 'autocomplete'
  | 'color'
  | 'confirmDialog';

export interface SimpleCondition {
  field: string;
  regex?: string;
  equals?: unknown;
  value?: unknown;
  notEquals?: unknown;
  true?: boolean;
  false?: boolean;
  notEmpty?: boolean;
  valid?: boolean;
}

export interface ConditionGroup {
  all?: Condition[];
  any?: Condition[];
  not?: Condition;
}

export type Condition = SimpleCondition | ConditionGroup;

export interface ValidationRule {
  name: string;
  value?: unknown;
  message?: string;
}

export interface DataSourceConfig {
  url: string;
  queryParam?: string;
  minLength?: number;
}

export interface AutoFillConfig {
  triggerField: string;
  api: string;
  behavior: 'ask' | 'replace' | 'fillEmpty';
  debounceMs?: number;
  map: Record<string, string>;
}

export interface FieldUiConfig {
  mask?: string;
  tabIndex?: number;
  dataSource?: string | DataSourceConfig;
  confirmationText?: string;
  bindKey?: string;
  bindLabel?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  hint?: string;
}

export interface DynamicField {
  name: string;
  label?: string;
  labelKey?: string;
  widget: WidgetType;
  tabIndex?: number;
  required?: boolean;
  disabled?: boolean;
  invisible?: boolean;
  values?: string[];
  validations?: ValidationRule[];
  dependencies?: {
    visibleIf?: Condition;
    enableIf?: Condition;
  };
  autoFill?: AutoFillConfig;
  ui?: FieldUiConfig;
  order?: number;
}

export interface SubmitUi {
  confirm?: boolean;
  confirmationText?: string;
}

export interface DynamicFormSchema {
  fields: DynamicField[];
  submit?: SubmitUi;
}
