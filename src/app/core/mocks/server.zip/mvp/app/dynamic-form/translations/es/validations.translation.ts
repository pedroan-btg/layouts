export const DynamicFormEsValidations = {
  form: {
    errors: {
      required: 'Este campo es obligatorio',
      min: 'El valor está por debajo del mínimo',
      max: 'El valor excede el máximo',
      minLength: 'El texto es más corto de lo permitido',
      maxLength: 'El texto es más largo de lo permitido',
      pattern: 'El valor no coincide con el formato esperado',
      integerOnly: 'Solo se permiten números enteros',
      decimalPlaces: 'Demasiados decimales',
      notPast: 'La fecha no puede estar en el pasado',
      notFuture: 'La fecha no puede estar en el futuro',
      maxDiffDays: 'La diferencia excede los días permitidos',
      multiSelectLimit: 'Seleccionaste más elementos de lo permitido',
      maxDiffMonths: 'La diferencia excede los meses permitidos',
      enumMatch: 'El valor no coincide con las opciones permitidas',
      invalid: 'Valor inválido',
    },
  },
};
