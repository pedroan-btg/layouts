import { DynamicField } from './types';

export function initialValueOf(
  field: DynamicField,
  initialModel: Record<string, unknown>,
): unknown {
  const preset = initialModel?.[field.name];

  if (preset !== undefined) return preset;

  switch (field.widget) {
    case 'checkbox':
      return false;
    case 'multiselect':
      return [];
    case 'number':
      return null;
    case 'datepicker':
    case 'calendar':
    case 'fileupload':
    case 'select':
    case 'autocomplete':
      return null;
    case 'textarea':
    case 'text':
    default:
      return '';
  }
}
