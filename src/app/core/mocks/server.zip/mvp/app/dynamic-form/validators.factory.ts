import { Injectable } from '@angular/core';
import { AbstractControl, ValidatorFn, Validators } from '@angular/forms';
import { DynamicField, ValidationRule } from './types';

@Injectable({ providedIn: 'root' })
export class ValidatorsFactory {
  buildValidators(field: DynamicField): ValidatorFn[] {
    const validators: ValidatorFn[] = [];

    if (field.required) {
      if (field.widget === 'autocomplete') {
        validators.push(this.requiredAutocomplete(field));
      } else {
        validators.push(Validators.required);
      }
    }

    (field.validations ?? []).forEach(v => {
      // Para plateNumber, não usamos o pattern do schema (case-sensitive),
      // e deixamos apenas o validador interno que trata maiúsculas/minúsculas.
      if (field.name === 'plateNumber' && v.name === 'pattern') {
        return;
      }

      const fn = this.toValidator(v);

      if (fn) validators.push(fn);
    });

    if (field.name === 'plateNumber') {
      validators.push(this.plateFormatValidator());
    }

    return validators;
  }

  // Normaliza valores de data vindos do input (Date, 'YYYY-MM-DD' ou 'DD/MM/YYYY')
  private parseDateValue(value: unknown): Date | null {
    if (value instanceof Date) {
      const d = new Date(value);
      d.setHours(0, 0, 0, 0);

      return d;
    }

    if (typeof value === 'string') {
      const s = value.trim();

      // ISO (do input type="date"): YYYY-MM-DD — interpretar como data LOCAL
      const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);

      if (iso) {
        const y = Number(iso[1]);
        const m = Number(iso[2]) - 1;
        const d = Number(iso[3]);
        const dt = new Date(y, m, d);
        dt.setHours(0, 0, 0, 0);

        return dt;
      }

      // Formato brasileiro: DD/MM/YYYY — interpretar como data LOCAL
      const br = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

      if (br) {
        const d = Number(br[1]);
        const m = Number(br[2]) - 1;
        const y = Number(br[3]);
        const dt = new Date(y, m, d);
        dt.setHours(0, 0, 0, 0);

        return dt;
      }

      // Fallback
      const dt = new Date(s);

      if (!isNaN(dt.getTime())) {
        dt.setHours(0, 0, 0, 0);

        return dt;
      }
    }

    return null;
  }

  private todayMidnight(): Date {
    const now = new Date();
    now.setHours(0, 0, 0, 0);

    return now;
  }

  private toValidator(v: ValidationRule): ValidatorFn | null {
    switch (v.name) {
      case 'min':
        return Validators.min(Number(v.value ?? 0));
      case 'max':
        return Validators.max(Number(v.value ?? Number.MAX_SAFE_INTEGER));
      case 'minLength':
        return Validators.minLength(Number(v.value ?? 0));
      case 'maxLength':
        return Validators.maxLength(Number(v.value ?? 99999));
      case 'pattern':
        return Validators.pattern(String(v.value ?? ''));
      case 'cpf':
        return this.cpfValidator();
      case 'integerOnly':
        return (c: AbstractControl) =>
          c.value === null || c.value === undefined || c.value === ''
            ? null
            : /^-?\d+$/.test(String(c.value))
              ? null
              : { integerOnly: true };
      case 'decimalPlaces':
        return (c: AbstractControl) => {
          const places = Number(v.value ?? 2);

          if (c.value === null || c.value === undefined || c.value === '') return null;

          const m = String(c.value).match(/^(.*)\.(\d+)$/);

          return m && m[2].length <= places ? null : { decimalPlaces: true };
        };
      case 'notPast':
        return (c: AbstractControl) => {
          if (!c.value) return null;

          const d = this.parseDateValue(c.value);

          if (!d) return null; // valor ilegível: não bloquear

          const now = this.todayMidnight();

          return d >= now ? null : { notPast: true };
        };
      case 'notFuture':
        return (c: AbstractControl) => {
          if (!c.value) return null;

          const d = this.parseDateValue(c.value);

          if (!d) return null; // valor ilegível: não bloquear

          const now = this.todayMidnight();

          return d <= now ? null : { notFuture: true };
        };
      case 'enumMatch':
        return (c: AbstractControl) => {
          const list = Array.isArray(v.value) ? v.value : [];

          return list.includes(c.value) ? null : { enumMatch: true };
        };
      case 'multiSelectLimit':
        return (c: AbstractControl) => {
          const limit = Number(v.value ?? 0);
          const arr = Array.isArray(c.value) ? c.value : [];

          return arr.length <= limit ? null : { multiSelectLimit: true };
        };
      default:
        return null;
    }
  }

  private requiredAutocomplete(field: DynamicField): ValidatorFn {
    const key = field.ui?.bindKey || 'value';

    return (c: AbstractControl) => {
      const v = c.value;

      // Empty string, null or undefined => invalid
      if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) {
        return { required: true };
      }

      // If object, require configured key to be present and non-empty
      if (typeof v === 'object') {
        const obj = v as Record<string, unknown>;
        const val = obj[key];

        if (
          val === null ||
          val === undefined ||
          (typeof val === 'string' && String(val).trim() === '')
        ) {
          return { required: true };
        }
      }

      return null;
    };
  }

  private cpfValidator(): ValidatorFn {
    return (c: AbstractControl) => {
      const raw = (c.value ?? '').toString();
      const digits = raw.replace(/\D+/g, '');

      if (digits === '') return null;

      if (digits.length !== 11) return { cpf: true };

      if (/^(\d)\1{10}$/.test(digits)) return { cpf: true };

      const calcDigit = (base: string, startWeight: number): number => {
        let sum = 0;

        for (let i = 0; i < base.length; i++) {
          sum += Number(base[i]) * (startWeight - i);
        }

        const r = sum % 11;

        return r < 2 ? 0 : 11 - r;
      };

      const d1 = calcDigit(digits.slice(0, 9), 10);

      if (d1 !== Number(digits[9])) return { cpf: true };

      const d2 = calcDigit(digits.slice(0, 10), 11);

      if (d2 !== Number(digits[10])) return { cpf: true };

      return null;
    };
  }

  private plateFormatValidator(): ValidatorFn {
    const regex = /^[A-Z]{3}-?[0-9]{4}$/;

    return (c: AbstractControl) => {
      const rawValue = (c.value ?? '').toString();
      const normalizedValue = rawValue.toUpperCase().replace(/\s+/g, '').replace(/_/g, '');

      if (normalizedValue === '') return null;

      return regex.test(normalizedValue) ? null : { pattern: true };
    };
  }
}
