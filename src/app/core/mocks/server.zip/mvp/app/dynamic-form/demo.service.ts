import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DynamicFormSchema } from './types';

@Injectable({ providedIn: 'root' })
export class DynamicFormDemoService {
  constructor(private http: HttpClient) {}

  loadSchema(): Observable<DynamicFormSchema> {
    return this.http.get<DynamicFormSchema>('/api/dynamic-form/motor-home');
  }
}
