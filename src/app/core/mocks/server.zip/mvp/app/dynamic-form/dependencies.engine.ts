import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Condition, DynamicFormSchema } from './types';

export function evalCondition(
  cond: Condition | undefined,
  form: FormGroup,
  values: Record<string, unknown>,
): boolean {
  if (!cond) return true;

  const isGroup = (c: any) => c && (Array.isArray(c.all) || Array.isArray(c.any) || c.not);

  const evalSimple = (c: any): boolean => {
    const val = values?.[c.field];
    const ctrl = form.get(c.field);

    const normalize = (x: unknown): unknown => {
      if (typeof x === 'string') {
        const t = x.trim().toLowerCase();

        if (t === 'true') return true;

        if (t === 'false') return false;

        const n = Number(x);

        if (!Number.isNaN(n) && String(n) === x) return n;
      }

      return x;
    };

    const normVal = normalize(val);

    if (c.regex) {
      try {
        const re = new RegExp(c.regex);

        return re.test(String(val ?? ''));
      } catch {
        return false;
      }
    }

    if (c.value !== undefined) return normVal === normalize(c.value);

    if (c.equals !== undefined) return normVal === normalize(c.equals);

    if (c.valid !== undefined && ctrl) return c.valid ? ctrl.valid : ctrl.invalid;

    if (c.notEquals !== undefined) return normVal !== normalize(c.notEquals);

    if (c.true) return Boolean(normVal) === true;

    if (c.false) return Boolean(normVal) === false;

    if (c.notEmpty) return normVal !== null && normVal !== undefined && normVal !== '';

    return Boolean(normVal);
  };

  if (isGroup(cond)) {
    if ((cond as any).not) return !evalCondition((cond as any).not as any, form, values);

    if ((cond as any).all)
      return ((cond as any).all as any[]).every(c => evalCondition(c as any, form, values));

    if ((cond as any).any)
      return ((cond as any).any as any[]).some(c => evalCondition(c as any, form, values));

    return true;
  }

  return evalSimple(cond as any);
}

export function referencesSelf(cond: Condition | undefined, name: string): boolean {
  if (!cond) return false;

  const isGroup = (c: any) => c && (Array.isArray(c.all) || Array.isArray(c.any) || c.not);

  if (isGroup(cond)) {
    if ((cond as any).not) return referencesSelf((cond as any).not as any, name);

    if ((cond as any).all)
      return ((cond as any).all as any[]).some(c => referencesSelf(c as any, name));

    if ((cond as any).any)
      return ((cond as any).any as any[]).some(c => referencesSelf(c as any, name));

    return false;
  }

  return (cond as any).field === name;
}

export function applyDependencies(
  form: FormGroup,
  schema: DynamicFormSchema,
  visibility: Map<string, boolean>,
  availability: Map<string, boolean>,
): void {
  const values = form.getRawValue();

  schema.fields.forEach(field => {
    const control = form.get(field.name);

    if (!control) return;

    const hasVisibleIf = !!field.dependencies?.visibleIf;
    const hasEnableIf = !!field.dependencies?.enableIf;
    const isSelfVisibilityRule = referencesSelf(field.dependencies?.visibleIf, field.name);
    const visible = hasVisibleIf
      ? evalCondition(field.dependencies?.visibleIf, form, values)
      : !field.invisible;
    visibility.set(field.name, visible);

    const visibleForAvailability = isSelfVisibilityRule ? true : visible;
    const shouldEnable = evalCondition(field.dependencies?.enableIf, form, values);
    const enabled = hasEnableIf
      ? visibleForAvailability && shouldEnable
      : visibleForAvailability && field.disabled !== true;
    availability.set(field.name, enabled);

    if (enabled && control.disabled) {
      control.enable({ emitEvent: false });
    } else if (!enabled && control.enabled) {
      control.disable({ emitEvent: false });
      // Não resetamos valores automaticamente para evitar loops de valueChanges
    }
  });
}

@Injectable({ providedIn: 'root' })
export class DependenciesEngine {
  visibility = new Map<string, boolean>();
  availability = new Map<string, boolean>();

  setup(form: FormGroup, schema: DynamicFormSchema): void {
    applyDependencies(form, schema, this.visibility, this.availability);
    form.valueChanges.subscribe(() => {
      applyDependencies(form, schema, this.visibility, this.availability);
    });
  }

  isVisible(name: string): boolean {
    return this.visibility.get(name) ?? true;
  }

  isEnabled(name: string): boolean {
    return this.availability.get(name) ?? true;
  }
}
