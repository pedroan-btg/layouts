import { Component, ChangeDetectionStrategy, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import {
  ReactiveFormsModule,
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { Input as FtsInput } from 'fts-frontui/input';
import { Select as FtsSelect } from 'fts-frontui/select';
import { Selection as FtsSelection } from 'fts-frontui/selection';
//import motorHome from '../../../mocks/json/motor-home.json';

@Component({
  selector: '[fts-dynamic-form-demo]',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FtsInput, FtsSelect, FtsSelection],
  template: `
    <div class="container py-3">
      <h5 class="mb-3">Dynamic Form Demo (Inline - Isolado)</h5>
      <form [formGroup]="form" class="row g-3" (ngSubmit)="onSubmit()">
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="plateNumber"
            label="Placa"
            type="text"
            mask="AAA-0000"
            [tabIndex]="1"></fts-input>
          @if (errorOf('plateNumber')) {
            <div class="mt-2 text-danger small">{{ errorOf('plateNumber') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="chassisNumber"
            label="Chassi"
            type="text"
            [maxlength]="17"
            [tabIndex]="2"></fts-input>
          @if (errorOf('chassisNumber')) {
            <div class="mt-2 text-danger small">{{ errorOf('chassisNumber') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="manufacturer"
            label="Fabricante"
            type="autocomplete"
            bindKey="id"
            bindLabel="label"
            [data]="dataManufacturers"
            [typeaheadMinLength]="2"
            [tabIndex]="3"></fts-input>
          @if (errorOf('manufacturer')) {
            <div class="mt-2 text-danger small">{{ errorOf('manufacturer') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="model"
            label="Modelo"
            type="autocomplete"
            bindKey="id"
            bindLabel="label"
            [data]="dataModels"
            [typeaheadMinLength]="2"
            [tabIndex]="4"></fts-input>
          @if (errorOf('model')) {
            <div class="mt-2 text-danger small">{{ errorOf('model') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="manufactureYear"
            label="Ano de fabricação"
            type="text"
            mask="0000"
            [tabIndex]="5"></fts-input>
          @if (errorOf('manufactureYear')) {
            <div class="mt-2 text-danger small">{{ errorOf('manufactureYear') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">Cor</label>
          <input
            type="color"
            class="form-control form-control-color w-100"
            formControlName="color"
            [attr.tabindex]="6" />
          @if (errorOf('color')) {
            <div class="mt-2 text-danger small">{{ errorOf('color') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-select
            formControlName="fuelType"
            label="Combustível"
            bindLabel="label"
            bindValue="value"
            [items]="fuelTypes"
            [clearable]="true"
            [tabIndex]="7"></fts-select>
          @if (errorOf('fuelType')) {
            <div class="mt-2 text-danger small">{{ errorOf('fuelType') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasSolarPanels"
              label="Possui painéis solares?"
              type="checkbox"
              [tabIndex]="9"></fts-selection>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-select
            formControlName="transmissionType"
            label="Transmissão"
            bindLabel="label"
            bindValue="value"
            [items]="transmissionOptions"
            [clearable]="true"
            [tabIndex]="8"></fts-select>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="solarPowerCapacity"
            label="Capacidade dos painéis"
            type="text"
            [suffix]="'Watts'"
            [tabIndex]="10"></fts-input>
          @if (errorOf('solarPowerCapacity')) {
            <div class="mt-2 text-danger small">{{ errorOf('solarPowerCapacity') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-select
            formControlName="batteryType"
            label="Tipo de bateria"
            bindLabel="label"
            bindValue="value"
            [items]="batteryTypeOptions"
            [clearable]="true"
            [tabIndex]="11"></fts-select>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="batteryCapacity"
            label="Capacidade da bateria"
            type="text"
            mask="000"
            [suffix]="'Ah'"
            [tabIndex]="12"></fts-input>
          @if (errorOf('batteryCapacity')) {
            <div class="mt-2 text-danger small">{{ errorOf('batteryCapacity') }}</div>
          }
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasGenerator"
              label="Possui gerador?"
              type="checkbox"
              [tabIndex]="13"></fts-selection>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="generatorPower"
            label="Potência do gerador"
            type="text"
            [suffix]="'kVA'"
            [tabIndex]="14"></fts-input>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasBathroom"
              label="Possui banheiro?"
              type="checkbox"
              [tabIndex]="15"></fts-selection>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-select
            formControlName="showerType"
            label="Tipo de chuveiro"
            bindLabel="label"
            bindValue="value"
            [items]="showerTypeOptions"
            [clearable]="true"
            [tabIndex]="16"></fts-select>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasHotWater"
              label="Possui água quente?"
              type="checkbox"
              [tabIndex]="17"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-select
            formControlName="kitchenType"
            label="Tipo de cozinha"
            bindLabel="label"
            bindValue="value"
            [items]="kitchenTypeOptions"
            [clearable]="true"
            [tabIndex]="18"></fts-select>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasFridge"
              label="Possui geladeira?"
              type="checkbox"
              [tabIndex]="19"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasMicrowave"
              label="Possui micro-ondas?"
              type="checkbox"
              [tabIndex]="20"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasFireExtinguisher"
              label="Possui extintor?"
              type="checkbox"
              [tabIndex]="21"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasFirstAidKit"
              label="Possui kit primeiros socorros?"
              type="checkbox"
              [tabIndex]="22"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasGPS"
              label="Possui GPS?"
              type="checkbox"
              [tabIndex]="23"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 43.78px;">
            <fts-selection
              formControlName="hasReverseCamera"
              label="Possui câmera de ré?"
              type="checkbox"
              [tabIndex]="24"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 38px;">
            <fts-selection
              formControlName="hasAlarm"
              label="Possui alarme?"
              type="checkbox"
              [tabIndex]="25"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 38px;">
            <fts-selection
              formControlName="tirePressureSystem"
              label="Possui sistema de pressão dos pneus?"
              type="checkbox"
              [tabIndex]="26"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="zipCode"
            label="CEP"
            type="text"
            mask="00000-000"
            [tabIndex]="27"></fts-input>
          @if (errorOf('zipCode')) {
            <div class="mt-2 text-danger small">{{ errorOf('zipCode') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input formControlName="state" label="Estado" type="text" [tabIndex]="28"></fts-input>
          @if (errorOf('state')) {
            <div class="mt-2 text-danger small">{{ errorOf('state') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input formControlName="city" label="Cidade" type="text" [tabIndex]="29"></fts-input>
          @if (errorOf('city')) {
            <div class="mt-2 text-danger small">{{ errorOf('city') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input formControlName="street" label="Rua" type="text" [tabIndex]="30"></fts-input>
          @if (errorOf('street')) {
            <div class="mt-2 text-danger small">{{ errorOf('street') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="insuranceExpiration"
            label="Vencimento do seguro"
            type="date"
            [tabIndex]="31"></fts-input>
          @if (errorOf('insuranceExpiration')) {
            <div class="mt-2 text-danger small">{{ errorOf('insuranceExpiration') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="lastMaintenanceDate"
            label="Última manutenção"
            type="date"
            [tabIndex]="32"></fts-input>
          @if (errorOf('lastMaintenanceDate')) {
            <div class="mt-2 text-danger small">{{ errorOf('lastMaintenanceDate') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="maintenanceWorkshop"
            label="Oficina de manutenção"
            type="text"
            [tabIndex]="33"></fts-input>
          @if (errorOf('maintenanceWorkshop')) {
            <div class="mt-2 text-danger small">{{ errorOf('maintenanceWorkshop') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">&nbsp;</label>
          <div class="d-flex align-items-center" style="min-height: 38px;">
            <fts-selection
              formControlName="hasInspectionReport"
              label="Possui laudo de inspeção?"
              type="checkbox"
              [tabIndex]="34"></fts-selection>
          </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">Laudo de inspeção</label>
          <input
            type="file"
            class="form-control"
            [disabled]="!form.get('hasInspectionReport')?.value"
            (change)="
              form.get('inspectionReportFile')?.setValue($event.target.files);
              form.get('inspectionReportFile')?.updateValueAndValidity()
            "
            [attr.tabindex]="35" />
          <div class="mt-2 small">
            {{ form.get('inspectionReportFile')?.value?.length || 0 }} arquivo(s) selecionado(s)
          </div>
          @if (errorOf('inspectionReportFile')) {
            <div class="mt-2 text-danger small">{{ errorOf('inspectionReportFile') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <fts-input
            formControlName="estimatedValue"
            label="Valor estimado"
            type="text"
            mask="currency"
            [currency]="'BRL'"
            [tabIndex]="36"></fts-input>
          @if (errorOf('estimatedValue')) {
            <div class="mt-2 text-danger small">{{ errorOf('estimatedValue') }}</div>
          }
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
          <label class="form-label">Fotos do veículo</label>
          <input
            type="file"
            multiple
            class="form-control"
            (change)="
              form.get('vehiclePhotos')?.setValue($event.target.files);
              form.get('vehiclePhotos')?.updateValueAndValidity()
            "
            [attr.tabindex]="37" />
          <div class="mt-2 small">
            {{ form.get('vehiclePhotos')?.value?.length || 0 }} foto(s) selecionada(s)
          </div>
          @if (errorOf('vehiclePhotos')) {
            <div class="mt-2 text-danger small">{{ errorOf('vehiclePhotos') }}</div>
          }
        </div>

        <div class="col-12 mt-2">
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DynamicFormDemoComponent implements OnInit {
  private fb = inject(FormBuilder);
  private http = inject(HttpClient);

  // Campos adicionais removidos para isolamento incremental
  fuelTypes = [
    { label: 'Diesel', value: 'diesel' },
    { label: 'Gasolina', value: 'gasoline' },
    { label: 'Elétrico', value: 'electric' },
    { label: 'Híbrido', value: 'hybrid' },
  ];

  featuresItems = [
    { label: 'Ar condicionado', value: 'ac' },
    { label: 'Geladeira', value: 'fridge' },
    { label: 'Cozinha', value: 'kitchen' },
    { label: 'GPS', value: 'gps' },
    { label: 'Câmera de ré', value: 'reverse' },
  ];

  form: FormGroup = this.fb.group({
    plateNumber: ['', [Validators.required, this.plateValidator()]],
    chassisNumber: ['', [Validators.required, Validators.minLength(17), Validators.maxLength(17)]],
    manufactureYear: ['', [Validators.required, Validators.min(1980), this.maxDateYearValidator()]],
    fuelType: ['', [Validators.required]],
    features: [[], [this.multiSelectLimitValidator(3)]],
    hasSolarPanels: [false],
    inspectionDate: ['', [Validators.required, this.notFutureValidator()]],
    notes: ['', [Validators.maxLength(500)]],
    manufacturer: [null, [Validators.required]],
    model: [null, [Validators.required]],
    color: ['', [Validators.pattern(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/)]],
    transmissionType: [''],
    hasHotWater: [false],
    kitchenType: [''],
    hasFridge: [false],
    hasMicrowave: [false],
    hasFireExtinguisher: [false],
    hasFirstAidKit: [false],
    hasGPS: [false],
    hasReverseCamera: [false],
    hasAlarm: [false],
    tirePressureSystem: [false],
    solarPowerCapacity: [null, [Validators.min(100), Validators.max(1000)]],
    batteryType: [''],
    batteryCapacity: [null, [Validators.min(50), Validators.max(600), this.integerOnlyValidator()]],
    hasGenerator: [false],
    generatorPower: [null],
    hasBathroom: [false],
    showerType: [''],
    zipCode: ['', [Validators.required, Validators.pattern(/^\d{5}-\d{3}$/)]],
    state: [{ value: '', disabled: true }],
    city: [{ value: '', disabled: true }],
    street: [{ value: '', disabled: true }],
    insuranceExpiration: ['', [this.notPastValidator(), this.maxDiffMonthsValidator(12)]],
    lastMaintenanceDate: ['', [this.notFutureValidator(), this.maxDiffMonthsValidator(24)]],
    maintenanceWorkshop: [''],
    hasInspectionReport: [false],
    inspectionReportFile: [
      null,
      [this.fileTypesValidator(['.pdf', '.jpg']), this.maxSizeMBValidator(5)],
    ],
    estimatedValue: [null, [Validators.min(10000), Validators.max(2000000)]],
    vehiclePhotos: [null, [this.fileTypesValidator(['.jpg', '.png']), this.maxFilesValidator(10)]],
    confirmation: [false],
  });

  errorOf(name: string): string {
    const c = this.form.get(name);

    if (!c) return '';

    if (c.touched && c.invalid) {
      const err = c.errors || {};

      if (err['required']) return 'form.errors.required';

      if (err['min']) return 'form.errors.min';

      if (err['max']) return 'form.errors.max';

      if (err['minlength']) return 'form.errors.minLength';

      if (err['maxlength']) return 'form.errors.maxLength';

      if (err['pattern']) return 'form.errors.pattern';

      if (err['integerOnly']) return 'form.errors.integerOnly';

      if (err['decimalPlaces']) return 'form.errors.decimalPlaces';

      if (err['notPast']) return 'form.errors.notPast';

      if (err['notFuture']) return 'form.errors.notFuture';

      if (err['maxDiffMonths']) return 'form.errors.maxDiffMonths';

      if (err['multiSelectLimit']) return 'form.errors.multiSelectLimit';

      if (err['fileTypes']) {
        if (name === 'vehiclePhotos') return 'Tipos permitidos: .jpg, .png';

        if (name === 'inspectionReportFile') return 'Tipos permitidos: .pdf, .jpg';

        return 'Tipos de arquivo inválidos';
      }

      if (err['maxSizeMB']) return 'Tamanho máximo: 5 MB';

      if (err['maxFiles']) return 'Quantidade máxima: 10 arquivos';

      return 'form.errors.invalid';
    }

    return '';
  }

  onSubmit(): void {
    this.form.markAllAsTouched();
    const mustConfirm = true;
    const text = 'Confirmar envio das informações do motorhome?';

    if (mustConfirm && !window.confirm(text)) return;

    void this.form.getRawValue();
  }

  ngOnInit(): void {
    const c = this.form.get('plateNumber');

    if (c) {
      c.valueChanges.subscribe(v => {
        const raw = (v ?? '').toString();
        const normalized = raw.toUpperCase().replace(/\s+/g, '');

        if (normalized !== raw) {
          c.setValue(normalized, { emitEvent: false });
          c.updateValueAndValidity({ emitEvent: false });
        }
      });
    }

    const zip = this.form.get('zipCode');
    const state = this.form.get('state');
    const city = this.form.get('city');
    const street = this.form.get('street');

    if (zip && state && city && street) {
      const regex = /^[0-9]{5}-?[0-9]{3}$/;
      zip.valueChanges.subscribe(v => {
        const raw = (v ?? '').toString();
        const isValid = regex.test(raw);

        if (isValid) {
          state.enable({ emitEvent: false });
          city.enable({ emitEvent: false });
          street.enable({ emitEvent: false });
        } else {
          state.disable({ emitEvent: false });
          city.disable({ emitEvent: false });
          street.disable({ emitEvent: false });
          state.setValue('', { emitEvent: false });
          city.setValue('', { emitEvent: false });
          street.setValue('', { emitEvent: false });
        }
      });
    }

    // Dependências baseadas em checkboxes: sempre visíveis, porém desabilitadas até marcar
    const solar = this.form.get('solarPowerCapacity');
    const hasSolar = this.form.get('hasSolarPanels');

    if (solar && hasSolar) {
      solar.disable({ emitEvent: false });
      hasSolar.valueChanges.subscribe(v => {
        if (v) {
          solar.enable({ emitEvent: false });
        } else {
          solar.disable({ emitEvent: false });
          solar.setValue(null, { emitEvent: false });
        }
      });
    }

    const genPower = this.form.get('generatorPower');
    const hasGen = this.form.get('hasGenerator');

    if (genPower && hasGen) {
      genPower.disable({ emitEvent: false });
      hasGen.valueChanges.subscribe(v => {
        if (v) {
          genPower.enable({ emitEvent: false });
        } else {
          genPower.disable({ emitEvent: false });
          genPower.setValue(null, { emitEvent: false });
        }
      });
    }

    const showerType = this.form.get('showerType');
    const hasBathroom = this.form.get('hasBathroom');

    if (showerType && hasBathroom) {
      showerType.disable({ emitEvent: false });
      hasBathroom.valueChanges.subscribe(v => {
        if (v) {
          showerType.enable({ emitEvent: false });
        } else {
          showerType.disable({ emitEvent: false });
          showerType.setValue('', { emitEvent: false });
        }
      });
    }

    const inspFile = this.form.get('inspectionReportFile');
    const hasInsp = this.form.get('hasInspectionReport');

    if (inspFile && hasInsp) {
      inspFile.disable({ emitEvent: false });
      hasInsp.valueChanges.subscribe(v => {
        if (v) {
          inspFile.enable({ emitEvent: false });
        } else {
          inspFile.disable({ emitEvent: false });
          inspFile.setValue(null, { emitEvent: false });
        }
      });
    }
  }

  // --- Validators auxiliares ---
  // Removido validador específico de autocomplete para isolamento

  private plateValidator() {
    // Permite hífen opcional e ignora sublinhado de máscaras
    const rx = /^[A-Z]{3}-?[0-9]{4}$/;

    return (c: FormControl) => {
      const raw = (c.value ?? '').toString();
      const v = raw.toUpperCase().replace(/\s+/g, '').replace(/_/g, '');

      return rx.test(v) ? null : { pattern: true };
    };
  }

  private notPastValidator() {
    return (c: FormControl) => {
      if (!c.value) return null;

      const d = new Date(c.value);
      const now = new Date();
      now.setHours(0, 0, 0, 0);

      return d >= now ? null : { notPast: true };
    };
  }

  private notFutureValidator() {
    return (c: FormControl) => {
      if (!c.value) return null;

      const d = new Date(c.value);
      const now = new Date();
      now.setHours(0, 0, 0, 0);

      return d <= now ? null : { notFuture: true };
    };
  }

  private maxDiffMonthsValidator(maxMonths: number) {
    return (c: FormControl) => {
      if (!c.value) return null;

      const d = new Date(c.value);
      const now = new Date();
      const diff = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());

      return diff <= maxMonths ? null : { maxDiffMonths: true };
    };
  }

  private maxDateYearValidator() {
    return (c: FormControl) => {
      if (!c.value) return null;

      const yr = Number(c.value);
      const nowYr = new Date().getFullYear();

      return yr <= nowYr ? null : { max: true };
    };
  }

  private multiSelectLimitValidator(limit: number) {
    return (c: FormControl) => {
      const v = c.value as unknown[];

      if (!Array.isArray(v)) return null;

      return v.length <= limit ? null : { multiSelectLimit: true };
    };
  }

  private fileTypesValidator(allowed: string[]) {
    return (c: FormControl) => {
      const files = c.value as FileList | null;

      if (!files || files.length === 0) return null;

      for (let i = 0; i < files.length; i++) {
        const name = files[i].name.toLowerCase();

        if (!allowed.some(ext => name.endsWith(ext))) {
          return { fileTypes: true };
        }
      }

      return null;
    };
  }

  private maxSizeMBValidator(maxMb: number) {
    return (c: FormControl) => {
      const files = c.value as FileList | null;

      if (!files || files.length === 0) return null;

      const maxBytes = maxMb * 1024 * 1024;

      for (let i = 0; i < files.length; i++) {
        if (files[i].size > maxBytes) {
          return { maxSizeMB: true };
        }
      }

      return null;
    };
  }

  private maxFilesValidator(maxFiles: number) {
    return (c: FormControl) => {
      const files = c.value as FileList | null;

      if (!files || files.length === 0) return null;

      return files.length <= maxFiles ? null : { maxFiles: true };
    };
  }

  private integerOnlyValidator() {
    return (c: FormControl) => {
      const raw = (c.value ?? '').toString();
      const v = raw.replace(/\s+/g, '').replace(/_/g, '');

      if (v === '') return null; // vazio é permitido quando não é required

      return /^\d+$/.test(v) ? null : { integerOnly: true };
    };
  }

  // --- Data source para autocomplete ---
  dataManufacturers = (q: string) => {
    const qp = encodeURIComponent(q ?? '');

    return this.http.get<unknown[]>(`/api/manufacturers?q=${qp}`);
  };

  dataModels = (q: string) => {
    const qp = encodeURIComponent(q ?? '');

    return this.http.get<unknown[]>(`/api/models/motorhome?q=${qp}`);
  };

  transmissionOptions = [
    { label: 'Manual', value: 'manual' },
    { label: 'Automática', value: 'automatic' },
  ];

  batteryTypeOptions = [
    { label: 'Lítio', value: 'lithium' },
    { label: 'Ácida', value: 'acid' },
    { label: 'Gel', value: 'gel' },
  ];

  kitchenTypeOptions = [
    { label: 'Interna', value: 'internal' },
    { label: 'Externa', value: 'external' },
    { label: 'Ambas', value: 'both' },
  ];

  showerTypeOptions = [
    { label: 'Interno', value: 'internal' },
    { label: 'Externo', value: 'external' },
    { label: 'Ambos', value: 'both' },
  ];
}
