export const DynamicFormEnValidations = {
  form: {
    errors: {
      required: 'This field is required',
      min: 'Value is below the minimum',
      max: 'Value exceeds the maximum',
      minLength: 'Text is shorter than allowed',
      maxLength: 'Text is longer than allowed',
      pattern: 'Value does not match the expected format',
      integerOnly: 'Only integer numbers are allowed',
      decimalPlaces: 'Too many decimal places',
      notPast: 'Date cannot be in the past',
      notFuture: 'Date cannot be in the future',
      maxDiffDays: 'Difference exceeds allowed days',
      multiSelectLimit: 'You selected more items than allowed',
      maxDiffMonths: 'Difference exceeds allowed months',
      enumMatch: 'Value does not match allowed options',
      invalid: 'Invalid value',
    },
  },
};
