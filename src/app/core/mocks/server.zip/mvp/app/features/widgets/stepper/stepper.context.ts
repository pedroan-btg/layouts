// Context types for Stepper feature. Extend as needed.
export interface StepperResetOptions {
  keepData?: boolean;
  index?: number;
}
