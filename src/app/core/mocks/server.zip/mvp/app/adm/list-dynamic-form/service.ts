import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CurrentUserService {
  getUserId(): string {
    return 'MOCK.USER';
  }
}
