import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  OnInit,
  Signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Observable, map, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';

import { DataTable, Table, TableColumn } from 'fts-frontui/table';
import { ToolbarActionButton } from 'fts-frontui/toolbar';
import { i18n } from 'fts-frontui/i18n';
import { Input } from 'fts-frontui/input';
import { DatePipe, EmptyPipe } from 'fts-frontui/pipes';
import { Toastr } from 'fts-frontui/toastr';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { Api } from './api';
import { Filter } from './filter';
import { AdmDynamicFormFilter } from './filter';
import { DynamicFormApi } from './model';
import { CurrentUserService } from './service';
import { SchemaStorageService } from '../../form-builder/editor/services/schema-storage.service';
import { ProdutoGarantiaModal } from './modal/product-garantia';

@Component({
  selector: '[adm-list-dynamic-form]',
  templateUrl: './list-dynamic-form.html',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    Table,
    TableColumn,
    ToolbarActionButton,
    i18n,
    DatePipe,
    EmptyPipe,
    AdmDynamicFormFilter,
    Toastr,
    NgbTooltip,
    ProdutoGarantiaModal,
  ],
  providers: [Api, Filter, SchemaStorageService, CurrentUserService],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ListDynamicForm implements OnInit {
  private readonly api = inject(Api);
  private readonly filter = inject(Filter);
  private readonly fb = inject(FormBuilder);
  private readonly ref = inject(ChangeDetectorRef);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly http = inject(HttpClient);
  private readonly currentUser = inject(CurrentUserService);
  private readonly storage = inject(SchemaStorageService);

  form!: FormGroup;
  dataSource!: Observable<DataTable<DynamicFormApi>>;
  hasFilter!: Signal<boolean>;
  private cacheRows: DynamicFormApi[] = [];
  private cachePageToken = 1;
  productModalOpen = false;

  ngOnInit(): void {
    this.initializeForm();
    this.setupVariables();
    this.loadData();
    this.promptDraftIfAny();
  }

  onFilter(): void {
    this.filter.onFilter();
  }

  onReset(): void {
    this.filter.clear();
  }

  setPage(currenPageToken: number | string): void {
    this.filter.setPage(currenPageToken as number);
  }

  onEdit(item: DynamicFormApi): void {
    void this.router.navigate(['../editor'], {
      relativeTo: this.route,
      queryParams: { id: item.id },
    });
  }

  onCreateNew(): void {
    void this.router.navigate(['../editor'], { relativeTo: this.route });
  }

  openProdutoGarantiaModal(): void {
    this.productModalOpen = true;
    this.ref.markForCheck();
  }

  closeProdutoGarantiaModal(): void {
    this.productModalOpen = false;
    this.ref.markForCheck();
  }

  onDelete(item: DynamicFormApi): void {
    Swal.fire({
      html: 'Esta ação irá marcar o formulário como descontinuado e ele não poderá ser utilizado.',
      icon: 'warning',
      confirmButtonText: 'Sim, descontinuar',
      cancelButtonText: 'Não, cancelar',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-danger',
      },
      buttonsStyling: false,
      showCancelButton: true,
      allowOutsideClick: false,
      heightAuto: false,
      reverseButtons: true,
    }).then(r => {
      if (r.isConfirmed)
        this.api
          .deprecateSchema(item.type)
          .subscribe(() => this.revalidateRow(item.type, 'deprecated'));
    });
  }

  onAction(item: DynamicFormApi): void {
    if (item.status === 'deprecated') {
      this.api.restoreSchema(item.type).subscribe(() => this.revalidateRow(item.type, 'published'));
    } else {
      this.onDelete(item);
    }
  }

  statusClass(s: DynamicFormApi['status']): string {
    if (s === 'published') return 'badge-light-success';

    if (s === 'deprecated') return 'badge-light-dark';

    return 'badge-light-warning';
  }

  private initializeForm(): void {
    this.form = this.fb.group({
      name: ['', Validators.maxLength(100)],
      jsonKey: ['', Validators.maxLength(100)],
      jsonValue: ['', Validators.maxLength(200)],
      version: ['', [Validators.pattern(/^\d+(\.\d+)*$/), Validators.maxLength(20)]],
      createdAt: [null],
      updatedAt: [null],
      showDeprecated: [false],
    });
  }

  private setupVariables(): void {
    this.hasFilter = this.filter.hasFilter;
    this.filter.setup({ form: this.form, callback: this.loadData.bind(this) });
  }

  private loadData(): void {
    this.dataSource = this.api.getAll(this.filter.value).pipe(
      map(data => {
        const rows = data.rows ?? [];
        const pageZeroBased = this.filter.value.page;
        const end = (pageZeroBased + 1) * this.filter.value.limit;
        const aggregatedRows = rows.slice(0, end);
        const pageToken = pageZeroBased + 1;
        this.cacheRows = aggregatedRows;
        this.cachePageToken = pageToken;

        return { pageToken, rows: aggregatedRows } as DataTable<DynamicFormApi>;
      }),
    );
    this.ref.markForCheck();
  }

  private revalidateRow(type: string, status: DynamicFormApi['status']): void {
    const idx = this.cacheRows.findIndex(r => r.type === type);

    if (idx < 0) return;

    const updated = { ...this.cacheRows[idx], status, updatedAt: new Date() };
    const rows = this.cacheRows.slice();

    if (status === 'deprecated' && !this.filter.value.showDeprecated) {
      rows.splice(idx, 1);
    } else {
      rows[idx] = updated;
    }

    this.cacheRows = rows;
    this.dataSource = of({ pageToken: this.cachePageToken, rows: this.cacheRows });
    this.ref.markForCheck();
  }

  private promptDraftIfAny(): void {
    const userId = this.currentUser.getUserId();
    this.storage.getPendingDrafts(userId).subscribe(list => {
      const blocking = list.find(d => d && d['publishedVersionExists'] === false);

      if (!blocking) return;

      Swal.fire({
        icon: 'warning',
        text: 'Você possui um formulário em rascunho não publicado. Deseja editar ou excluir?',
        confirmButtonText: 'Editar',
        denyButtonText: 'Excluir',
        showDenyButton: true,
        showCancelButton: false,
        buttonsStyling: false,
        customClass: {
          confirmButton: 'btn btn-primary',
          denyButton: 'btn btn-danger',
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
        heightAuto: false,
        reverseButtons: true,
      }).then(result => {
        if (result.isConfirmed) {
          void this.router.navigate(['../editor'], {
            relativeTo: this.route,
            queryParams: { draftId: Number(blocking?.['id'] ?? 0) },
          });
        } else if (result.isDenied) {
          const id = Number(blocking?.['id'] ?? NaN);

          if (Number.isFinite(id)) {
            this.storage.deleteDraft(id).subscribe(() => {
              this.loadData();
            });
          }
        }
      });
    });
  }
}
