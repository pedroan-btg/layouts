import {
  Component,
  EventEmitter,
  Input,
  Output,
  OnInit,
  OnChanges,
  SimpleChanges,
  inject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { of, Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { Input as FtsInput } from 'fts-frontui/input';
import { Select as FtsSelect } from 'fts-frontui/select';
import { DataTable, Table, TableColumn } from 'fts-frontui/table';
import { Router, ActivatedRoute } from '@angular/router';
import { ProdutoGarantiaApi, Option, VinculoProdutoGarantia } from './api';

// types moved to ./api

@Component({
  selector: '[fts-product-garantia-modal]',
  templateUrl: './product-garantia.html',
  imports: [CommonModule, ReactiveFormsModule, FtsInput, FtsSelect, Table, TableColumn],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProdutoGarantiaModal implements OnInit, OnChanges {
  private readonly fb = inject(FormBuilder);
  private readonly ref = inject(ChangeDetectorRef);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly api = inject(ProdutoGarantiaApi);

  @Input() open = false;
  @Output() closed = new EventEmitter<void>();

  form!: FormGroup;
  mercados: Option[] = [];
  tipos: Option[] = [];
  subtipos: Option[] = [];
  ativos: Option[] = [];
  forms: Option[] = [];
  custodiaOptions: Option[] = [
    { label: 'Com custódia BTG', value: 'true' },
    { label: 'Sem custódia BTG', value: 'false' },
    { label: 'não se aplica', value: 'null' },
  ];

  page = 0;
  limit = 12;
  cacheRows: VinculoProdutoGarantia[] = [];
  dataSource!: Observable<DataTable<VinculoProdutoGarantia>>;

  ngOnInit(): void {
    this.form = this.fb.group({
      mercadoId: [null, Validators.required],
      tipoGarantiaId: [{ value: null, disabled: true }, Validators.required],
      subtipoGarantiaId: [{ value: null, disabled: true }, Validators.required],
      ativoId: [{ value: null, disabled: true }, Validators.required],
      custodiaBTG: ['null'],
      formId: [null, Validators.required],
      ordemPrioridade: [1, [Validators.required, Validators.min(1), Validators.pattern(/^\d+$/)]],
    });
    this.form.get('mercadoId')?.valueChanges.subscribe(selectedMarketId => {
      const hasSelectedMarket = !!selectedMarketId;
      const dependentControlKeys = ['tipoGarantiaId', 'subtipoGarantiaId', 'ativoId'];
      dependentControlKeys.forEach(controlKey => {
        const formControl = this.form.get(controlKey);

        if (!formControl) return;

        if (hasSelectedMarket) formControl.enable();
        else formControl.disable();

        formControl.reset(null);
      });
      this.router.navigate([], {
        queryParamsHandling: 'merge',
        queryParams: {
          adm_pg_ctx: hasSelectedMarket ? String(selectedMarketId) : null,
          _pg_token: hasSelectedMarket ? Date.now() : null,
        },
      });

      if (hasSelectedMarket) {
        this.cacheRows = [];
        this.dataSource = of({ pageToken: Date.now(), rows: null });
        this.ref.markForCheck();
        this.reloadOptionsForMarket(String(selectedMarketId));
        this.page = 0;
        this.loadExistingVinculos(String(selectedMarketId));
      } else {
        this.tipos = [];
        this.subtipos = [];
        this.ativos = [];
        this.cacheRows = [];
        this.dataSource = of({ pageToken: Date.now(), rows: null });
        this.ref.markForCheck();
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open) {
      if (this.form) {
        this.form.reset({
          mercadoId: null,
          custodiaBTG: 'null',
          formType: null,
          ordemPrioridade: 1,
        });
        const dependentControlKeys = ['tipoGarantiaId', 'subtipoGarantiaId', 'ativoId'];
        dependentControlKeys.forEach(controlKey => {
          const formControl = this.form.get(controlKey);

          if (formControl) {
            formControl.disable();
            formControl.reset(null);
          }
        });
      }

      this.tipos = [];
      this.subtipos = [];
      this.ativos = [];
      this.page = 0;
      this.cacheRows = [];
      this.dataSource = of({ pageToken: Date.now(), rows: null });

      if (this.mercados.length === 0) this.loadMercados();

      if (this.forms.length === 0) this.loadForms();

      this.ref.markForCheck();
    }
  }

  labelForId(arr: Option[], id: string): string {
    const f = arr.find(x => x.value === id);

    return f ? f.label : id;
  }

  onClose(): void {
    this.closed.emit();
  }

  private loadMercados(): void {
    this.api.getMarkets().subscribe(arr => {
      this.mercados = arr;
      this.ref.markForCheck();
    });
  }

  private loadForms(): void {
    this.api.getFormsList().subscribe(arr => {
      this.forms = arr;
      this.ref.markForCheck();
    });
  }

  private reloadOptionsForMarket(marketId: string): void {
    this.api.getCollateralTypes(marketId).subscribe(arr => {
      this.tipos = arr;
      this.ref.markForCheck();
    });

    this.api.getCollateralSubtypes(marketId).subscribe(arr => {
      this.subtipos = arr;
      this.ref.markForCheck();
    });

    this.api.getAssets(marketId).subscribe(arr => {
      this.ativos = arr;
      this.ref.markForCheck();
    });
  }

  addVinculo(): void {
    if (this.form.invalid) return;

    const custodiaRawValue = String(this.form.get('custodiaBTG')?.value ?? 'null');
    let custodiaValue: boolean | null;

    if (custodiaRawValue === 'true') custodiaValue = true;
    else if (custodiaRawValue === 'false') custodiaValue = false;
    else custodiaValue = null;

    const mercadoId = String(this.form.get('mercadoId')?.value ?? '');
    const tipoGarantiaId = String(this.form.get('tipoGarantiaId')?.value ?? '');
    const subtipoGarantiaId = String(this.form.get('subtipoGarantiaId')?.value ?? '');
    const ativoId = String(this.form.get('ativoId')?.value ?? '');
    const formIdRaw = String(this.form.get('formId')?.value ?? '');
    const formId = Number(formIdRaw || '0');
    const formType = this.labelForId(this.forms, formIdRaw);
    const ordemPrioridade = Number(this.form.get('ordemPrioridade')?.value ?? 1);
    let custodiaToken: string;

    if (custodiaValue === true) custodiaToken = '1';
    else if (custodiaValue === false) custodiaToken = '0';
    else custodiaToken = '2';

    const id = [mercadoId, tipoGarantiaId, subtipoGarantiaId, ativoId, custodiaToken].join('|');
    const v: VinculoProdutoGarantia = {
      id,
      mercadoId,
      tipoGarantiaId,
      subtipoGarantiaId,
      ativoId,
      custodiaBTG: custodiaValue,
      formType,
      formId,
      ordemPrioridade,
    };

    const duplicateAssociation = this.cacheRows.find(
      x =>
        x.mercadoId === v.mercadoId &&
        x.tipoGarantiaId === v.tipoGarantiaId &&
        x.subtipoGarantiaId === v.subtipoGarantiaId &&
        x.ativoId === v.ativoId &&
        x.custodiaBTG === v.custodiaBTG,
    );

    if (duplicateAssociation) {
      Swal.fire({ icon: 'error', text: 'Já existe vínculo com a mesma combinação.' });

      return;
    }

    this.api.createFinancialAsset(v).subscribe(() => {
      const keepMarket = this.form.get('mercadoId')?.value;
      this.form.reset({ mercadoId: keepMarket, custodiaBTG: 'null', ordemPrioridade: 1 });
      const clear = ['tipoGarantiaId', 'subtipoGarantiaId', 'ativoId', 'formId'];
      clear.forEach(k => this.form.get(k)?.setValue(null));
      this.reloadOptionsForMarket(String(keepMarket ?? ''));
      this.loadExistingVinculos(String(keepMarket ?? ''));
      this.ref.markForCheck();
    });
  }

  removeVinculo(row: VinculoProdutoGarantia): void {
    Swal.fire({
      icon: 'question',
      text: 'Tem certeza?',
      showCancelButton: true,
      confirmButtonText: 'Remover',
      cancelButtonText: 'Cancelar',
      buttonsStyling: false,
      customClass: { confirmButton: 'btn btn-danger', cancelButton: 'btn btn-secondary' },
    }).then(res => {
      if (!res.isConfirmed) return;

      this.api
        .deleteFinancialAsset({
          mercadoId: row.mercadoId,
          tipoGarantiaId: row.tipoGarantiaId,
          subtipoGarantiaId: row.subtipoGarantiaId,
          ativoId: row.ativoId,
          custodiaBTG: String(row.custodiaBTG),
        })
        .subscribe(() => {
          const currentMarketId = String(this.form.get('mercadoId')?.value ?? '');
          this.loadExistingVinculos(currentMarketId || undefined);
          this.ref.markForCheck();
        });
    });
  }

  private loadExistingVinculos(marketId?: string): void {
    this.api.getFinancialAssets(this.page, this.limit, marketId).subscribe(({ rows }) => {
      this.cacheRows = rows ?? [];
      const pageToken = `${this.page + 1}-${String(marketId ?? '')}-${Date.now()}`;
      this.dataSource = of({ pageToken, rows: this.cacheRows.length ? this.cacheRows : null });
      this.ref.markForCheck();
    });
  }

  changePage(pageToken: number | string): void {
    const n = typeof pageToken === 'string' ? Number(pageToken) : pageToken;
    this.page = Math.max(0, (n ?? 1) - 1);
    const m = String(this.form.get('mercadoId')?.value ?? '');
    this.loadExistingVinculos(m || undefined);
  }
}
