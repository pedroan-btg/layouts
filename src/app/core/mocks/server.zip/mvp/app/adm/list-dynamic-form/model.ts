import { ItemsPerPageType } from 'fts-frontui/table';

export type FormStatus = 'draft' | 'published' | 'deprecated';

export interface DynamicFormApi {
  id: number;
  type: string;
  name: string;
  version: string;
  status: FormStatus;
  fieldsCount: number;
  createdAt: Date | null;
  updatedAt: Date | null;
}

export interface ApiResponse {
  data?: {
    rows: DynamicFormApi[];
    skip: number;
    total?: number;
  };
  errors?: string[];
  statusCode: number;
}

export const toDynamicForm = (response: ApiResponse): DynamicFormApi[] => {
  const parseDate = (d: unknown): Date | null => {
    if (!d) return null;

    if (d instanceof Date) return isNaN(d.getTime()) ? null : d;

    const dt = new Date(String(d));

    return isNaN(dt.getTime()) ? null : dt;
  };

  return (response.data?.rows ?? []).map((s: DynamicFormApi) => ({
    id: Number((s as any).id ?? 0),
    type: s.type,
    name: s.name,
    version: s.version,
    status: s.status,
    fieldsCount: s.fieldsCount,
    createdAt: parseDate(s.createdAt as unknown),
    updatedAt: parseDate(s.updatedAt as unknown),
  }));
};

export interface FilterModel {
  name: string | null;
  jsonKey: string | null;
  jsonValue: string | null;
  version: string | null;
  createdAt: Date[] | null;
  updatedAt: Date[] | null;
  showDeprecated: boolean;
  page: number;
  limit: ItemsPerPageType;
  skip: number;
}
