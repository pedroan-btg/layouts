import { Component, EventEmitter, Input, Output, Signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Input as FtsInput } from 'fts-frontui/input';
import { ToolbarActionButton } from 'fts-frontui/toolbar';

@Component({
  selector: '[col-adm-dynamic-form-filter]',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FtsInput, ToolbarActionButton],
  templateUrl: './filter.html',
})
export class AdmDynamicFormFilter {
  @Input({ required: true }) form!: FormGroup;
  @Input({ required: true }) hasFilter!: Signal<boolean>;
  @Output() apply = new EventEmitter<void>();
  @Output() reset = new EventEmitter<void>();
}
