import { ItemsPerPageType } from 'fts-frontui/table';

export interface FilterModel {
  name: string | null;
  jsonKey: string | null;
  jsonValue: string | null;
  version: string | null;
  createdAt: Date[] | null;
  updatedAt: Date[] | null;
  showDeprecated: boolean;
  page: number;
  limit: ItemsPerPageType;
  skip: number;
}
