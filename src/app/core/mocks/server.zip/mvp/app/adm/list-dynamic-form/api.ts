import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ApiResponse, DynamicFormApi, toDynamicForm, FilterModel } from './model';
import { FormSchemaModel } from '../../form-builder/models/form-schema.model';

@Injectable()
export class Api {
  private readonly httpClient = inject(HttpClient);

  getAll(filter: FilterModel): Observable<{ rows: DynamicFormApi[] | undefined; total: number }> {
    let params = new HttpParams();

    Object.entries(filter).forEach(([key, value]) => {
      if (value === null || value === undefined) return;

      if (key === 'skip') return;

      if (Array.isArray(value)) {
        value.forEach(v => {
          params = params.append(key, v.toString());
        });
      } else {
        params = params.set(key, value.toString());
      }
    });

    return this.httpClient.get<ApiResponse>(`/api/dynamic-forms/schemas`, { params }).pipe(
      map(response => {
        const rows = toDynamicForm(response);
        const totalFromServer = response.data?.total;
        const total = Number.isFinite(totalFromServer as number)
          ? (totalFromServer as number)
          : (rows?.length ?? 0);

        return { rows, total };
      }),
    );
  }

  getSchemaByType(type: string): Observable<FormSchemaModel> {
    return this.httpClient.get<FormSchemaModel>(`/api/dynamic-form/${type}`);
  }

  deleteSchema(type: string): Observable<void> {
    return this.httpClient.delete<void>(`/api/dynamic-forms/${type}`);
  }

  deprecateSchema(type: string): Observable<void> {
    return this.httpClient.patch<void>(`/api/dynamic-forms/${type}/deprecate`, {});
  }

  restoreSchema(type: string): Observable<void> {
    return this.httpClient.patch<void>(`/api/dynamic-forms/${type}/restore`, {});
  }

  createNew(): Observable<{ id: number }> {
    return this.httpClient
      .post<{ statusCode: number; data?: { row: DynamicFormApi } }>(`/api/dynamic-forms`, {})
      .pipe(map(res => ({ id: Number(res.data?.row.id ?? 0) })));
  }
}
