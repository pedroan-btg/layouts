export const PATH_COLLATERAL_MARKETS = '/api/collateralmarkets';
export const PATH_DYNAMIC_FORMS_SCHEMAS = '/api/dynamic-forms/schemas';
export const PATH_COLLATERAL_TYPES = '/api/collateraltypes';
export const PATH_COLLATERAL_SUBTYPES = '/api/collateralsubtypes';
export const PATH_COLLATERAL_ASSETS = '/api/collateralassets';
export const PATH_FINANCIAL_ASSET = '/api/financialasset';
