import { DestroyRef, inject, Injectable, signal } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject } from 'rxjs';
import { FilterModel } from './model';

@Injectable()
export class Filter {
  private readonly destroyRef = inject(DestroyRef);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  private form!: FormGroup;
  private lastFilteredQueryParams?: string;

  private readonly hasActiveFilterSignal = signal<boolean>(false);
  private readonly filterEvents = new Subject<boolean>();
  readonly hasFilter = this.hasActiveFilterSignal.asReadonly();
  readonly filterChanges = this.filterEvents.asObservable();

  value: FilterModel = { page: 0, skip: 0, limit: 12, showDeprecated: false } as FilterModel;

  setup({ form, callback }: { form: FormGroup; callback: () => void }): void {
    this.form = form;

    this.filterChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => callback());

    this.route.queryParamMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => this.onParamFilter(params));
  }

  onFilter(): void {
    const formValues = this.form.value;
    this.value = { ...this.value, ...formValues } as FilterModel;

    const hasActiveFilters = Object.values(formValues).some(value => {
      if (value == null) return false;

      if (Array.isArray(value)) return value.some(Boolean);

      return typeof value === 'string' ? value.trim() !== '' : true;
    });
    this.hasActiveFilterSignal.set(hasActiveFilters);

    const serializeDateListToParamString = (arr: Date[] | null | undefined): string | null =>
      arr && arr.length > 0 ? arr.map(d => d.toISOString()).join(',') : null;

    const normalizeStringParam = (v: string | null | undefined): string | null => {
      const s = (v ?? '').trim();

      return s.length > 0 ? s : null;
    };

    const queryParams: Record<string, unknown> = {
      name: normalizeStringParam(this.value.name),
      jsonkey: normalizeStringParam(this.value.jsonKey),
      jsonvalue: normalizeStringParam(this.value.jsonValue),
      version: normalizeStringParam(this.value.version),
      createdat: serializeDateListToParamString(this.value.createdAt),
      updatedat: serializeDateListToParamString(this.value.updatedAt),
      showdeprecated: this.value.showDeprecated ? '1' : null,
    };

    this.router.navigate([], { relativeTo: this.route, queryParams });
    this.emitChange();
  }

  clear(): void {
    this.value.name = null;
    this.value.jsonKey = null;
    this.value.jsonValue = null;
    this.value.version = null;
    this.value.createdAt = null;
    this.value.updatedAt = null;
    this.value.page = 0;
    this.value.skip = 0;
    this.hasActiveFilterSignal.set(false);

    if (this.form) this.form.reset({}, { emitEvent: false });

    this.router.navigate([], { relativeTo: this.route, queryParams: {} });
    this.emitChange();
  }

  setPage(currentPageToken: number): void {
    const isValid = Number.isFinite(currentPageToken) && currentPageToken > 0;
    const page = isValid ? currentPageToken : 0;
    this.value.page = page;
    this.value.skip = page * this.value.limit;
    this.emitChange();
  }

  private getQueryParamIgnoreCase(params: ParamMap, key: string): string | null {
    const keys = (params as unknown as { keys?: string[] }).keys ?? [];
    const found = keys.find(k => k.toLowerCase() === key.toLowerCase());

    return params.get(found ?? key);
  }

  private parseDateListFromParamString(param: string | null): Date[] | null {
    if (!param) return null;

    const parts = param
      .split(',')
      .map(p => p.trim())
      .filter(Boolean);
    const dates = parts.map(p => new Date(p)).filter(d => !isNaN(d.getTime()));

    return dates.length > 0 ? dates : null;
  }

  private filterQueryParamsForComparison(params: ParamMap): string {
    const ignore = ['page', 'pagination', 'pg', 'pagina'];
    const filtered: Record<string, unknown> = {};
    const keys = (params as unknown as { keys?: string[] }).keys ?? [];
    keys.forEach(key => {
      if (!ignore.includes(key)) {
        const getAll = (params as unknown as { getAll?: (k: string) => string[] }).getAll;

        if (typeof getAll === 'function') {
          const all = getAll.call(params, key) ?? [];
          filtered[key] = all.length > 1 ? all : params.get(key);
        } else {
          filtered[key] = params.get(key);
        }
      }
    });

    return JSON.stringify(filtered);
  }

  private onParamFilter(params: ParamMap): void {
    this.hasActiveFilterSignal.set(false);

    const controlNames = Object.keys(this.form.controls ?? {});

    for (const controlName of controlNames) {
      const control = this.form.get(controlName);
      const paramValue = this.getQueryParamIgnoreCase(params, controlName);

      if (control && paramValue !== null) {
        if (controlName === 'createdAt' || controlName === 'updatedAt') {
          const dates = this.parseDateListFromParamString(paramValue);
          control.setValue(dates, { emitEvent: false });
          const isActive = !!dates && dates.length > 0;

          if (isActive) this.hasActiveFilterSignal.set(true);
        } else if (controlName === 'showDeprecated') {
          const v = paramValue.toLowerCase();
          const bool = v === '1' || v === 'true';
          control.setValue(bool, { emitEvent: false });

          if (bool) this.hasActiveFilterSignal.set(true);
        } else {
          const trimmed = paramValue.trim();

          if (trimmed === '') {
            control.setValue(null, { emitEvent: false });
          } else {
            control.setValue(paramValue, { emitEvent: false });
            this.hasActiveFilterSignal.set(true);
          }
        }
      }
    }

    this.value = {
      ...this.value,
      ...this.form.value,
      page: this.value.page,
      skip: this.value.skip,
      limit: this.value.limit,
    } as FilterModel;

    const filtered = this.filterQueryParamsForComparison(params);

    if (filtered !== this.lastFilteredQueryParams) {
      this.value.page = 0;
      this.value.skip = 0;
      this.lastFilteredQueryParams = filtered;
    }

    this.emitChange();
  }

  private emitChange(): void {
    this.filterEvents.next(true);
  }
}
