import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import {
  PATH_COLLATERAL_MARKETS,
  PATH_DYNAMIC_FORMS_SCHEMAS,
  PATH_COLLATERAL_TYPES,
  PATH_COLLATERAL_SUBTYPES,
  PATH_COLLATERAL_ASSETS,
  PATH_FINANCIAL_ASSET,
} from './constants';

export interface Option {
  label: string;
  value: string;
}

export interface VinculoProdutoGarantia {
  id: string;
  mercadoId: string;
  tipoGarantiaId: string;
  subtipoGarantiaId: string;
  ativoId: string;
  custodiaBTG: boolean | null;
  formType: string;
  formId: number;
  ordemPrioridade: number;
}

@Injectable({ providedIn: 'root' })
export class ProdutoGarantiaApi {
  private readonly http = inject(HttpClient);

  getMarkets(): Observable<Option[]> {
    return this.http
      .get<{ data: { rows: { id: string; name: string }[] } }>(PATH_COLLATERAL_MARKETS)
      .pipe(
        map(response =>
          response.data.rows.map(row => ({ label: row.name, value: row.id }) as Option),
        ),
      );
  }

  getFormsList(): Observable<Option[]> {
    return this.http
      .get<{ data: { rows: { id: number; type: string; name?: string; version?: string }[] } }>(
        PATH_DYNAMIC_FORMS_SCHEMAS,
      )
      .pipe(
        map(response =>
          response.data.rows.map(row => ({
            label: row.type,
            value: String(row.id),
          })),
        ),
      );
  }

  getCollateralTypes(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        data: { rows: { id: string; name: string }[] };
      }>(`${PATH_COLLATERAL_TYPES}?marketId=${encodeURIComponent(marketId)}`)
      .pipe(
        map(response =>
          response.data.rows.map(row => ({ label: row.name, value: row.id }) as Option),
        ),
      );
  }

  getCollateralSubtypes(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        data: { rows: { id: string; name: string }[] };
      }>(`${PATH_COLLATERAL_SUBTYPES}?marketId=${encodeURIComponent(marketId)}`)
      .pipe(
        map(response =>
          response.data.rows.map(row => ({ label: row.name, value: row.id }) as Option),
        ),
      );
  }

  getAssets(marketId: string): Observable<Option[]> {
    return this.http
      .get<{
        data: { rows: { id: string; name: string }[] };
      }>(`${PATH_COLLATERAL_ASSETS}?marketId=${encodeURIComponent(marketId)}`)
      .pipe(
        map(response =>
          response.data.rows.map(row => ({ label: row.name, value: row.id }) as Option),
        ),
      );
  }

  getFinancialAssets(
    page: number,
    limit: number,
    marketId?: string,
  ): Observable<{ rows: VinculoProdutoGarantia[]; total?: number }> {
    const search = new URLSearchParams({ page: String(page), limit: String(limit) });

    if (marketId) search.append('marketId', marketId);

    const url = `${PATH_FINANCIAL_ASSET}?${search.toString()}`;

    return this.http
      .get<{ data: { rows: VinculoProdutoGarantia[]; total?: number } }>(url)
      .pipe(map(response => response.data));
  }

  createFinancialAsset(link: VinculoProdutoGarantia): Observable<void> {
    return this.http.post<void>(PATH_FINANCIAL_ASSET, link);
  }

  deleteFinancialAsset(params: {
    mercadoId: string;
    tipoGarantiaId: string;
    subtipoGarantiaId: string;
    ativoId: string;
    custodiaBTG: string;
  }): Observable<void> {
    const queryString = new URLSearchParams(params).toString();

    return this.http.delete<void>(`${PATH_FINANCIAL_ASSET}?${queryString}`);
  }
}
