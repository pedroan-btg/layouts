import { Component, HostBinding } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: '[fts-root]',
  imports: [RouterOutlet],
  templateUrl: './app.html',
})
export class App {
  @HostBinding('class') hostClass = 'd-flex flex-column flex-root';
}
