import { Component, EventEmitter, Input, Output, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormArray, FormGroup, FormBuilder } from '@angular/forms';
import { Input as FtsInput } from 'fts-frontui/input';
import { Select as FtsSelect } from 'fts-frontui/select';
import { Selection as FtsSelection } from 'fts-frontui/selection';
import { NgbAccordionModule, NgbAccordionDirective } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: '[fts-field-advanced-modal]',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FtsInput,
    FtsSelect,
    FtsSelection,
    NgbAccordionModule,
  ],
  templateUrl: './field-advanced-modal.html',
})
export class FieldAdvancedModal implements AfterViewInit {
  @Input() open = false;
  @Input() titleName = '';
  @Input() fieldForm!: FormGroup;
  @Input() validationsFormArray!: FormArray;
  @Input() dependenciesForm!: FormGroup;
  @Input() behaviorOptions: { label: string; value: string }[] = [];
  @Input() autoFillForm!: FormGroup;
  @Input() size: 'default' | 'lg' | 'xl' = 'xl';
  @Input() dialogWidth: number | null = null;
  @Input() validationNameOptions: { label: string; value: string }[] = [];
  @Output() save = new EventEmitter<void>();
  @Output() closed = new EventEmitter<void>();
  private readonly fb = new FormBuilder();
  @ViewChild(NgbAccordionDirective) acc?: NgbAccordionDirective;

  onClose(): void {
    this.closed.emit();
  }

  onSave(): void {
    this.save.emit();
  }

  addValidationRow(): void {
    const arr = this.fieldForm.get('validations') as FormArray;

    if (!arr) return;

    arr.push(this.fb.group({ name: [''], value: [''], message: [''] }));
  }

  removeValidationRow(index: number): void {
    const arr = this.fieldForm.get('validations') as FormArray;

    if (!arr) return;

    if (index < 0 || index >= arr.length) return;

    arr.removeAt(index);
  }

  addMappingRow(): void {
    const arr = this.autoFillForm.get('mappings') as FormArray;

    if (!arr) return;

    arr.push(this.fb.group({ fieldName: [''], sourcePath: [''] }));
  }

  removeMappingRow(index: number): void {
    const arr = this.autoFillForm.get('mappings') as FormArray;

    if (!arr) return;

    if (index < 0 || index >= arr.length) return;

    arr.removeAt(index);
  }

  get mappingsFormArray(): FormArray {
    return this.autoFillForm.get('mappings') as FormArray;
  }

  get visibleRoot(): FormGroup {
    return this.dependenciesForm.get('visibleRoot') as FormGroup;
  }

  get enableRoot(): FormGroup {
    return this.dependenciesForm.get('enableRoot') as FormGroup;
  }

  get visibleItems(): FormArray {
    return this.visibleRoot.get('items') as FormArray;
  }

  get enableItems(): FormArray {
    return this.enableRoot.get('items') as FormArray;
  }

  groupCombinatorOptions: { label: string; value: string }[] = [
    { label: 'AND', value: 'all' },
    { label: 'OR', value: 'any' },
  ];

  dependencyOperatorOptions: { label: string; value: string }[] = [
    { label: 'equals', value: 'equals' },
    { label: 'value', value: 'equals' },
    { label: 'regex', value: 'regex' },
    { label: 'notEquals', value: 'notEquals' },
    { label: 'true', value: 'true' },
    { label: 'false', value: 'false' },
    { label: 'notEmpty', value: 'notEmpty' },
    { label: 'valid', value: 'valid' },
  ];

  addRuleTo(items: FormArray): void {
    items.push(this.fb.group({ kind: ['rule'], field: [''], operator: ['equals'], operand: [''] }));
  }

  addGroupTo(items: FormArray): void {
    items.push(
      this.fb.group({
        kind: ['group'],
        combinator: ['all'],
        not: [false],
        items: this.fb.array([]),
      }),
    );
  }

  addOperatorTo(items: FormArray): void {
    this.addGroupTo(items);
  }

  removeItem(items: FormArray, index: number): void {
    if (index < 0 || index >= items.length) return;

    items.removeAt(index);
  }

  childItems(group: unknown): FormArray {
    return (group as FormGroup).get('items') as FormArray;
  }

  isGroup(item: unknown): boolean {
    return String((item as FormGroup).get('kind')?.value ?? '') === 'group';
  }

  showOperand(op: string | null | undefined): boolean {
    const v = String(op ?? '').trim();

    return ['regex', 'equals', 'notEquals'].includes(v);
  }

  ngAfterViewInit(): void {
    try {
      this.acc?.expand('validations');
    } catch {
      return;
    }
  }
}
