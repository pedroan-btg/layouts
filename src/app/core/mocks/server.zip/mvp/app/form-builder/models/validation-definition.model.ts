export interface ValidationDefinitionModel {
  name: string;
  value?: unknown;
  message?: string;
}
