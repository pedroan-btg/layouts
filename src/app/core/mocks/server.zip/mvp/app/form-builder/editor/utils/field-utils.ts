import { FieldDefinitionModel } from '../../models/field-definition.model';
import { ValidationDefinitionModel } from '../../models/validation-definition.model';

export function defaultFieldByType(
  type: FieldDefinitionModel['type'],
  name: string,
  order: number,
  tabIndex: number,
): FieldDefinitionModel {
  const labelKey = `FIELDS.${name.replace(/([A-Z])/g, '_$1').toUpperCase()}`;

  switch (type) {
    case 'string':
      return { name, labelKey, type, widget: 'text', order, tabIndex };
    case 'number':
      return { name, labelKey, type, widget: 'number', order, tabIndex };
    case 'boolean':
      return { name, labelKey, type, widget: 'checkbox', order, tabIndex };
    case 'enum':
      return { name, labelKey, type, widget: 'select', order, tabIndex, values: [] };
    case 'date':
      return { name, labelKey, type, widget: 'datepicker', order, tabIndex };
    case 'file':
      return { name, labelKey, type, widget: 'fileupload', order, tabIndex };
    default:
      return { name, labelKey, type: 'string', widget: 'text', order, tabIndex };
  }
}

export function suggestWidgetByType(
  type: FieldDefinitionModel['type'],
): FieldDefinitionModel['widget'] {
  switch (type) {
    case 'string':
      return 'text';
    case 'number':
      return 'number';
    case 'boolean':
      return 'checkbox';
    case 'enum':
      return 'select';
    case 'date':
      return 'datepicker';
    case 'file':
      return 'fileupload';
    default:
      return 'text';
  }
}

export function defaultValidationsForType(
  type: FieldDefinitionModel['type'],
): ValidationDefinitionModel[] {
  if (type === 'number') return [];

  if (type === 'date') return [];

  if (type === 'enum') return [{ name: 'required' }];

  if (type === 'file') return [];

  return [];
}
