import { Injectable } from '@angular/core';
import { FormSchemaModel } from '../models/form-schema.model';
import { FieldDefinitionModel } from '../models/field-definition.model';
// removed unused import

@Injectable({ providedIn: 'root' })
export class SchemaPersistenceService {
  exportJson(schema: FormSchemaModel): string {
    const ordered: Record<string, unknown> = {
      type: schema.type,
      version: schema.version,
      description: schema.description,
      fields: schema.fields.map(f => this.orderField(f)),
    };
    const json = JSON.stringify(ordered, null, 2);

    return json.endsWith('\n') ? json : json + '\n';
  }

  triggerDownloadJson(schema: FormSchemaModel, fileName = 'form-schema.json'): void {
    const content = this.exportJson(schema);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  private orderField(field: FieldDefinitionModel): Record<string, unknown> {
    const orderedField: Record<string, unknown> = {};
    orderedField['name'] = field.name;
    orderedField['labelKey'] = field.labelKey;
    orderedField['type'] = field.type;
    orderedField['widget'] = field.widget;
    orderedField['order'] = field.order;
    orderedField['tabIndex'] = field.tabIndex;

    if (field.required !== undefined) orderedField['required'] = field.required;

    if (field.disabled !== undefined) orderedField['disabled'] = field.disabled;

    if (field.invisible !== undefined) orderedField['invisible'] = field.invisible;

    if (field.values && field.values.length) orderedField['values'] = field.values;

    if (field.validations && field.validations.length)
      orderedField['validations'] = field.validations.map(v => ({
        name: v.name,
        value: v.value,
        message: v.message,
      }));

    if (field.ui) orderedField['ui'] = field.ui;

    if (field.dependencies) orderedField['dependencies'] = field.dependencies;

    if (field.autoFill) orderedField['autoFill'] = field.autoFill;

    return orderedField;
  }

  async importFromFile(file: File): Promise<FormSchemaModel> {
    const text = await file.text();
    const obj = JSON.parse(text) as FormSchemaModel;

    const fields = (obj.fields ?? []).map(f => {
      const cleaned = (f.validations ?? []).filter(v => {
        if (f.type === 'enum' && v.name === 'pattern') return false;

        if (
          f.type === 'file' &&
          !['fileTypes', 'maxSizeMB', 'maxFiles', 'required'].includes(v.name)
        )
          return false;

        return true;
      });

      return { ...f, validations: cleaned };
    });

    return { ...obj, fields };
  }
}
