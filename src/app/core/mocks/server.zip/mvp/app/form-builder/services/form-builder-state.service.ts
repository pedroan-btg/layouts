import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FormSchemaModel } from '../models/form-schema.model';
import { FieldDefinitionModel } from '../models/field-definition.model';

@Injectable({ providedIn: 'root' })
export class FormBuilderStateService {
  private readonly schemaSubject = new BehaviorSubject<FormSchemaModel | null>(null);
  readonly schema$ = this.schemaSubject.asObservable();

  setSchema(next: FormSchemaModel): void {
    this.schemaSubject.next(next);
  }

  currentSchema(): FormSchemaModel | null {
    return this.schemaSubject.getValue();
  }

  addField(newField: FieldDefinitionModel): void {
    const current = this.currentSchema();

    if (!current) return;

    const updatedFields = [...current.fields, newField];
    this.schemaSubject.next({ ...current, fields: updatedFields });
  }

  updateField(name: string, updated: Partial<FieldDefinitionModel>): void {
    const current = this.currentSchema();

    if (!current) return;

    const updatedFields = current.fields.map(field =>
      field.name === name ? { ...field, ...updated } : field,
    );
    this.schemaSubject.next({ ...current, fields: updatedFields });
  }

  removeField(name: string): void {
    const current = this.currentSchema();

    if (!current) return;

    const updatedFields = current.fields.filter(field => field.name !== name);
    this.schemaSubject.next({ ...current, fields: updatedFields });
  }

  reorderFields(orderByName: string[]): void {
    const current = this.currentSchema();

    if (!current) return;

    const orderMap = new Map<string, number>();
    orderByName.forEach((name, index) => orderMap.set(name, index + 1));
    const updatedFields = current.fields.map(field => ({
      ...field,
      order: orderMap.get(field.name) ?? field.order,
    }));
    this.schemaSubject.next({ ...current, fields: updatedFields });
  }

  renameField(oldName: string, newName: string): void {
    const current = this.currentSchema();

    if (!current) return;

    if (!newName || oldName === newName) return;

    const exists = current.fields.some(f => f.name === newName);

    if (exists) return;

    const renameInCondition = (cond: any): any => {
      if (!cond) return cond;

      if (cond.not) return { not: renameInCondition(cond.not) };

      if (Array.isArray(cond.all)) return { all: cond.all.map(renameInCondition) };

      if (Array.isArray(cond.any)) return { any: cond.any.map(renameInCondition) };

      if (cond.field === oldName) return { ...cond, field: newName };

      return cond;
    };

    const updatedFields = current.fields.map(field => {
      const renamedSelf = field.name === oldName ? { ...field, name: newName } : field;

      const deps = renamedSelf.dependencies;
      const auto = renamedSelf.autoFill;

      const updatedDeps = deps
        ? {
            visibleIf: renameInCondition(deps.visibleIf as any),
            enableIf: renameInCondition(deps.enableIf as any),
          }
        : undefined;

      let updatedAuto = auto;

      if (auto) {
        const triggerField = auto.triggerField === oldName ? newName : auto.triggerField;
        const newMap: Record<string, string> = {};
        Object.keys(auto.map ?? {}).forEach(k => {
          const dest = k === oldName ? newName : k;
          newMap[dest] = auto.map[k];
        });
        updatedAuto = { ...auto, triggerField, map: newMap };
      }

      return { ...renamedSelf, dependencies: updatedDeps, autoFill: updatedAuto };
    });

    this.schemaSubject.next({ ...current, fields: updatedFields });
  }
}
