import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { FormSchemaModel } from '../../models/form-schema.model';
import { CurrentUserService } from '../../services/current-user.service';

@Injectable({ providedIn: 'root' })
export class SchemaStorageService {
  private lastDraft: FormSchemaModel | null = null;
  private readonly http = inject(HttpClient);
  private readonly currentUser = inject(CurrentUserService);

  saveDraft(schema: FormSchemaModel): void {
    this.lastDraft = this.sanitize(schema);
  }

  loadDraft(): FormSchemaModel | null {
    return this.lastDraft ? this.sanitize(this.lastDraft) : null;
  }

  clearDraft(): void {
    this.lastDraft = null;
  }

  persistDraft(
    schema: FormSchemaModel,
    editFormId: number | null,
    currentDraftId?: number,
  ): Observable<number> {
    const userId = this.currentUser.getUserId();
    const isEdit = Number.isFinite(editFormId as number);
    const payload: Record<string, unknown> = {
      id: currentDraftId ?? undefined,
      userId,
      formId: isEdit ? editFormId : null,
      type: schema.type || 'custom-draft',
      publishedVersionExists: isEdit,
      name: schema.description || 'Novo Formulário',
      changes: schema,
    };

    return this.http
      .post<{ statusCode: number; data?: { draft: { id: number } } }>(`/api/drafts`, payload)
      .pipe(map(res => Number(res.data?.draft.id ?? NaN)));
  }

  getPendingDrafts(userId: string): Observable<Record<string, unknown>[]> {
    return this.http
      .get<{ statusCode: number; data?: { drafts: Record<string, unknown>[] } }>(
        `/api/drafts/pending`,
        {
          params: { userId },
          observe: 'body',
        },
      )
      .pipe(
        map(resp => {
          const list = (resp.data?.drafts ?? []) as Record<string, unknown>[];

          return list;
        }),
      );
  }

  deleteDraft(id: number): Observable<void> {
    return this.http.delete<void>(`/api/drafts/${id}`);
  }

  private sanitize(schema: FormSchemaModel): FormSchemaModel {
    const fields = (schema.fields ?? []).map(f => {
      const cleanedValidations = (f.validations ?? []).filter(v => {
        if (f.type === 'enum' && v.name === 'pattern') return false;

        if (
          f.type === 'file' &&
          !['fileTypes', 'maxSizeMB', 'maxFiles', 'required'].includes(v.name)
        )
          return false;

        return true;
      });

      return { ...f, validations: cleanedValidations };
    });

    return { ...schema, fields };
  }
}
