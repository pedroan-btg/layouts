import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  ViewChildren,
  ElementRef,
  QueryList,
  ViewChild,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Input as FtsInput } from 'fts-frontui/input';
import { Select as FtsSelect } from 'fts-frontui/select';
import { Selection as FtsSelection } from 'fts-frontui/selection';
import { BehaviorSubject, Observable, map, tap, of } from 'rxjs';
import { FormBuilderStateService } from '../services/form-builder-state.service';
import { FormSchemaModel } from '../models/form-schema.model';
import { FieldDefinitionModel, ConditionModel } from '../models/field-definition.model';
import { ValidationDefinitionModel } from '../models/validation-definition.model';
import { SchemaStorageService } from './services/schema-storage.service';
import { SchemaValidatorService } from './services/schema-validator.service';
import { SchemaPersistenceService } from '../services/schema-persistence.service';
import { SchemaHelpersService } from './services/schema-helpers.service';
import { CurrentUserService } from '../services/current-user.service';
import { FieldAdvancedModal } from './modal/field-advanced-modal';
import { FieldTemplatesModal } from './modal/field-templates-modal';
import Swal from 'sweetalert2';
import { DynamicFormComponent } from '../../dynamic-form/dynamic-form.component';
import { formHasChanged } from 'fts-frontui/form';
import { DataTable, Table, TableColumn, ItemsPerPageType } from 'fts-frontui/table';
import { Toastr, ToastrService } from 'fts-frontui/toastr';
import { ToolbarActionButton } from 'fts-frontui/toolbar';
import { Router, ActivatedRoute } from '@angular/router';
type TableRowModel = FieldDefinitionModel & { id: string };

@Component({
  selector: 'form-schema-editor',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FtsInput,
    FtsSelect,
    FtsSelection,
    FieldAdvancedModal,
    FieldTemplatesModal,
    DynamicFormComponent,
    Table,
    TableColumn,
    ToolbarActionButton,
    Toastr,
  ],
  providers: [SchemaStorageService, CurrentUserService],
  templateUrl: './form-schema-editor.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormSchemaEditor {
  reorderMode = false;
  reorderList: string[] = [];
  originalOrderNames: string[] = [];
  previewSchemaBeforeReorder: FormSchemaModel | null = null;
  reorderForm!: FormGroup;
  reorderInitialValues: { names: string[] } = { names: [] };
  private dragFromIndex: number | null = null;
  private tableDragFromIndex: number | null = null;
  tableReorderActive = false;
  tableDragPressedIndex: number | null = null;
  tableDragPressedName: string | null = null;
  @ViewChildren('row') rows!: QueryList<ElementRef<HTMLElement>>;
  @ViewChild('tableWrapper') tableWrapper?: ElementRef<HTMLElement>;
  constructor() {
    const idParam = Number(this.route.snapshot.queryParamMap.get('id') ?? NaN);
    const draftIdParam = Number(this.route.snapshot.queryParamMap.get('draftId') ?? NaN);

    if (Number.isFinite(idParam)) {
      this.editFormId = idParam;
      const userId = this.currentUser.getUserId();
      this.storage.getPendingDrafts(userId).subscribe(list => {
        const existing = list.find(
          d => Number(d?.['formId']) === idParam && Boolean(d?.['publishedVersionExists']),
        ) as Record<string, unknown> | undefined;

        if (existing && existing['changes']) {
          const schema = existing['changes'] as FormSchemaModel;
          this.currentDraftId = Number((existing['id'] as number | undefined) ?? NaN);
          this.state.setSchema(schema);
          const sorted = [...(schema.fields ?? [])].sort((a, b) => (a.order || 0) - (b.order || 0));
          this.fieldsList$.next(sorted);
          this.schemaForm.patchValue({
            type: schema.type,
            version: schema.version,
            description: schema.description,
          });
          this.storage.saveDraft(schema);
          this.buildDataSource();
          this.ref.markForCheck();
        } else {
          this.http
            .get<FormSchemaModel>(`/api/editor/form-schema?id=${idParam}`)
            .subscribe(schema => {
              this.state.setSchema(schema);
              const sorted = [...schema.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
              this.fieldsList$.next(sorted);
              this.schemaForm.patchValue({
                type: schema.type,
                version: schema.version,
                description: schema.description,
              });
              this.storage.saveDraft(schema);
              this.buildDataSource();
              this.ref.markForCheck();
            });
        }
      });
    } else if (Number.isFinite(draftIdParam)) {
      const userId = this.currentUser.getUserId();
      this.http
        .get<{ statusCode: number; data?: { drafts: any[] } }>(`/api/drafts/pending`, {
          params: { userId },
          observe: 'body',
        })
        .subscribe(resp => {
          const list = (resp.data?.drafts ?? []) as any[];
          const found = list.find(d => Number(d?.id) === draftIdParam);
          const schema = (found?.changes ?? null) as FormSchemaModel | null;

          if (!schema) {
            this.state.setSchema({ type: '', version: 1, description: '', fields: [] });
            this.fieldsList$.next([]);
            this.schemaForm.reset({ type: '', version: 1, description: '' });
            this.createInitialDraft();

            return;
          }

          this.currentDraftId = draftIdParam;
          this.state.setSchema(schema);
          const sorted = [...(schema.fields ?? [])].sort((a, b) => (a.order || 0) - (b.order || 0));
          this.fieldsList$.next(sorted);
          this.schemaForm.patchValue({
            type: schema.type,
            version: schema.version,
            description: schema.description,
          });
          this.storage.saveDraft(schema);
          this.buildDataSource();
          this.ref.markForCheck();
        });
    } else {
      this.state.setSchema({ type: '', version: 1, description: '', fields: [] });
      this.storage.clearDraft();
      this.fieldsList$.next([]);
      this.schemaForm.reset({ type: '', version: 1, description: '' });
      this.createInitialDraft();
    }

    this.route.queryParamMap.subscribe(params => {
      const idParam2 = Number(params.get('id') ?? NaN);
      const draftIdParam2 = Number(params.get('draftId') ?? NaN);

      this.inlineRowForms = {};
      this.expandedRows.clear();

      if (Number.isFinite(idParam2)) {
        this.editFormId = idParam2;
        const userId = this.currentUser.getUserId();
        this.storage.getPendingDrafts(userId).subscribe(list => {
          const existing = list.find(
            d => Number(d?.['formId']) === idParam2 && Boolean(d?.['publishedVersionExists']),
          ) as Record<string, unknown> | undefined;

          if (existing && existing['changes']) {
            const schema = existing['changes'] as FormSchemaModel;
            this.currentDraftId = Number((existing['id'] as number | undefined) ?? NaN);
            this.state.setSchema(schema);
            const sorted = [...(schema.fields ?? [])].sort(
              (a, b) => (a.order || 0) - (b.order || 0),
            );
            this.fieldsList$.next(sorted);
            this.schemaForm.patchValue({
              type: schema.type,
              version: schema.version,
              description: schema.description,
            });
            this.storage.saveDraft(schema);
            this.buildDataSource();
            this.ref.markForCheck();
          } else {
            this.http
              .get<FormSchemaModel>(`/api/editor/form-schema?id=${idParam2}`)
              .subscribe(schema => {
                this.currentDraftId = null;
                this.state.setSchema(schema);
                const sorted = [...schema.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
                this.fieldsList$.next(sorted);
                this.schemaForm.patchValue({
                  type: schema.type,
                  version: schema.version,
                  description: schema.description,
                });
                this.storage.saveDraft(schema);
                this.buildDataSource();
                this.ref.markForCheck();
              });
          }
        });
      } else if (Number.isFinite(draftIdParam2)) {
        const userId = this.currentUser.getUserId();
        this.storage.getPendingDrafts(userId).subscribe(list => {
          const found = list.find(d => Number(d?.['id']) === draftIdParam2) as
            | Record<string, unknown>
            | undefined;
          const schema = (found?.['changes'] ?? null) as FormSchemaModel | null;

          if (!schema) {
            this.state.setSchema({ type: '', version: 1, description: '', fields: [] });
            this.fieldsList$.next([]);
            this.schemaForm.reset({ type: '', version: 1, description: '' });
            this.createInitialDraft();

            return;
          }

          this.currentDraftId = draftIdParam2;
          this.state.setSchema(schema);
          const sorted = [...(schema.fields ?? [])].sort((a, b) => (a.order || 0) - (b.order || 0));
          this.fieldsList$.next(sorted);
          this.schemaForm.patchValue({
            type: schema.type,
            version: schema.version,
            description: schema.description,
          });
          this.storage.saveDraft(schema);
          this.buildDataSource();
          this.ref.markForCheck();
        });
      } else {
        this.editFormId = null;
        this.currentDraftId = null;
        this.state.setSchema({ type: '', version: 1, description: '', fields: [] });
        this.storage.clearDraft();
        this.fieldsList$.next([]);
        this.schemaForm.reset({ type: '', version: 1, description: '' });
        this.createInitialDraft();
      }
    });

    this.fieldForm.addControl('validations', this.validationsFormArray);
    this.state.schema$.subscribe(currentSchema => {
      if (!currentSchema) return;

      const sorted = [...currentSchema.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
      this.fieldsList$.next(sorted);
      this.setupInlineForms(sorted);
      this.buildDataSource();
      this.ref.markForCheck();
    });
    this.reorderForm = this.fb.group({ names: [[]] });
    this.buildDataSource();
    this.ref.markForCheck();
  }

  private readonly fb = inject(FormBuilder);
  private readonly state = inject(FormBuilderStateService);
  private readonly storage = inject(SchemaStorageService);
  private readonly validator = inject(SchemaValidatorService);
  private readonly helpers = inject(SchemaHelpersService);
  private readonly persistence = inject(SchemaPersistenceService);
  private readonly ref = inject(ChangeDetectorRef);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly http = inject(HttpClient);
  private readonly currentUser = inject(CurrentUserService);
  private readonly toastr = inject(ToastrService);

  schemaForm: FormGroup = this.fb.group({
    type: ['', [Validators.required]],
    version: [1, [Validators.required, Validators.min(1)]],
    description: ['', [Validators.required]],
  });

  newFieldForm: FormGroup = this.fb.group({
    name: ['', [Validators.required]],
    labelKey: ['', []],
    type: ['string', [Validators.required]],
  });

  expandedRows = new Set<string>();

  fieldForm: FormGroup = this.fb.group({
    name: ['', [Validators.required]],
    labelKey: ['', []],
    type: ['string', [Validators.required]],
    widget: ['text', [Validators.required]],
    required: [false],
    disabled: [false],
    order: [1, [Validators.required, Validators.min(1)]],
    tabIndex: [1, [Validators.required, Validators.min(1)]],
    uiMask: [''],
    uiHint: [''],
    valuesText: [''],
    uiBindKey: [''],
    uiBindLabel: [''],
  });

  validationsFormArray: FormArray = this.fb.array([]);
  dependenciesForm: FormGroup = this.fb.group({
    visibleRoot: this.fb.group({ combinator: ['all'], not: [false], items: this.fb.array([]) }),
    enableRoot: this.fb.group({ combinator: ['all'], not: [false], items: this.fb.array([]) }),
  });

  autoFillForm: FormGroup = this.fb.group({
    triggerField: [''],
    api: [''],
    behavior: ['ask|replace|fillEmpty'],
    mappings: this.fb.array([]),
    confirmationText: [''],
  });

  fieldTypeOptions = [
    { label: 'autocomplete', value: 'autocomplete' },
    { label: 'boolean', value: 'boolean' },
    { label: 'color', value: 'color' },
    { label: 'date', value: 'date' },
    { label: 'enum', value: 'enum' },
    { label: 'file', value: 'file' },
    { label: 'number', value: 'number' },
    { label: 'string', value: 'string' },
  ];

  widgetOptions = [
    { label: 'text', value: 'text' },
    { label: 'number', value: 'number' },
    { label: 'textarea', value: 'textarea' },
    { label: 'checkbox', value: 'checkbox' },
    { label: 'select', value: 'select' },
    { label: 'multiselect', value: 'multiselect' },
    { label: 'datepicker', value: 'datepicker' },
    { label: 'calendar', value: 'calendar' },
    { label: 'fileupload', value: 'fileupload' },
    { label: 'autocomplete', value: 'autocomplete' },
    { label: 'color', value: 'color' },
    { label: 'confirmDialog', value: 'confirmDialog' },
  ];

  behaviorOptions = [
    { label: 'ask', value: 'ask' },
    { label: 'replace', value: 'replace' },
    { label: 'fillEmpty', value: 'fillEmpty' },
    { label: 'ask|replace|fillEmpty', value: 'ask|replace|fillEmpty' },
  ];

  fieldsList$: BehaviorSubject<FieldDefinitionModel[]> = new BehaviorSubject<
    FieldDefinitionModel[]
  >([]);

  dataSource!: Observable<DataTable<TableRowModel>>;
  private currentPage = 0;
  private itemsPerPage: ItemsPerPageType = 96;

  issues$: BehaviorSubject<string[]> = new BehaviorSubject<string[]>([]);
  previewRequested$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  inlineRowForms: Record<string, FormGroup> = {};
  modalOpen = false;
  modalTitleName = '';
  previewOpen = false;
  previewSchema: any = null;
  templateOpen = false;
  templateOptions = [
    { label: 'CEP com AutoFill (CEP, Estado, Cidade, Rua)', value: 'cepAutocomplete' },
    { label: 'CPF com máscara e validação regex', value: 'cpfRegex' },
    { label: 'Dropdown com carregamento via API', value: 'dropdownManufacturers' },
    { label: 'Dropdowns em cascata (Estado → Cidade → Bairro)', value: 'cascadeLocation' },
  ];

  private editFormId: number | null = null;
  private currentDraftId: number | null = null;

  validationNameOptions = [
    { label: 'required', value: 'required' },
    { label: 'min', value: 'min' },
    { label: 'max', value: 'max' },
    { label: 'minLength', value: 'minLength' },
    { label: 'maxLength', value: 'maxLength' },
    { label: 'pattern', value: 'pattern' },
    { label: 'regex', value: 'regex' },
    { label: 'cpf', value: 'cpf' },
    { label: 'notPast', value: 'notPast' },
    { label: 'notFuture', value: 'notFuture' },
    { label: 'maxDiffMonths', value: 'maxDiffMonths' },
    { label: 'maxDateYear', value: 'maxDateYear' },
    { label: 'fileTypes', value: 'fileTypes' },
    { label: 'maxSizeMB', value: 'maxSizeMB' },
    { label: 'maxFiles', value: 'maxFiles' },
  ];

  addValidation(): void {
    const group = this.fb.group({ name: ['', [Validators.required]], value: [''], message: [''] });
    this.validationsFormArray.push(group);
  }

  onCancel(): void {
    void this.router.navigate(['../adm'], { relativeTo: this.route });
  }

  private buildDataSource(): void {
    const list = this.fieldsList$.getValue();
    const start = this.currentPage * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    const rows = list.slice(start, end).map(f => ({ ...f, id: f.name }));
    const pageToken = Math.random().toString(36).substring(2, 12);
    this.dataSource = of({ pageToken, rows });
    this.ref.markForCheck();
  }

  setPage(currenPageToken: number | string): void {
    const isValid = Number.isFinite(currenPageToken as number) && (currenPageToken as number) > 0;
    this.currentPage = isValid ? (currenPageToken as number) - 1 : 0;
    this.buildDataSource();
    this.ref.markForCheck();
  }

  removeValidation(index: number): void {
    this.validationsFormArray.removeAt(index);
  }

  onTypeChange(): void {
    const type = this.fieldForm.get('type')?.value as FieldDefinitionModel['type'];
    const widget = this.helpers.suggestWidget(type);
    this.fieldForm.get('widget')?.setValue(widget);
  }

  addField(): void {
    const baseValues = this.readFieldFormValues();
    const validations = this.readValidations();
    const dependencies = this.readDependencies();
    const autoFill = this.readAutoFill();
    const currentFields = this.fieldsList$.getValue();
    const nextOrder = this.helpers.nextOrder(currentFields);
    const nextTabIndex = this.helpers.nextTabIndex(currentFields);
    const merged = {
      ...baseValues,
      validations,
      dependencies,
      autoFill,
      order: baseValues.order ?? nextOrder,
      tabIndex: baseValues.tabIndex ?? nextTabIndex,
    };
    const field = this.helpers.toFieldDefinition(merged, { nextOrder, nextTabIndex });
    const schema = this.buildSchemaWithNewField(field);
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);

      return;
    }

    this.state.addField(field);
    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.clearFieldForms();
    this.issues$.next([]);
    this.buildDataSource();
    this.ref.markForCheck();
  }

  editField(name: string): void {
    const current = this.state.currentSchema();

    if (!current) return;

    const selectedField = current.fields.find(x => x.name === name);

    if (!selectedField) return;

    this.fieldForm.patchValue({
      name: selectedField.name,
      labelKey: selectedField.labelKey,
      type: selectedField.type,
      widget: selectedField.widget,
      required: selectedField.required ?? false,
      disabled: selectedField.disabled ?? false,
      order: selectedField.order,
      tabIndex: selectedField.tabIndex,
      uiMask: selectedField.ui?.mask ?? '',
      uiHint: selectedField.ui?.hint ?? '',
      valuesText: (selectedField.values ?? []).join(','),
      uiBindKey: selectedField.ui?.bindKey ?? '',
      uiBindLabel: selectedField.ui?.bindLabel ?? '',
    });
    this.validationsFormArray.clear();
    (selectedField.validations ?? []).forEach(v =>
      this.validationsFormArray.push(
        this.fb.group({ name: [v.name], value: [v.value], message: [v.message ?? ''] }),
      ),
    );

    if (this.validationsFormArray.length === 0) {
      this.validationsFormArray.push(this.fb.group({ name: [''], value: [''], message: [''] }));
    }

    const visibleRoot = this.dependenciesForm.get('visibleRoot') as FormGroup;
    const enableRoot = this.dependenciesForm.get('enableRoot') as FormGroup;
    const vItems = visibleRoot.get('items') as FormArray;
    const eItems = enableRoot.get('items') as FormArray;
    vItems.clear();
    eItems.clear();

    const resolveOperator = (r: any): string =>
      r?.regex !== undefined
        ? 'regex'
        : r?.equals !== undefined || r?.value !== undefined
          ? 'equals'
          : r?.notEquals !== undefined
            ? 'notEquals'
            : r?.true
              ? 'true'
              : r?.false
                ? 'false'
                : r?.notEmpty
                  ? 'notEmpty'
                  : r?.valid
                    ? 'valid'
                    : 'equals';

    const pushRuleItem = (target: FormArray, r: any): void => {
      target.push(
        this.fb.group({
          kind: ['rule'],
          field: [r?.field || ''],
          operator: [resolveOperator(r)],
          operand: [r?.regex ?? r?.equals ?? r?.value ?? r?.notEquals ?? ''],
        }),
      );
    };

    const buildItems = (c: ConditionModel, target: FormArray): void => {
      if (!c) return;

      if ((c as any).not || (c as any).all || (c as any).any) {
        const group = this.fb.group({
          kind: ['group'],
          combinator: [(c as any).all ? 'all' : (c as any).any ? 'any' : 'all'],
          not: [Boolean((c as any).not)],
          items: this.fb.array([]),
        });
        const childList: ConditionModel[] = (c as any).not
          ? [(c as any).not as ConditionModel]
          : (((c as any).all ?? (c as any).any ?? []) as ConditionModel[]);
        childList.forEach((childCondition: ConditionModel) =>
          buildItems(childCondition, group.get('items') as FormArray),
        );
        target.push(group);

        return;
      }

      pushRuleItem(target, c as any);
    };

    const setRootFromCondition = (cond: any, root: FormGroup): void => {
      const itemsArr = root.get('items') as FormArray;
      itemsArr.clear();
      let top = cond;
      let rootNot = false;
      let rootComb = 'all';

      if (top && top.not) {
        rootNot = true;
        top = top.not;
      }

      if (top && (top.all || top.any)) rootComb = top.all ? 'all' : 'any';

      root.patchValue({ combinator: rootComb, not: rootNot });
      const children = top && (top.all || top.any) ? (top.all ?? top.any ?? []) : top ? [top] : [];
      (children as ConditionModel[]).forEach((childCondition: ConditionModel) =>
        buildItems(childCondition, itemsArr),
      );
    };

    setRootFromCondition(selectedField.dependencies?.visibleIf, visibleRoot);
    setRootFromCondition(selectedField.dependencies?.enableIf, enableRoot);
    const dsValUnknown = selectedField.ui?.dataSource as unknown;
    let endpointForModal = '';

    if (
      selectedField.widget === 'autocomplete' ||
      selectedField.widget === 'select' ||
      selectedField.widget === 'multiselect'
    ) {
      if (typeof dsValUnknown === 'string') {
        endpointForModal = dsValUnknown;
      } else if (dsValUnknown && typeof dsValUnknown === 'object') {
        const maybeUrl = (dsValUnknown as { url?: string }).url ?? '';
        endpointForModal = String(maybeUrl);
      }
    } else {
      endpointForModal = selectedField.autoFill?.api ?? '';
    }

    this.autoFillForm.patchValue({
      triggerField: selectedField.autoFill?.triggerField ?? '',
      api: endpointForModal,
      behavior: selectedField.autoFill?.behavior ?? 'ask|replace|fillEmpty',
      confirmationText: selectedField.ui?.confirmationText ?? '',
    });
    const mappingsArr = this.autoFillForm.get('mappings') as FormArray;
    mappingsArr.clear();
    const mapObj = selectedField.autoFill?.map ?? {};
    const keys = Object.keys(mapObj);

    if (keys.length === 0) {
      mappingsArr.push(this.fb.group({ fieldName: [''], sourcePath: [''] }));
    } else {
      keys.forEach(k =>
        mappingsArr.push(this.fb.group({ fieldName: [k], sourcePath: [mapObj[k] ?? ''] })),
      );
    }

    this.modalTitleName = selectedField.name;
  }

  updateField(): void {
    const baseValues = this.readFieldFormValues();
    const validations = this.readValidations();
    const dependencies = this.readDependencies();
    const autoFill = this.readAutoFill();
    const updatedPartial = { ...baseValues, validations, dependencies, autoFill };
    const fieldName = String(baseValues.name ?? '').trim();

    if (!fieldName) return;

    this.state.updateField(fieldName, updatedPartial);

    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.clearFieldForms();
  }

  removeField(name: string): void {
    Swal.fire({
      html: `Excluir o campo <b>${name}</b>? Esta ação não pode ser desfeita no rascunho atual.`,
      icon: 'warning',
      confirmButtonText: 'Sim, excluir',
      cancelButtonText: 'Cancelar',
      customClass: { confirmButton: 'btn btn-primary', cancelButton: 'btn btn-danger' },
      buttonsStyling: false,
      showCancelButton: true,
      allowOutsideClick: false,
      heightAuto: false,
      reverseButtons: true,
    }).then(r => {
      if (!r.isConfirmed) return;

      this.state.removeField(name);
      const updated = this.state.currentSchema();

      if (updated) this.storage.saveDraft(updated);

      delete this.inlineRowForms[name];
      this.buildDataSource();
      this.ref.markForCheck();
    });
  }

  saveDraft(): void {
    const schema = this.buildCurrentSchema();
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);

      return;
    }

    this.state.setSchema(schema);
    this.storage.saveDraft(schema);
    const formId = Number.isFinite(this.editFormId as number) ? (this.editFormId as number) : null;
    this.storage.persistDraft(schema, formId, this.currentDraftId ?? undefined).subscribe(id => {
      if (Number.isFinite(id)) this.currentDraftId = id;

      this.issues$.next([]);
      this.toastr.success('Rascunho salvo com sucesso.', 'Rascunho', {
        timeOut: 3000,
        progressBar: true,
      });
    });
  }

  preview(): void {
    const schema = this.buildCurrentSchema();
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);
      Swal.fire({
        html: issues.join('<br/>'),
        icon: 'error',
        confirmButtonText: 'Ok',
        customClass: { confirmButton: 'btn btn-primary' },
        buttonsStyling: false,
        allowOutsideClick: false,
        heightAuto: false,
      });

      return;
    }

    this.previewSchema = schema;
    this.previewOpen = true;
  }

  closePreview(): void {
    this.previewOpen = false;
  }

  openTemplatesModal(): void {
    this.templateOpen = true;
  }

  closeTemplatesModal(): void {
    this.templateOpen = false;
  }

  enterReorderMode(): void {
    const current = this.state.currentSchema();
    const sorted = (current?.fields ?? []).slice().sort((a, b) => (a.order || 0) - (b.order || 0));
    this.reorderList = sorted.map(f => f.name);
    this.originalOrderNames = this.reorderList.slice();
    this.reorderInitialValues = { names: this.originalOrderNames.slice() };
    this.reorderForm.setValue({ names: this.reorderList.slice() });
    this.previewSchemaBeforeReorder = current ? { ...current, fields: [...current.fields] } : null;
    this.reorderMode = true;
  }

  cancelReorderMode(): void {
    if (this.previewSchemaBeforeReorder) this.previewSchema = this.previewSchemaBeforeReorder;

    this.reorderList = this.originalOrderNames.slice();
    this.reorderForm.setValue({ names: this.originalOrderNames.slice() });
    this.reorderMode = false;
    this.dragFromIndex = null;
  }

  saveReorderMode(): void {
    if (this.reorderList.length === 0) {
      this.cancelReorderMode();

      return;
    }

    if (!formHasChanged(this.reorderForm, this.reorderInitialValues)) {
      this.cancelReorderMode();

      return;
    }

    this.state.reorderFields(this.reorderList);
    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.previewSchema = updated ?? this.previewSchema;
    this.reorderMode = false;
    this.dragFromIndex = null;
    this.buildDataSource();
    this.ref.markForCheck();
  }

  onDragStart(index: number): void {
    this.dragFromIndex = index;
  }

  onDragOver(index: number, event: DragEvent): void {
    event.preventDefault();
  }

  onDrop(index: number): void {
    if (this.dragFromIndex === null) return;

    const list = [...this.reorderList];
    const [moved] = list.splice(this.dragFromIndex, 1);
    list.splice(index, 0, moved);
    this.reorderList = list;
    this.dragFromIndex = null;
  }

  labelFor(name: string): string {
    const current = this.state.currentSchema();
    const f = (current?.fields ?? []).find(x => x.name === name);

    return f?.labelKey ?? name;
  }

  onPreviewOrderChange(names: string[]): void {
    this.reorderList = names.slice();
    this.reorderForm.setValue({ names: this.reorderList.slice() }, { emitEvent: false });
    const current = this.state.currentSchema();

    if (!current) return;

    const orderMap = new Map<string, number>();
    this.reorderList.forEach((n, i) => orderMap.set(n, i + 1));
    const updatedFields = current.fields.map(f => ({
      ...f,
      order: orderMap.get(f.name) ?? f.order,
    }));
    this.previewSchema = { ...current, fields: updatedFields };
  }

  hasReorderChanges(): boolean {
    return formHasChanged(this.reorderForm, this.reorderInitialValues);
  }

  onTableDragStart(index: number): void {
    this.tableDragFromIndex = index;
    this.tableReorderActive = true;
  }

  onTableDragOver(index: number, event: DragEvent): void {
    event.preventDefault();
  }

  onTableDrop(index: number): void {
    if (this.tableDragFromIndex === null) {
      this.tableReorderActive = false;

      return;
    }

    const current = this.state.currentSchema();

    if (!current) {
      this.tableDragFromIndex = null;
      this.tableReorderActive = false;

      return;
    }

    const sorted = [...current.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
    const names = sorted.map(f => f.name);
    const prevRects = new Map<string, DOMRect>();
    const wrapper = this.tableWrapper?.nativeElement;

    if (wrapper) {
      const rows = Array.from(wrapper.querySelectorAll('tbody tr')) as HTMLTableRowElement[];
      rows.forEach(row => {
        const marker = row.querySelector('[data-row-marker="1"]') as HTMLElement | null;
        const nm = marker?.getAttribute('data-name') || marker?.textContent?.trim() || '';

        if (nm) prevRects.set(nm, row.getBoundingClientRect());
      });
    }

    const [moved] = names.splice(this.tableDragFromIndex, 1);
    names.splice(index, 0, moved);
    this.state.reorderFields(names);
    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.tableDragFromIndex = null;
    this.tableReorderActive = false;
    this.tableDragPressedIndex = null;
    this.buildDataSource();
    this.ref.markForCheck();
    setTimeout(() => {
      if (this.tableWrapper?.nativeElement) {
        this.tableWrapper.nativeElement.style.overflowX = 'hidden';
      }

      const wrapper2 = this.tableWrapper?.nativeElement;

      if (wrapper2) {
        const rows = Array.from(wrapper2.querySelectorAll('tbody tr')) as HTMLTableRowElement[];
        rows.forEach(row => {
          const marker = row.querySelector('[data-row-marker="1"]') as HTMLElement | null;
          const name = marker?.getAttribute('data-name') || marker?.textContent?.trim() || '';

          if (!name) return;

          const prev = prevRects.get(name);

          if (!prev) return;

          const now = row.getBoundingClientRect();
          const dx = 0;
          const dy = prev.top - now.top;

          if (dx === 0 && dy === 0) return;

          const node = row as HTMLElement;
          node.style.transition = 'none';
          node.style.transform = `translate(${dx}px, ${dy}px) scale(1.02)`;
          node.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
          node.style.willChange = 'transform, box-shadow';
          requestAnimationFrame(() => {
            node.style.transition = 'transform 350ms ease-in-out, box-shadow 350ms ease-in-out';
            node.style.transform = 'translate(0, 0) scale(1)';
            node.style.boxShadow = '';
            setTimeout(() => {
              node.style.transition = '';
              node.style.willChange = '';
            }, 360);
          });
        });
      }

      setTimeout(() => {
        if (this.tableWrapper?.nativeElement) {
          this.tableWrapper.nativeElement.style.overflowX = '';
        }
      }, 400);
    }, 0);
  }

  onTableDragPress(index: number): void {
    this.tableDragPressedIndex = index;
  }

  onTableDragRelease(): void {
    this.tableDragPressedIndex = null;
  }

  onTableDragPressByName(name: string): void {
    this.tableDragPressedName = name;
  }

  onTableDropByName(targetName: string): void {
    const current = this.state.currentSchema();

    if (!current || !this.tableDragPressedName) {
      this.tableDragPressedName = null;

      return;
    }

    const sorted = [...current.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
    const names = sorted.map(f => f.name);
    const prevRects = new Map<string, DOMRect>();
    const wrapper = this.tableWrapper?.nativeElement;

    if (wrapper) {
      const rows = Array.from(wrapper.querySelectorAll('tbody tr')) as HTMLTableRowElement[];
      rows.forEach(row => {
        const marker = row.querySelector('[data-row-marker="1"]') as HTMLElement | null;
        const nm = marker?.getAttribute('data-name') || marker?.textContent?.trim() || '';

        if (nm) prevRects.set(nm, row.getBoundingClientRect());
      });
    }

    const fromIdx = names.indexOf(this.tableDragPressedName);
    const toIdx = names.indexOf(targetName);

    if (fromIdx < 0 || toIdx < 0) {
      this.tableDragPressedName = null;

      return;
    }

    const [moved] = names.splice(fromIdx, 1);
    names.splice(toIdx, 0, moved);
    this.state.reorderFields(names);
    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.tableDragPressedName = null;
    this.buildDataSource();
    this.ref.markForCheck();

    if (this.tableWrapper?.nativeElement) {
      this.tableWrapper.nativeElement.style.overflowX = 'hidden';
    }

    setTimeout(() => {
      const wrapper2 = this.tableWrapper?.nativeElement;

      if (wrapper2) {
        const rows = Array.from(wrapper2.querySelectorAll('tbody tr')) as HTMLTableRowElement[];
        rows.forEach(row => {
          const marker = row.querySelector('[data-row-marker="1"]') as HTMLElement | null;
          const name = marker?.getAttribute('data-name') || marker?.textContent?.trim() || '';

          if (!name) return;

          const prev = prevRects.get(name);

          if (!prev) return;

          const now = row.getBoundingClientRect();
          const dx = 0;
          const dy = prev.top - now.top;

          if (dx === 0 && dy === 0) return;

          const node = row as HTMLElement;
          node.style.transition = 'none';
          node.style.transform = `translate(${dx}px, ${dy}px)`;
          node.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
          node.style.willChange = 'transform, box-shadow';
          requestAnimationFrame(() => {
            node.style.transition = 'transform 350ms ease-in-out, box-shadow 350ms ease-in-out';
            node.style.transform = 'translate(0, 0)';
            node.style.boxShadow = '';
            setTimeout(() => {
              node.style.transition = '';
              node.style.willChange = '';
            }, 360);
          });
        });
      }

      setTimeout(() => {
        if (this.tableWrapper?.nativeElement) {
          this.tableWrapper.nativeElement.style.overflowX = '';
        }
      }, 400);
    }, 0);
  }

  generateFromTemplate(key: string): void {
    const suffix = String(Date.now());
    const list =
      key === 'cepAutocomplete'
        ? this.buildCepTemplateFields(suffix)
        : key === 'dropdownManufacturers'
          ? [this.buildManufacturersDropdownField(suffix)]
          : key === 'cascadeLocation'
            ? this.buildCascadingLocationFields(suffix)
            : [this.buildCpfTemplateField(suffix)];
    let existing = this.fieldsList$.getValue();
    let nextOrder = this.helpers.nextOrder(existing);
    let nextTab = this.helpers.nextTabIndex(existing);
    list.forEach(f => {
      const withOrder: FieldDefinitionModel = {
        ...f,
        order: nextOrder,
        tabIndex: nextTab,
      } as FieldDefinitionModel;
      this.state.addField(withOrder);
      const updated = this.state.currentSchema();
      existing = updated ? updated.fields : existing;
      nextOrder = this.helpers.nextOrder(existing);
      nextTab = this.helpers.nextTabIndex(existing);
    });
    const updatedSchema = this.state.currentSchema();

    if (updatedSchema) this.storage.saveDraft(updatedSchema);

    this.closeTemplatesModal();
  }

  private buildCepTemplateFields(suffix: string): FieldDefinitionModel[] {
    const zip = `zipCode_${suffix}`;
    const state = `state_${suffix}`;
    const city = `city_${suffix}`;
    const street = `street_${suffix}`;
    const zipField: FieldDefinitionModel = {
      name: zip,
      labelKey: '',
      type: 'string',
      widget: 'text',
      required: true,
      validations: [
        { name: 'pattern', value: '^\\d{5}-?\\d{3}$', message: 'CEP inválido' },
        { name: 'maxLength', value: 9 },
      ],
      ui: { mask: '00000-000' },
      autoFill: {
        triggerField: zip,
        api: `https://viacep.com.br/ws/{{${zip}}}/json/`,
        behavior: 'ask|replace|fillEmpty',
        map: {
          [state]: 'uf',
          [city]: 'localidade',
          [street]: 'logradouro',
        },
      },
    } as FieldDefinitionModel;
    const stateField: FieldDefinitionModel = {
      name: state,
      labelKey: '',
      type: 'string',
      widget: 'text',
      disabled: true,
      dependencies: { enableIf: { field: zip, regex: '^[0-9]{5}-?[0-9]{3}$' } },
    } as FieldDefinitionModel;
    const cityField: FieldDefinitionModel = {
      name: city,
      labelKey: '',
      type: 'string',
      widget: 'text',
      disabled: true,
      dependencies: { enableIf: { field: zip, notEmpty: true } },
    } as FieldDefinitionModel;
    const streetField: FieldDefinitionModel = {
      name: street,
      labelKey: '',
      type: 'string',
      widget: 'text',
      disabled: true,
      dependencies: { enableIf: { field: zip, notEmpty: true } },
    } as FieldDefinitionModel;

    return [zipField, stateField, cityField, streetField];
  }

  private buildCpfTemplateField(suffix: string): FieldDefinitionModel {
    const cpf = `cpf_${suffix}`;
    const field: FieldDefinitionModel = {
      name: cpf,
      labelKey: '',
      type: 'string',
      widget: 'text',
      required: true,
      validations: [
        {
          name: 'pattern',
          value: '^[0-9]{3}\\.?[0-9]{3}\\.?[0-9]{3}-?[0-9]{2}$',
          message: 'CPF inválido',
        },
        { name: 'maxLength', value: 14 },
        { name: 'cpf', message: 'CPF inválido' },
      ],
      ui: { mask: '000.000.000-00' },
    } as FieldDefinitionModel;

    return field;
  }

  private buildManufacturersDropdownField(suffix: string): FieldDefinitionModel {
    const name = `manufacturer_${suffix}`;
    const field: FieldDefinitionModel = {
      name,
      labelKey: '',
      type: 'enum',
      widget: 'select',
      required: true,
      validations: [{ name: 'required' }],
      ui: {
        dataSource: 'api/manufacturers',
        bindKey: 'id',
        bindLabel: 'label',
        hint: 'Selecione o fabricante',
      },
    } as FieldDefinitionModel;

    return field;
  }

  private buildCascadingLocationFields(suffix: string): FieldDefinitionModel[] {
    const uf = `state_${suffix}`;
    const city = `city_${suffix}`;
    const hood = `neighborhood_${suffix}`;

    const ufField: FieldDefinitionModel = {
      name: uf,
      labelKey: '',
      type: 'enum',
      widget: 'select',
      required: true,
      validations: [{ name: 'required' }],
      ui: {
        dataSource: 'https://brasilapi.com.br/api/ibge/uf/v1',
        bindKey: 'sigla',
        bindLabel: 'nome',
        hint: 'Selecione o estado',
      },
    } as FieldDefinitionModel;

    const cityField: FieldDefinitionModel = {
      name: city,
      labelKey: '',
      type: 'enum',
      widget: 'select',
      required: true,
      dependencies: { enableIf: { field: uf, notEmpty: true } },
      ui: {
        dataSource: `https://brasilapi.com.br/api/ibge/municipios/v1/{{${uf}}}`,
        bindKey: 'nome',
        bindLabel: 'nome',
        hint: 'Selecione a cidade',
      },
      validations: [{ name: 'required' }],
    } as FieldDefinitionModel;

    const hoodField: FieldDefinitionModel = {
      name: hood,
      labelKey: '',
      type: 'enum',
      widget: 'select',
      required: true,
      dependencies: { enableIf: { field: city, notEmpty: true } },
      ui: {
        dataSource: `api/neighborhoods?city={{${city}}}`,
        bindKey: 'nome',
        bindLabel: 'nome',
        hint: 'Selecione o bairro',
      },
      validations: [{ name: 'required' }],
    } as FieldDefinitionModel;

    return [ufField, cityField, hoodField];
  }

  onTemplateChosen(key: string): void {
    this.generateFromTemplate(key);
  }

  saveJSONFile(): void {
    const schema = this.buildCurrentSchema();
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);

      return;
    }

    this.persistence.triggerDownloadJson(schema);
  }

  async publish(): Promise<void> {
    const schema = this.buildCurrentSchema();
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);
      Swal.fire({
        html: issues.join('<br/>'),
        icon: 'error',
        confirmButtonText: 'Ok',
        customClass: { confirmButton: 'btn btn-primary' },
        buttonsStyling: false,
        allowOutsideClick: false,
        heightAuto: false,
      });

      return;
    }

    const hasExisting = Number.isFinite(this.editFormId as number);
    const proceed = async (): Promise<void> => {
      await this.publishToDb(schema);

      if (Number.isFinite(this.currentDraftId as number)) {
        this.http.delete<void>(`/api/drafts/${this.currentDraftId}`).subscribe(() => {});
      } else {
        const userId = this.currentUser.getUserId();
        this.http
          .get<{ statusCode: number; data?: { drafts: any[] } }>(`/api/drafts/pending`, {
            params: { userId },
            observe: 'body',
          })
          .subscribe(resp => {
            const list = (resp.data?.drafts ?? []) as any[];
            const found = list.find(
              d =>
                (hasExisting ? d.formId === this.editFormId : !d.publishedVersionExists) &&
                d.type === (schema.type || 'custom-draft'),
            ) as any;
            const id = Number(found?.id ?? NaN);

            if (Number.isFinite(id))
              this.http.delete<void>(`/api/drafts/${id}`).subscribe(() => {});
          });
      }

      void this.router.navigate(['../adm'], { relativeTo: this.route }).then(() => {
        this.toastr.success('Formulário publicado com sucesso.', 'Publicação', {
          timeOut: 3000,
          progressBar: true,
        });
      });
    };

    if (hasExisting) {
      Swal.fire({
        html: 'Publicação existente será substituída. Deseja continuar?',
        icon: 'warning',
        confirmButtonText: 'Sim, publicar',
        cancelButtonText: 'Não, cancelar',
        customClass: { confirmButton: 'btn btn-primary', cancelButton: 'btn btn-danger' },
        buttonsStyling: false,
        showCancelButton: true,
        allowOutsideClick: false,
        heightAuto: false,
        reverseButtons: true,
      }).then(r => {
        if (r.isConfirmed) void proceed();
      });
    } else {
      await proceed();
    }
  }

  hasPublishedVersion(): boolean {
    return Number.isFinite(this.editFormId as number);
  }

  revertToPublished(): void {
    if (!Number.isFinite(this.editFormId as number)) return;

    Swal.fire({
      html: 'Esta ação irá descartar o rascunho atual e reverter para a última versão publicada.',
      icon: 'warning',
      confirmButtonText: 'Sim, reverter',
      cancelButtonText: 'Não, cancelar',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-danger',
      },
      buttonsStyling: false,
      showCancelButton: true,
      allowOutsideClick: false,
      heightAuto: false,
      reverseButtons: true,
    }).then(result => {
      if (!result.isConfirmed) return;

      const proceed = (): void => {
        const id = this.editFormId as number;
        this.http.get<FormSchemaModel>(`/api/editor/form-schema?id=${id}`).subscribe(schema => {
          this.state.setSchema(schema);
          const sorted = [...schema.fields].sort((a, b) => (a.order || 0) - (b.order || 0));
          this.fieldsList$.next(sorted);
          this.schemaForm.patchValue({
            type: schema.type,
            version: schema.version,
            description: schema.description,
          });
          this.storage.clearDraft();
          this.buildDataSource();
          this.ref.markForCheck();
        });
      };

      if (Number.isFinite(this.currentDraftId as number)) {
        this.http.delete<void>(`/api/drafts/${this.currentDraftId}`).subscribe(() => {
          this.currentDraftId = null;
          proceed();
        });
      } else {
        const userId = this.currentUser.getUserId();
        this.http
          .get<{ statusCode: number; data?: { drafts: any[] } }>(`/api/drafts/pending`, {
            params: { userId },
            observe: 'body',
          })
          .subscribe(resp => {
            const list = (resp.data?.drafts ?? []) as any[];
            const found = list.find(d => d.formId === this.editFormId) as any;
            const id = Number(found?.id ?? NaN);

            if (Number.isFinite(id)) {
              this.http.delete<void>(`/api/drafts/${id}`).subscribe(() => proceed());
            } else {
              proceed();
            }
          });
      }
    });
  }

  private openDb(): Promise<IDBDatabase> {
    const dbName = 'collateral-idb';
    const dbVersion = 3;

    return new Promise((resolve, reject) => {
      const reqOpen = indexedDB.open(dbName, dbVersion);
      reqOpen.onupgradeneeded = () => {
        const db = reqOpen.result;

        if (!db.objectStoreNames.contains('forms')) {
          const store = db.createObjectStore('forms', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: false });
          store.createIndex('name', 'name', { unique: false });
          store.createIndex('version', 'version', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        if (!db.objectStoreNames.contains('schemas')) {
          const store = db.createObjectStore('schemas', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: true });
        }

        if (!db.objectStoreNames.contains('seed')) db.createObjectStore('seed', { keyPath: 'key' });
      };
      reqOpen.onerror = () => reject(reqOpen.error);
      reqOpen.onsuccess = () => resolve(reqOpen.result);
    });
  }

  private findFormByType(db: IDBDatabase, type: string): Promise<any | null> {
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('forms', 'readonly');
        const idx = tx.objectStore('forms').index('type');
        const reqIdx = idx.openCursor(IDBKeyRange.only(type));
        reqIdx.onsuccess = () => {
          const cursor = reqIdx.result as IDBCursorWithValue | null;
          resolve(cursor ? (cursor.value as any) : null);
        };
        reqIdx.onerror = () => reject(reqIdx.error);
      } catch (e) {
        reject(e as any);
      }
    });
  }

  private putForm(db: IDBDatabase, row: any): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('forms', 'readwrite');
        const store = tx.objectStore('forms');
        const put = store.put(row);
        put.onsuccess = () => resolve();
        put.onerror = () => reject(put.error);
      } catch (e) {
        reject(e as any);
      }
    });
  }

  private putSchema(db: IDBDatabase, id: number, type: string, body: any): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('schemas', 'readwrite');
        const store = tx.objectStore('schemas');
        const put = store.put({ id, type, schema: body });
        put.onsuccess = () => resolve();
        put.onerror = () => reject(put.error);
      } catch (e) {
        reject(e as any);
      }
    });
  }

  private async publishToDb(schema: FormSchemaModel): Promise<void> {
    const db = await this.openDb();
    const now = new Date().toISOString();
    const existing = await this.findFormByType(db, schema.type);
    const id = Number.isFinite(this.editFormId as number)
      ? (this.editFormId as number)
      : Number(existing?.id ?? NaN) || Date.now() + Math.floor(Math.random() * 1000);
    const createdAt = (existing?.createdAt as string) ?? now;
    const name = (existing?.name as string) ?? (schema.type || 'Formulário');
    const row = {
      id,
      type: schema.type,
      name,
      version: String(schema.version),
      status: 'published',
      fieldsCount: (schema.fields ?? []).length,
      createdAt,
      updatedAt: now,
    } as any;
    await this.putSchema(db, id, schema.type, schema);
    await this.putForm(db, row);
  }

  private createInitialDraft(): void {
    this.currentDraftId = null;
  }

  resetFormBuilder(): void {
    Swal.fire({
      html: 'Esta ação irá redefinir completamente o construtor de formulário e apagar o rascunho salvo.',
      icon: 'warning',
      confirmButtonText: 'Sim, redefinir',
      cancelButtonText: 'Não, cancelar',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-danger',
      },
      buttonsStyling: false,
      showCancelButton: true,
      allowOutsideClick: false,
      heightAuto: false,
      reverseButtons: true,
    }).then(confirmResult => {
      if (confirmResult.isConfirmed) this.performFullFormBuilderReset();
    });
  }

  private performFullFormBuilderReset(): void {
    this.modalOpen = false;
    const currentType = String(this.schemaForm.get('type')?.value ?? '').trim();
    const currentVersion = Number(this.schemaForm.get('version')?.value ?? 1);
    const currentDescription = String(this.schemaForm.get('description')?.value ?? '').trim();
    this.fieldsList$.next([]);
    this.state.setSchema({
      type: currentType,
      version: currentVersion,
      description: currentDescription,
      fields: [],
    });
    this.schemaForm.patchValue({
      type: currentType,
      version: currentVersion,
      description: currentDescription,
    });
    this.newFieldForm.reset({ name: '', labelKey: '', type: 'string' });
    this.inlineRowForms = {};
    this.fieldForm.reset({
      type: 'string',
      widget: 'text',
      required: false,
      disabled: false,
      order: 1,
      tabIndex: 1,
      uiMask: '',
      valuesText: '',
    });
    this.validationsFormArray.clear();
    const vArr = this.dependenciesForm.get('visibleRules') as FormArray;
    const eArr = this.dependenciesForm.get('enableRules') as FormArray;
    vArr.clear();
    eArr.clear();
    this.dependenciesForm.patchValue({
      visibleGroupCombinator: 'all',
      visibleGroupNot: false,
      enableGroupCombinator: 'all',
      enableGroupNot: false,
    });
    this.autoFillForm.reset({ behavior: 'ask|replace|fillEmpty' });
    const autoFillMappingsFormArray = this.autoFillForm.get('mappings') as FormArray;
    autoFillMappingsFormArray.clear();
    const schema = this.buildCurrentSchema();
    this.storage.saveDraft(schema);
    this.issues$.next([]);
  }

  executeComplexFooterAction(): void {}

  onImportButtonClicked(fileInput: HTMLInputElement): void {
    Swal.fire({
      html: 'Esta ação irá importar um arquivo e <b>sobrescrever todos os campos</b> do formulário atual.',
      icon: 'warning',
      confirmButtonText: 'Sim, importar',
      cancelButtonText: 'Não, cancelar',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-danger',
      },
      buttonsStyling: false,
      showCancelButton: true,
      allowOutsideClick: false,
      heightAuto: false,
      reverseButtons: true,
    }).then(result => {
      if (result.isConfirmed) {
        fileInput.value = '';
        fileInput.click();
      }
    });
  }

  async onImportFileChanged(event: Event): Promise<void> {
    const inputElement = event.target as HTMLInputElement;
    const selectedFile =
      inputElement.files && inputElement.files.length > 0 ? inputElement.files[0] : null;

    if (!selectedFile) return;

    try {
      const importedSchemaRaw = await this.persistence.importFromFile(selectedFile);
      const importedSchema = this.normalizeImportedSchema(importedSchemaRaw);
      const basicValid = this.isBasicSchemaValid(importedSchema);
      const issues = this.validator.validate(importedSchema).map(i => `${i.path}: ${i.message}`);

      if (!basicValid || issues.length > 0) {
        const errorMessage = issues.length > 0 ? issues.join('<br/>') : 'Schema inválido';
        Swal.fire({
          html: errorMessage,
          icon: 'error',
          confirmButtonText: 'Ok, entendi',
          customClass: { confirmButton: 'btn btn-primary' },
          buttonsStyling: false,
          allowOutsideClick: false,
          heightAuto: false,
        });

        return;
      }

      this.state.setSchema(importedSchema);
      this.fieldsList$.next(importedSchema.fields);
      this.schemaForm.patchValue({
        type: importedSchema.type,
        version: importedSchema.version,
        description: importedSchema.description,
      });
      this.storage.saveDraft(importedSchema);
      Swal.fire({
        html: 'Importação concluída com sucesso.',
        icon: 'success',
        confirmButtonText: 'Ok',
        customClass: { confirmButton: 'btn btn-primary' },
        buttonsStyling: false,
        allowOutsideClick: false,
        heightAuto: false,
      });
    } catch {
      Swal.fire({
        html: 'Falha ao ler o arquivo. Verifique se é um JSON válido.',
        icon: 'error',
        confirmButtonText: 'Ok',
        customClass: { confirmButton: 'btn btn-primary' },
        buttonsStyling: false,
        allowOutsideClick: false,
        heightAuto: false,
      });
    }
  }

  private normalizeImportedSchema(schema: FormSchemaModel): FormSchemaModel {
    const fields = (schema.fields ?? []).map(f => {
      const clone = { ...f } as any;

      if (
        clone.type === 'enum' &&
        ['text', 'textarea', 'autocomplete', 'color'].includes(clone.widget)
      ) {
        clone.type = 'string';
      }

      return clone as FieldDefinitionModel;
    });

    return { ...schema, fields };
  }

  private isBasicSchemaValid(obj: FormSchemaModel | null): boolean {
    if (!obj) return false;

    const hasType = typeof obj.type === 'string' && obj.type.length > 0;
    const hasVersion = typeof obj.version === 'number' && obj.version >= 1;
    const hasDescription = typeof obj.description === 'string';
    const hasFieldsArray = Array.isArray(obj.fields);

    return hasType && hasVersion && hasDescription && hasFieldsArray;
  }

  private buildSchemaWithNewField(field: FieldDefinitionModel): FormSchemaModel {
    const base = this.buildCurrentSchema();

    return { ...base, fields: [...base.fields, field] };
  }

  private buildCurrentSchema(): FormSchemaModel {
    const type = String(this.schemaForm.get('type')?.value ?? '').trim();
    const version = Number(this.schemaForm.get('version')?.value ?? 1);
    const description = String(this.schemaForm.get('description')?.value ?? '').trim();
    const existing = this.fieldsList$.getValue();

    return { type, version, description, fields: existing };
  }

  private readFieldFormValues(): Partial<FieldDefinitionModel> {
    const name = String(this.fieldForm.get('name')?.value ?? '').trim();
    const labelKey = String(this.fieldForm.get('labelKey')?.value ?? '').trim();
    const type = this.fieldForm.get('type')?.value as FieldDefinitionModel['type'];
    const widget = this.fieldForm.get('widget')?.value as FieldDefinitionModel['widget'];
    const tabIndex = Number(this.fieldForm.get('tabIndex')?.value ?? 1);
    const uiMask = String(this.fieldForm.get('uiMask')?.value ?? '').trim();
    const uiHint = String(this.fieldForm.get('uiHint')?.value ?? '').trim();
    const uiBindKey = String(this.fieldForm.get('uiBindKey')?.value ?? '').trim();
    const uiBindLabel = String(this.fieldForm.get('uiBindLabel')?.value ?? '').trim();
    const valuesRaw = String(this.fieldForm.get('valuesText')?.value ?? '').trim();
    const values = valuesRaw
      ? valuesRaw
          .split(',')
          .map(x => x.trim())
          .filter(x => x.length > 0)
      : [];
    const ui: any = {};

    if (uiMask) ui.mask = uiMask;

    if (uiHint) ui.hint = uiHint;

    if (uiBindKey) ui.bindKey = uiBindKey;

    if (uiBindLabel) ui.bindLabel = uiBindLabel;

    const endpoint = String(this.autoFillForm.get('api')?.value ?? '').trim();

    if (['autocomplete', 'select', 'multiselect'].includes(widget) && endpoint)
      ui.dataSource = endpoint;

    const uiFinal = Object.keys(ui).length > 0 ? ui : undefined;

    return { name, labelKey, type, widget, tabIndex, values, ui: uiFinal };
  }

  private readValidations(): ValidationDefinitionModel[] {
    const numberRules = new Set([
      'min',
      'max',
      'minLength',
      'maxLength',
      'maxSizeMB',
      'maxFiles',
      'maxDiffMonths',
    ]);
    const arrayRules = new Set(['fileTypes']);

    const mapped = this.validationsFormArray.controls.map(c => {
      const g = c as FormGroup;
      const name = String(g.get('name')?.value ?? '').trim();
      const value: any = g.get('value')?.value;
      const message = String(g.get('message')?.value ?? '').trim();
      const m: ValidationDefinitionModel = { name };

      if (arrayRules.has(name)) {
        const raw = String(value ?? '').trim();

        if (raw)
          m.value = raw
            .split(',')
            .map(x => x.trim())
            .filter(x => x.length > 0);
      } else if (numberRules.has(name)) {
        const raw = String(value ?? '').trim();

        if (raw !== '') m.value = Number(raw);
      } else if (value !== undefined && value !== '') {
        m.value = value;
      } else if (name === 'notPast' || name === 'notFuture') {
        m.value = true;
      }

      if (message) m.message = message;

      return m;
    });

    return mapped.filter(v => String(v.name ?? '').trim() !== '');
  }

  private readDependencies(): Partial<FieldDefinitionModel['dependencies']> | undefined {
    const visibleRoot = this.dependenciesForm.get('visibleRoot') as FormGroup;
    const enableRoot = this.dependenciesForm.get('enableRoot') as FormGroup;

    const itemToCondition = (item: FormGroup): any => {
      const kind = String(item.get('kind')?.value ?? 'rule');

      if (kind === 'group') {
        const combinator = String(item.get('combinator')?.value ?? 'all');
        const notFlag = Boolean(item.get('not')?.value);
        const itemsArr = item.get('items') as FormArray;
        const children = itemsArr.controls
          .map(c => itemToCondition(c as FormGroup))
          .filter(Boolean);
        let cond: any = undefined;

        if (children.length === 1) cond = children[0];

        if (children.length > 1) cond = { [combinator]: children };

        if (notFlag && cond) cond = { not: cond };

        return cond;
      }

      const field = String(item.get('field')?.value ?? '').trim();
      const operator = String(item.get('operator')?.value ?? 'equals');
      const operand = item.get('operand')?.value;

      if (!field) return null;

      const base: any = { field };

      switch (operator) {
        case 'regex':
          base.regex = String(operand ?? '');
          break;
        case 'equals':
          base.equals = operand;
          break;
        case 'notEquals':
          base.notEquals = operand;
          break;
        case 'true':
          base.true = true;
          break;
        case 'false':
          base.false = true;
          break;
        case 'notEmpty':
          base.notEmpty = true;
          break;
        case 'valid':
          base.valid = true;
          break;
        default:
          base.equals = operand;
      }

      return base;
    };

    const rootToCondition = (root: FormGroup): any => {
      const combinator = String(root.get('combinator')?.value ?? 'all');
      const notFlag = Boolean(root.get('not')?.value);
      const itemsArr = root.get('items') as FormArray;
      const children = itemsArr.controls.map(c => itemToCondition(c as FormGroup)).filter(Boolean);
      let cond: any = undefined;

      if (children.length === 1) cond = children[0];

      if (children.length > 1) cond = { [combinator]: children };

      if (notFlag && cond) cond = { not: cond };

      return cond;
    };

    const visibleIf = rootToCondition(visibleRoot);
    const enableIf = rootToCondition(enableRoot);

    if (!visibleIf && !enableIf) return undefined;

    return { visibleIf, enableIf };
  }

  private readAutoFill(): FieldDefinitionModel['autoFill'] | undefined {
    const triggerField = String(this.autoFillForm.get('triggerField')?.value ?? '').trim();
    const api = String(this.autoFillForm.get('api')?.value ?? '').trim();
    const behavior = String(this.autoFillForm.get('behavior')?.value ?? '').trim() as
      | 'ask'
      | 'replace'
      | 'fillEmpty'
      | 'ask|replace|fillEmpty';

    if (!triggerField || !api) return undefined;

    const map: Record<string, string> = {};
    const mappingsArr = this.autoFillForm.get('mappings') as FormArray;

    if (mappingsArr && mappingsArr.length > 0) {
      mappingsArr.controls.forEach(c => {
        const g = c as FormGroup;
        const fieldName = String(g.get('fieldName')?.value ?? '').trim();
        const sourcePath = String(g.get('sourcePath')?.value ?? '').trim();

        if (fieldName && sourcePath) map[fieldName] = sourcePath;
      });
    }

    return { triggerField, api, behavior, map };
  }

  private clearFieldForms(): void {
    this.fieldForm.reset({
      type: 'string',
      widget: 'text',
      required: false,
      disabled: false,
      order: 1,
      tabIndex: 1,
      uiMask: '',
      uiHint: '',
      valuesText: '',
    });
    this.validationsFormArray.clear();
    const vRoot = this.dependenciesForm.get('visibleRoot') as FormGroup;
    const eRoot = this.dependenciesForm.get('enableRoot') as FormGroup;
    (vRoot.get('items') as FormArray).clear();
    (eRoot.get('items') as FormArray).clear();
    vRoot.patchValue({ combinator: 'all', not: false });
    eRoot.patchValue({ combinator: 'all', not: false });
    this.autoFillForm.reset({ behavior: 'ask|replace|fillEmpty' });
    const mappingsArr = this.autoFillForm.get('mappings') as FormArray;
    mappingsArr.clear();
  }

  addFieldSimple(): void {
    const name = String(this.newFieldForm.get('name')?.value ?? '').trim();
    const labelKey = String(this.newFieldForm.get('labelKey')?.value ?? '').trim();
    const selectedType = String(this.newFieldForm.get('type')?.value ?? 'string');
    const isColor = selectedType === 'color';
    const isEnum = selectedType === 'enum';
    const isAutocomplete = selectedType === 'autocomplete';
    const type = (
      isColor || isAutocomplete ? 'string' : selectedType
    ) as FieldDefinitionModel['type'];

    if (!name) return;

    const currentFields = this.fieldsList$.getValue();
    const nextOrder = this.helpers.nextOrder(currentFields);
    const nextTabIndex = this.helpers.nextTabIndex(currentFields);
    const widget = isColor
      ? 'color'
      : isAutocomplete
        ? 'autocomplete'
        : this.helpers.suggestWidget(type);
    const field = this.helpers.toFieldDefinition(
      {
        name,
        labelKey,
        type,
        widget,
        order: nextOrder,
        tabIndex: nextTabIndex,
        values: isEnum ? ['OPTION_1', 'OPTION_2'] : undefined,
      },
      { nextOrder, nextTabIndex },
    );
    const schema = this.buildSchemaWithNewField(field);
    const issues = this.validator.validate(schema).map(i => `${i.path}: ${i.message}`);

    if (issues.length > 0) {
      this.issues$.next(issues);

      return;
    }

    const current = this.state.currentSchema();

    if (!current) {
      this.state.setSchema(schema);
    } else {
      this.state.addField(field);
    }

    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);

    this.newFieldForm.reset({ name: '', labelKey: '', type: 'string' });
    this.issues$.next([]);
    this.buildDataSource();
    this.ref.markForCheck();
  }

  updateFieldProperties(fieldName: string, partial: Partial<FieldDefinitionModel>): void {
    this.state.updateField(fieldName, partial);
    const updated = this.state.currentSchema();

    if (updated) this.storage.saveDraft(updated);
  }

  updateMask(fieldName: string, maskText: string): void {
    const ui = maskText ? { mask: maskText } : undefined;
    this.updateFieldProperties(fieldName, { ui });
  }

  updateValues(fieldName: string, valuesText: string): void {
    const values = valuesText
      ? valuesText
          .split(',')
          .map(x => x.trim())
          .filter(x => x.length > 0)
      : [];
    this.updateFieldProperties(fieldName, { values });
  }

  toggleRow(fieldName: string): void {
    if (this.expandedRows.has(fieldName)) this.expandedRows.delete(fieldName);
    else this.expandedRows.add(fieldName);
  }

  addValidationToField(fieldName: string): void {
    const current = this.state.currentSchema();

    if (!current) return;

    const field = current.fields.find(f => f.name === fieldName);

    if (!field) return;

    const validations = [
      ...(field.validations ?? []),
      { name: '', value: '', message: '' } as ValidationDefinitionModel,
    ];
    this.updateFieldProperties(fieldName, { validations });
  }

  updateValidationOfField(
    fieldName: string,
    index: number,
    patch: Partial<ValidationDefinitionModel>,
  ): void {
    const current = this.state.currentSchema();

    if (!current) return;

    const field = current.fields.find(f => f.name === fieldName);

    if (!field) return;

    const list = [...(field.validations ?? [])];
    const item = { ...(list[index] ?? ({ name: '' } as ValidationDefinitionModel)), ...patch };
    list[index] = item;
    this.updateFieldProperties(fieldName, { validations: list });
  }

  removeValidationOfField(fieldName: string, index: number): void {
    const current = this.state.currentSchema();

    if (!current) return;

    const field = current.fields.find(f => f.name === fieldName);

    if (!field) return;

    const list = [...(field.validations ?? [])];
    list.splice(index, 1);
    this.updateFieldProperties(fieldName, { validations: list });
  }

  updateDependencies(fieldName: string, deps: Partial<FieldDefinitionModel['dependencies']>): void {
    this.updateFieldProperties(fieldName, {
      dependencies: deps as FieldDefinitionModel['dependencies'],
    });
  }

  updateAutoFill(fieldName: string, auto: FieldDefinitionModel['autoFill'] | undefined): void {
    this.updateFieldProperties(fieldName, { autoFill: auto });
  }

  openAdvancedModal(fieldName: string): void {
    this.editField(fieldName);
    const form = this.getInlineForm(fieldName);
    const currentName = String(form.get('name')?.value ?? fieldName);
    this.modalTitleName = currentName;
    this.modalOpen = true;
  }

  closeAdvancedModal(): void {
    this.modalOpen = false;
  }

  saveAdvancedModal(): void {
    this.updateField();
    this.modalOpen = false;
  }

  private setupInlineForms(fields: FieldDefinitionModel[]): void {
    const names = new Set(fields.map(f => f.name));
    Object.keys(this.inlineRowForms).forEach(n => {
      if (!names.has(n)) delete this.inlineRowForms[n];
    });
    fields.forEach(f => {
      const existing = this.inlineRowForms[f.name];

      if (!existing) {
        const fg = this.fb.group({
          name: [f.name],
          labelKey: [f.labelKey ?? ''],
          required: [f.required ?? false],
          disabled: [f.disabled ?? false],
          invisible: [Boolean(f.invisible)],
        });
        this.inlineRowForms[f.name] = fg;
        this.bindInlineForm(f.name, fg);
      } else {
        existing.patchValue(
          {
            name: f.name,
            labelKey: f.labelKey ?? '',
            required: f.required ?? false,
            disabled: f.disabled ?? false,
            invisible: Boolean(f.invisible),
          },
          { emitEvent: false },
        );
      }
    });
  }

  getInlineForm(fieldName: string): FormGroup {
    const fg = this.inlineRowForms[fieldName];

    if (fg) return fg;

    const current = this.state.currentSchema();
    const field = current?.fields.find(x => x.name === fieldName);
    const created = this.fb.group({
      name: [field?.name ?? fieldName],
      labelKey: [field?.labelKey ?? ''],
      required: [field?.required ?? false],
      disabled: [field?.disabled ?? false],
      invisible: [Boolean(field?.invisible)],
    });
    this.inlineRowForms[fieldName] = created;
    this.bindInlineForm(fieldName, created);

    return created;
  }

  private bindInlineForm(fieldName: string, fg: FormGroup): void {
    // renomear será feito no blur via commitInlineName; evitar re-render a cada tecla
    fg.get('labelKey')?.valueChanges.subscribe(v => {
      const value = String(v ?? '').trim();
      const currentName = this.getInlineCurrentName(fieldName, fg);
      this.updateFieldProperties(currentName, { labelKey: value });
    });
    fg.get('required')?.valueChanges.subscribe(v => {
      const currentName = this.getInlineCurrentName(fieldName, fg);
      this.updateFieldProperties(currentName, { required: Boolean(v) });
    });
    fg.get('disabled')?.valueChanges.subscribe(v => {
      const currentName = this.getInlineCurrentName(fieldName, fg);
      this.updateFieldProperties(currentName, { disabled: Boolean(v) });
    });
    fg.get('invisible')?.valueChanges.subscribe(v => {
      const currentName = this.getInlineCurrentName(fieldName, fg);
      this.updateFieldProperties(currentName, { invisible: Boolean(v) });
    });
  }

  commitInlineName(originalName: string): void {
    const fg = this.getInlineForm(originalName);
    const newName = String(fg.get('name')?.value ?? '').trim();
    const current = this.state.currentSchema();

    if (!current) return;

    if (!newName || newName === originalName) return;

    const exists = current.fields.some(f => f.name === newName);

    if (exists) {
      fg.patchValue({ name: originalName }, { emitEvent: false });

      return;
    }

    this.state.renameField(originalName, newName);
    this.inlineRowForms[newName] = fg;
    delete this.inlineRowForms[originalName];
    this.buildDataSource();
    this.ref.markForCheck();
  }

  private getInlineCurrentName(originalName: string, fg: FormGroup): string {
    const value = String(fg.get('name')?.value ?? '').trim();

    return value || originalName;
  }
}
