import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: '[fts-field-templates-modal]',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './field-templates-modal.html',
})
export class FieldTemplatesModal {
  @Input() open = false;
  @Input() options: { label: string; value: string }[] = [];
  @Output() choose = new EventEmitter<string>();
  @Output() closed = new EventEmitter<void>();

  onClose(): void {
    this.closed.emit();
  }

  onAdd(value: string): void {
    this.choose.emit(value);
    this.closed.emit();
  }
}
