import { Injectable } from '@angular/core';
import { FormSchemaModel } from '../../models/form-schema.model';
import { FieldDefinitionModel } from '../../models/field-definition.model';
import { ValidationDefinitionModel } from '../../models/validation-definition.model';

export interface SchemaValidationIssue {
  path: string;
  message: string;
}

interface DepCond {
  not?: DepCond;
  all?: DepCond[];
  any?: DepCond[];
  field?: string;
}

@Injectable({ providedIn: 'root' })
export class SchemaValidatorService {
  validate(schema: FormSchemaModel): SchemaValidationIssue[] {
    const issues: SchemaValidationIssue[] = [];
    const names = new Set<string>();

    schema.fields.forEach((f, i) => {
      if (names.has(f.name))
        issues.push({ path: `fields[${i}].name`, message: 'Nome de campo duplicado' });

      names.add(f.name);

      if (!this.isWidgetCompatible(f))
        issues.push({ path: `fields[${i}].widget`, message: 'Widget incompatível com type' });

      if (f.type === 'enum' && (!f.values || f.values.length === 0) && !f.ui?.dataSource)
        issues.push({ path: `fields[${i}].values`, message: 'Enum sem valores' });

      const vList = (f.validations ?? []).filter(v => String(v.name ?? '').trim().length > 0);
      const vIssues = this.validateValidations(vList, f);
      vIssues.forEach(m => issues.push({ path: `fields[${i}].validations`, message: m }));

      if (f.ui?.mask && !this.maskAllowedFor(f))
        issues.push({ path: `fields[${i}].ui.mask`, message: 'Máscara não aplicável' });

      if (f.dependencies?.visibleIf) {
        const paths = this.collectMissingDependencyPaths(
          f.dependencies.visibleIf,
          schema,
          `fields[${i}].dependencies.visibleIf`,
        );
        paths.forEach(p =>
          issues.push({ path: p, message: 'Dependência refere campo inexistente' }),
        );
      }

      if (f.dependencies?.enableIf) {
        const paths2 = this.collectMissingDependencyPaths(
          f.dependencies.enableIf,
          schema,
          `fields[${i}].dependencies.enableIf`,
        );
        paths2.forEach(p =>
          issues.push({ path: p, message: 'Dependência refere campo inexistente' }),
        );
      }

      if (f.autoFill) {
        const containsVar = f.autoFill.api.includes(`{{${f.autoFill.triggerField}}}`);

        if (!containsVar)
          issues.push({
            path: `fields[${i}].autoFill.api`,
            message: 'AutoFill API sem interpolação do triggerField',
          });

        const mapValid = Object.keys(f.autoFill.map).every(k => this.fieldExists(schema, k));

        if (!mapValid)
          issues.push({ path: `fields[${i}].autoFill.map`, message: 'AutoFill map inválido' });
      }
    });

    return issues;
  }

  isValid(schema: FormSchemaModel): boolean {
    return this.validate(schema).length === 0;
  }

  private isWidgetCompatible(field: FieldDefinitionModel): boolean {
    switch (field.type) {
      case 'string':
        if (['text', 'textarea', 'autocomplete', 'color'].includes(field.widget)) return true;

        if (['select', 'multiselect'].includes(field.widget) && !!field.ui?.dataSource) return true;

        return false;
      case 'number':
        return ['number', 'text'].includes(field.widget);
      case 'boolean':
        return ['checkbox', 'confirmDialog'].includes(field.widget);
      case 'enum':
        return ['select', 'multiselect'].includes(field.widget);
      case 'date':
        return ['datepicker', 'calendar'].includes(field.widget);
      case 'file':
        return ['fileupload'].includes(field.widget);
      default:
        return false;
    }
  }

  private validateValidations(
    validations: ValidationDefinitionModel[],
    field: FieldDefinitionModel,
  ): string[] {
    const messages: string[] = [];
    validations.forEach(v => {
      if (!v.name) messages.push('Validação sem nome');

      if (
        ['min', 'max', 'minLength', 'maxLength', 'maxSizeMB', 'maxFiles'].includes(v.name) &&
        v.value === undefined
      )
        messages.push('Validação requer valor');

      if (v.name === 'pattern' && typeof v.value !== 'string') messages.push('Pattern inválido');

      if (['fileTypes'].includes(v.name) && !Array.isArray(v.value))
        messages.push('fileTypes inválido');

      if (
        field.type === 'date' &&
        ['notPast', 'notFuture', 'maxDiffMonths'].includes(v.name) === false &&
        ['min', 'max'].includes(v.name)
      )
        messages.push('Validação numérica incompatível com data');

      if (field.type === 'number' && v.name === 'pattern')
        messages.push('Pattern incompatível com number');

      if (
        field.type === 'file' &&
        !['fileTypes', 'maxSizeMB', 'maxFiles', 'required'].includes(v.name)
      )
        messages.push('Validação incompatível com file');
    });

    return messages;
  }

  private maskAllowedFor(field: FieldDefinitionModel): boolean {
    if (!field.ui?.mask) return true;

    return field.widget === 'text' || field.widget === 'number';
  }

  private collectMissingDependencyPaths(
    cond: DepCond | null | undefined,
    schema: FormSchemaModel,
    prefix: string,
  ): string[] {
    if (!cond) return [];

    if (cond.not) return this.collectMissingDependencyPaths(cond.not, schema, `${prefix}.not`);

    if (Array.isArray(cond.all)) {
      const res: string[] = [];
      cond.all.forEach((c, idx) => {
        res.push(...this.collectMissingDependencyPaths(c, schema, `${prefix}.all[${idx}]`));
      });

      return res;
    }

    if (Array.isArray(cond.any)) {
      const res: string[] = [];
      cond.any.forEach((c, idx) => {
        res.push(...this.collectMissingDependencyPaths(c, schema, `${prefix}.any[${idx}]`));
      });

      return res;
    }

    const name = cond.field;

    if (typeof name !== 'string' || !this.fieldExists(schema, name)) return [`${prefix}.field`];

    return [];
  }

  private fieldExists(schema: FormSchemaModel, name: string): boolean {
    return schema.fields.some(f => f.name === name);
  }

  private findPatternValue(name: string, schema: FormSchemaModel): string | null {
    const f = schema.fields.find(x => x.name === name);
    const v = f?.validations?.find(x => x.name === 'pattern');

    return v && typeof v.value === 'string' ? v.value : null;
  }
}
