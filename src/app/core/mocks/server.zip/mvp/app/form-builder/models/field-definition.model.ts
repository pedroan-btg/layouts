import { ValidationDefinitionModel } from './validation-definition.model';

export interface FieldUiConfigModel {
  mask?: string;
  tabIndex?: number;
  dataSource?: string;
  confirmationText?: string;
  bindKey?: string;
  bindLabel?: string;
  prefix?: string;
  suffix?: string;
  placeholder?: string;
  tooltipKey?: string;
  label?: string;
  hint?: string;
}

export interface SimpleConditionModel {
  field: string;
  regex?: string;
  equals?: unknown;
  value?: unknown;
  notEquals?: unknown;
  true?: boolean;
  false?: boolean;
  notEmpty?: boolean;
  valid?: boolean;
}

export interface ConditionGroupModel {
  all?: ConditionModel[];
  any?: ConditionModel[];
  not?: ConditionModel;
}

export type ConditionModel = SimpleConditionModel | ConditionGroupModel;

export interface AutoFillConfigModel {
  triggerField: string;
  api: string;
  behavior: 'ask' | 'replace' | 'fillEmpty' | 'ask|replace|fillEmpty';
  debounceMs?: number;
  map: Record<string, string>;
}

export interface FieldDefinitionModel {
  name: string;
  labelKey: string;
  type: 'string' | 'number' | 'boolean' | 'enum' | 'date' | 'file';
  widget:
    | 'text'
    | 'number'
    | 'textarea'
    | 'checkbox'
    | 'select'
    | 'multiselect'
    | 'datepicker'
    | 'calendar'
    | 'fileupload'
    | 'autocomplete'
    | 'color'
    | 'confirmDialog';
  order: number;
  tabIndex: number;
  required?: boolean;
  disabled?: boolean;
  invisible?: boolean;
  values?: string[];
  validations?: ValidationDefinitionModel[];
  ui?: FieldUiConfigModel;
  dependencies?: {
    visibleIf?: ConditionModel;
    enableIf?: ConditionModel;
  };
  autoFill?: AutoFillConfigModel;
}
