import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormBuilderStateService } from '../services/form-builder-state.service';
import { DynamicFormComponent } from '../../dynamic-form/dynamic-form.component';
import {
  DynamicFormSchema,
  DynamicField,
  ValidationRule,
  SubmitUi,
} from '../../dynamic-form/types';

@Component({
  selector: '[fts-form-preview]',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DynamicFormComponent],
  templateUrl: './form-preview.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormPreview implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly state = inject(FormBuilderStateService);

  form: FormGroup = this.fb.group({});
  schema: DynamicFormSchema | null = null;

  ngOnInit(): void {
    this.state.schema$.subscribe(schemaFromState => {
      if (!schemaFromState) {
        this.schema = null;

        return;
      }

      const confirmationField = schemaFromState.fields.find(
        fieldDefinition => fieldDefinition.widget === 'confirmDialog',
      );
      const fields: DynamicField[] = schemaFromState.fields
        .filter(fieldDefinition => fieldDefinition.widget !== 'confirmDialog')
        .map(fieldDefinition => ({
          name: fieldDefinition.name,
          labelKey: fieldDefinition.labelKey,
          widget: fieldDefinition.widget as unknown as DynamicField['widget'],
          order: fieldDefinition.order,
          tabIndex: fieldDefinition.tabIndex,
          required: fieldDefinition.required,
          disabled: fieldDefinition.disabled,
          values: fieldDefinition.values,
          validations: (fieldDefinition.validations ?? []) as unknown as ValidationRule[],
          dependencies: fieldDefinition.dependencies as unknown as DynamicField['dependencies'],
          autoFill: fieldDefinition.autoFill as unknown as DynamicField['autoFill'],
          ui: fieldDefinition.ui as unknown as DynamicField['ui'],
        }));
      const submit: SubmitUi | undefined = confirmationField
        ? { confirm: true, confirmationText: confirmationField.ui?.confirmationText }
        : undefined;
      this.schema = submit ? { fields, submit } : { fields };
    });
  }

  onSubmitted(): void {
    return;
  }
}
