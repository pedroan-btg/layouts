import { Injectable } from '@angular/core';
import { FieldDefinitionModel, FieldUiConfigModel } from '../../models/field-definition.model';
import { ValidationDefinitionModel } from '../../models/validation-definition.model';

@Injectable({ providedIn: 'root' })
export class SchemaHelpersService {
  toFieldDefinition(
    input: Partial<FieldDefinitionModel>,
    defaults: { nextOrder: number; nextTabIndex: number },
  ): FieldDefinitionModel {
    const name = String(input.name ?? '').trim();
    const labelKey = String(
      input.labelKey ?? `FIELDS.${name.replace(/([A-Z])/g, '_$1').toUpperCase()}`,
    );
    const type = input.type ?? 'string';
    const widget = input.widget ?? this.suggestWidget(type);
    const order = input.order ?? defaults.nextOrder;
    const tabIndex = input.tabIndex ?? defaults.nextTabIndex;
    const required = input.required ?? false;
    const disabled = input.disabled ?? false;
    const values = input.values ?? [];
    const validations = (input.validations ?? []).map(v => ({
      name: v.name,
      value: v.value,
      message: v.message,
    })) as ValidationDefinitionModel[];
    const ui = this.normalizeUi(input.ui);
    const dependencies = input.dependencies ?? undefined;
    const autoFill = input.autoFill ?? undefined;

    return {
      name,
      labelKey,
      type,
      widget,
      order,
      tabIndex,
      required,
      disabled,
      values,
      validations,
      ui,
      dependencies,
      autoFill,
    };
  }

  suggestWidget(type: FieldDefinitionModel['type']): FieldDefinitionModel['widget'] {
    switch (type) {
      case 'string':
        return 'text';
      case 'number':
        return 'number';
      case 'boolean':
        return 'checkbox';
      case 'enum':
        return 'select';
      case 'date':
        return 'datepicker';
      case 'file':
        return 'fileupload';
      default:
        return 'text';
    }
  }

  normalizeUi(ui: Partial<FieldUiConfigModel> | undefined): FieldUiConfigModel | undefined {
    if (!ui) return undefined;

    const merged: FieldUiConfigModel = {
      mask: ui.mask,
      tabIndex: ui.tabIndex,
      dataSource: ui.dataSource,
      confirmationText: ui.confirmationText,
      bindKey: ui.bindKey,
      bindLabel: ui.bindLabel,
      prefix: ui.prefix,
      suffix: ui.suffix,
      placeholder: ui.placeholder,
      tooltipKey: ui.tooltipKey,
      label: ui.label,
      hint: ui.hint,
    };

    return merged;
  }

  nextOrder(existing: FieldDefinitionModel[]): number {
    const max = existing.reduce((m, f) => Math.max(m, f.order ?? 0), 0);

    return max + 1;
  }

  nextTabIndex(existing: FieldDefinitionModel[]): number {
    const max = existing.reduce((m, f) => Math.max(m, f.tabIndex ?? 0), 0);

    return max + 1;
  }
}
