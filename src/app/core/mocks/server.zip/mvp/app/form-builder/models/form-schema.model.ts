import { FieldDefinitionModel } from './field-definition.model';

export interface FormSchemaModel {
  type: string;
  version: number;
  description: string;
  fields: FieldDefinitionModel[];
}
