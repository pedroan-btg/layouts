export const environment = {
  environment: 'ENVIRONMENT',
  collateralApi: 'FTS_COLLATERAL',
  onboardingApi: 'FTS_ONBOARDING',
  onboardingApiKey: 'FTS_ONBOARDING_KEY',
};
