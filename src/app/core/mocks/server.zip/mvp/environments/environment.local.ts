export const environment = {
  environment: 'development',
  collateralApi: 'http://localhost:4300',
  onboardingApi: 'https://onboarding-api-uat.pactual.net',
  onboardingApiKey: '5b0c43ffe3de0c45839d482fe85dfeb1ef567dc5df68b708bc37f59a02db2605',
};
