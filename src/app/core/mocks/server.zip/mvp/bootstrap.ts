import { bootstrapApplication } from '@angular/platform-browser';
import { registerLocaleData } from '@angular/common';
import { enableProdMode } from '@angular/core';
import localePt from '@angular/common/locales/pt';
import localeEs from '@angular/common/locales/es';
import 'bootstrap';

import { appConfig } from './app/app.config';
import { App } from './app/app';

registerLocaleData(localeEs);
registerLocaleData(localePt);
enableProdMode();

bootstrapApplication(App, appConfig).catch(err => new Error(err));
