import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { delay, defer, from, map, switchMap } from 'rxjs';

interface Draft {
  id: number;
  userId: string;
  formId?: number | null;
  type: string;
  publishedVersionExists: boolean;
  name?: string;
  changes?: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

const dbName = 'collateral-idb';

const openDb = (): Promise<IDBDatabase> =>
  new Promise((resolve, reject) => {
    const reqOpen = indexedDB.open(dbName);
    reqOpen.onupgradeneeded = () => {
      const db = reqOpen.result;

      if (!db.objectStoreNames.contains('drafts')) {
        const store = db.createObjectStore('drafts', { keyPath: 'id' });
        store.createIndex('userId', 'userId', { unique: false });
        store.createIndex('formId', 'formId', { unique: false });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('schemas')) {
        const store = db.createObjectStore('schemas', { keyPath: 'id' });
        store.createIndex('type', 'type', { unique: true });
      }

      if (!db.objectStoreNames.contains('forms')) {
        const store = db.createObjectStore('forms', { keyPath: 'id' });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('name', 'name', { unique: false });
        store.createIndex('version', 'version', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('seed')) {
        db.createObjectStore('seed', { keyPath: 'key' });
      }
    };
    reqOpen.onerror = () => reject(reqOpen.error);
    reqOpen.onsuccess = () => resolve(reqOpen.result);
  });

const getAllDrafts = (db: IDBDatabase): Promise<Draft[]> =>
  new Promise((resolve, reject) => {
    try {
      const tx = db.transaction('drafts', 'readonly');
      const req = tx.objectStore('drafts').getAll();
      req.onsuccess = () => resolve((req.result ?? []) as Draft[]);
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e as any);
    }
  });

const putDraft = (db: IDBDatabase, draft: Draft): Promise<Draft> =>
  new Promise((resolve, reject) => {
    try {
      const tx = db.transaction('drafts', 'readwrite');
      const req = tx.objectStore('drafts').put(draft);
      req.onsuccess = () => resolve(draft);
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e as any);
    }
  });

const deleteDraft = (db: IDBDatabase, id: number): Promise<void> =>
  new Promise((resolve, reject) => {
    try {
      const tx = db.transaction('drafts', 'readwrite');
      const req = tx.objectStore('drafts').delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e as any);
    }
  });

export const handleDraftsMock = (req: any, next: any) => {
  if (!(globalThis as any).indexedDB) {
    return next(req);
  }

  if (
    (req.method === 'GET' && (req as any).urlWithParams?.includes('/api/drafts/pending')) ||
    (req.method === 'GET' && req.url.includes('/api/drafts/pending'))
  ) {
    let userId: string | null = null;
    try {
      const fullUrl = (req as any).urlWithParams ?? req.url;
      const url = new URL(fullUrl, 'http://localhost');
      userId = url.searchParams.get('userId');
    } catch {}

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(getAllDrafts(db)).pipe(map(arr => ({ db, arr })))),
      map(({ arr }) => (userId ? arr.filter(d => d.userId === userId) : arr)),
      map(drafts => new HttpResponse({ status: 200, body: { statusCode: 200, data: { drafts } } })),
      delay(200),
    );
  }

  if (req.method === 'POST' && req.url.endsWith('/api/drafts')) {
    const payload = (req.body ?? null) as Partial<Draft> | null;

    if (
      !payload ||
      !payload.userId ||
      !payload.type ||
      typeof payload.publishedVersionExists !== 'boolean'
    ) {
      const bad = { statusCode: 400, errors: ['Invalid draft payload'] } as const;

      return defer(() => from(Promise.resolve(new HttpResponse({ status: 400, body: bad })))).pipe(
        delay(150),
      );
    }

    const now = new Date().toISOString();

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(getAllDrafts(db)).pipe(
          switchMap(all => {
            const userDrafts = all.filter(d => d.userId === payload.userId);
            const isPublished = !!payload.publishedVersionExists;
            const formId = payload.formId ?? null;
            const incomingId = Number((payload as any).id ?? NaN);

            if (isPublished) {
              const existing = userDrafts.find(
                d => d.formId === formId && d.publishedVersionExists,
              );
              const id = Number.isFinite(incomingId)
                ? incomingId
                : (existing?.id ?? Date.now() + Math.floor(Math.random() * 1000));
              const draft: Draft = {
                id,
                userId: payload.userId!,
                formId,
                type: payload.type!,
                publishedVersionExists: true,
                name: payload.name,
                changes: payload.changes ?? {},
                createdAt: existing?.createdAt ?? now,
                updatedAt: now,
              };

              return from(putDraft(db, draft)).pipe(
                map(
                  d =>
                    new HttpResponse({
                      status: existing ? 200 : 201,
                      body: { statusCode: existing ? 200 : 201, data: { draft: d } },
                    }),
                ),
              );
            } else {
              const blocking = userDrafts.find(d => !d.publishedVersionExists);

              if (blocking && (!Number.isFinite(incomingId) || incomingId !== blocking.id)) {
                const bad = {
                  statusCode: 400,
                  errors: ['Only one unpublished draft allowed for this user'],
                } as const;

                return from(Promise.resolve(new HttpResponse({ status: 400, body: bad })));
              }

              const id = Number.isFinite(incomingId)
                ? incomingId
                : (blocking?.id ?? Date.now() + Math.floor(Math.random() * 1000));
              const draft: Draft = {
                id,
                userId: payload.userId!,
                formId: null,
                type: payload.type!,
                publishedVersionExists: false,
                name: payload.name,
                changes: payload.changes ?? {},
                createdAt: blocking?.createdAt ?? now,
                updatedAt: now,
              };

              return from(putDraft(db, draft)).pipe(
                map(
                  d =>
                    new HttpResponse({
                      status: blocking ? 200 : 201,
                      body: { statusCode: blocking ? 200 : 201, data: { draft: d } },
                    }),
                ),
              );
            }
          }),
        ),
      ),
      delay(200),
    );
  }

  if (req.method === 'DELETE' && req.url.includes('/api/drafts/')) {
    const idStr = req.url.split('/api/drafts/')[1]?.split('?')[0] ?? '';
    const id = Number(idStr);

    if (!Number.isFinite(id)) {
      const bad = { statusCode: 400, errors: ['Invalid draft id'] } as const;

      return defer(() => from(Promise.resolve(new HttpResponse({ status: 400, body: bad })))).pipe(
        delay(150),
      );
    }

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(deleteDraft(db, id))),
      map(() => new HttpResponse({ status: 204 })),
      delay(150),
    );
  }

  if (req.method === 'POST' && req.url.endsWith('/api/forms/revert')) {
    const body = req.body as any;
    const draftId = Number(body?.draftId ?? NaN);

    if (!Number.isFinite(draftId)) {
      const bad = { statusCode: 400, errors: ['Invalid draftId'] } as const;

      return defer(() => from(Promise.resolve(new HttpResponse({ status: 400, body: bad })))).pipe(
        delay(150),
      );
    }

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(deleteDraft(db, draftId))),
      map(() => new HttpResponse({ status: 200, body: { statusCode: 200 } })),
      delay(150),
    );
  }

  return next(req);
};

export const draftsMockInterceptor: HttpInterceptorFn = (req, next) => handleDraftsMock(req, next);
