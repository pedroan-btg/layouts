import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { defer, from, map, switchMap, delay } from 'rxjs';
import seedData from '../json/collateral-config.json';

interface NamedRow {
  id: string;
  name: string;
}
interface Vinculo {
  id: string;
  mercadoId: string;
  tipoGarantiaId: string;
  subtipoGarantiaId: string;
  ativoId: string;
  custodiaBTG: boolean | null;
  formType: string;
  formId: number;
  ordemPrioridade: number;
}

export const collateralMockInterceptor: HttpInterceptorFn = (req, next) => {
  const dbName = 'collateral-idb';

  const openDb = (): Promise<IDBDatabase> =>
    new Promise((resolve, reject) => {
      const r = indexedDB.open(dbName);
      r.onupgradeneeded = () => {
        const db = r.result;

        if (!db.objectStoreNames.contains('collateralMarkets')) {
          db.createObjectStore('collateralMarkets', { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains('collateralTypes')) {
          const s = db.createObjectStore('collateralTypes', { keyPath: 'id' });
          s.createIndex('marketId', 'marketId', { unique: false });
        }

        if (!db.objectStoreNames.contains('collateralSubtypes')) {
          const s = db.createObjectStore('collateralSubtypes', { keyPath: 'id' });
          s.createIndex('marketId', 'marketId', { unique: false });
        }

        if (!db.objectStoreNames.contains('collateralAssets')) {
          const s = db.createObjectStore('collateralAssets', { keyPath: 'id' });
          s.createIndex('marketId', 'marketId', { unique: false });
        }

        if (!db.objectStoreNames.contains('financialAssets')) {
          const s = db.createObjectStore('financialAssets', { keyPath: 'id' });
          s.createIndex('composite', 'composite', { unique: true });
        }

        if (!db.objectStoreNames.contains('seed')) {
          db.createObjectStore('seed', { keyPath: 'key' });
        }
      };
      r.onerror = () => reject(r.error);
      r.onsuccess = () => resolve(r.result);
    });

  const slug = (s: string): string =>
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

  const seedIfNeeded = (db: IDBDatabase): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(
          [
            'seed',
            'collateralMarkets',
            'collateralTypes',
            'collateralSubtypes',
            'collateralAssets',
          ],
          'readwrite',
        );
        const seedStore = tx.objectStore('seed');
        const get = seedStore.get('collateralSeed-v2');
        get.onsuccess = () => {
          if (get.result) {
            resolve();

            return;
          }

          const mStore = tx.objectStore('collateralMarkets');
          const tStore = tx.objectStore('collateralTypes');
          const stStore = tx.objectStore('collateralSubtypes');
          const aStore = tx.objectStore('collateralAssets');

          let pending = 0;

          seedData.markets.forEach(m => {
            pending += 1;
            const put = mStore.put(m);
            put.onsuccess = () => {
              pending -= 1;

              if (pending === 0) done();
            };
            put.onerror = () => reject(put.error);
          });

          const addArr = (
            store: IDBObjectStore,
            marketId: string,
            arr: string[],
            prefix: string,
          ) => {
            arr.forEach(v => {
              const id = `${marketId}-${prefix}-${slug(v)}`;
              pending += 1;
              const put = store.put({ id, marketId, name: v });
              put.onsuccess = () => {
                pending -= 1;

                if (pending === 0) done();
              };
              put.onerror = () => reject(put.error);
            });
          };

          Object.entries(seedData.types).forEach(([marketId, arr]) =>
            addArr(tStore, marketId, arr as string[], 'type'),
          );
          Object.entries(seedData.subtypes).forEach(([marketId, arr]) =>
            addArr(stStore, marketId, arr as string[], 'subtype'),
          );
          Object.entries(seedData.assets).forEach(([marketId, arr]) =>
            addArr(aStore, marketId, arr as string[], 'asset'),
          );

          const done = () => {
            seedStore.put({ key: 'collateralSeed-v2', value: 1 });
            resolve();
          };
        };
        get.onerror = () => reject(get.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const zeroFinancialAssetsIfNeeded = (db: IDBDatabase): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(['seed', 'financialAssets'], 'readwrite');
        const seedStore = tx.objectStore('seed');
        const finStore = tx.objectStore('financialAssets');
        const get = seedStore.get('financialAssetsZeroed');
        get.onsuccess = () => {
          if (get.result) {
            resolve();
            return;
          }

          const clearReq = finStore.clear();
          clearReq.onsuccess = () => {
            seedStore.put({ key: 'financialAssetsZeroed', value: 1 });
            resolve();
          };
          clearReq.onerror = () => reject(clearReq.error);
        };
        get.onerror = () => reject(get.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const listByStore = (
    db: IDBDatabase,
    storeName: string,
    marketId?: string,
  ): Promise<NamedRow[]> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(storeName, 'readonly');
        const store = tx.objectStore(storeName);
        const idx = marketId ? store.index('marketId') : null;
        const req = idx ? idx.openCursor(IDBKeyRange.only(marketId)) : store.openCursor();
        const out: NamedRow[] = [];
        req.onsuccess = () => {
          const cursor = req.result as IDBCursorWithValue | null;

          if (cursor) {
            const v = cursor.value as any;
            out.push({ id: v.id, name: v.name });
            cursor.continue();
          } else resolve(out);
        };
        req.onerror = () => reject(req.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const listFinancialAssets = (
    db: IDBDatabase,
    page: number,
    limit: number,
    marketId?: string,
  ): Promise<{ rows: Vinculo[]; total: number }> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('financialAssets', 'readonly');
        const store = tx.objectStore('financialAssets');
        const req = store.getAll();
        req.onsuccess = () => {
          const all = (req.result ?? []) as Vinculo[];
          const filtered = marketId ? all.filter(v => v.mercadoId === marketId) : all;
          const start = page * limit;
          const end = start + limit;
          const rows = filtered.slice(start, end);
          const total = filtered.length;
          resolve({ rows, total });
        };
        req.onerror = () => reject(req.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const putFinancialAsset = (db: IDBDatabase, v: Vinculo): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('financialAssets', 'readwrite');
        const store = tx.objectStore('financialAssets');
        const cust = v.custodiaBTG === true ? '1' : v.custodiaBTG === false ? '0' : '2';
        const composite = [
          v.mercadoId,
          v.tipoGarantiaId,
          v.subtipoGarantiaId,
          v.ativoId,
          cust,
        ].join('|');
        const id = composite;
        const put = store.put({ ...v, id, composite });
        put.onsuccess = () => resolve();
        put.onerror = () => reject(put.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const deleteFinancialAsset = (
    db: IDBDatabase,
    mercadoId: string,
    tipoGarantiaId: string,
    subtipoGarantiaId: string,
    ativoId: string,
    custodiaBTG: string,
  ): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('financialAssets', 'readwrite');
        const store = tx.objectStore('financialAssets');
        const cust = custodiaBTG === 'true' ? '1' : custodiaBTG === 'false' ? '0' : '2';
        const composite = [mercadoId, tipoGarantiaId, subtipoGarantiaId, ativoId, cust].join('|');
        const del = store.delete(composite);
        del.onsuccess = () => resolve();
        del.onerror = () => reject(del.error);
      } catch (e) {
        reject(e as any);
      }
    });

  if (req.method === 'GET' && req.url.endsWith('/api/collateralmarkets')) {
    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(seedIfNeeded(db)).pipe(switchMap(() => from(listByStore(db, 'collateralMarkets')))),
      ),
      map(rows => ({ statusCode: 200, data: { rows } })),
      map(body => new HttpResponse({ status: 200, body })),
      delay(150),
    );
  }

  if (req.method === 'GET' && req.url.includes('/api/collateraltypes')) {
    const full = (req as any).urlWithParams ?? req.url;
    const u = new URL(full, 'http://localhost');
    const m = String(u.searchParams.get('marketId') ?? '');

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(seedIfNeeded(db)).pipe(switchMap(() => from(listByStore(db, 'collateralTypes', m)))),
      ),
      map(rows => ({ statusCode: 200, data: { rows } })),
      map(body => new HttpResponse({ status: 200, body })),
      delay(150),
    );
  }

  if (req.method === 'GET' && req.url.includes('/api/collateralsubtypes')) {
    const full = (req as any).urlWithParams ?? req.url;
    const u = new URL(full, 'http://localhost');
    const m = String(u.searchParams.get('marketId') ?? '');

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(seedIfNeeded(db)).pipe(
          switchMap(() => from(listByStore(db, 'collateralSubtypes', m))),
        ),
      ),
      map(rows => ({ statusCode: 200, data: { rows } })),
      map(body => new HttpResponse({ status: 200, body })),
      delay(150),
    );
  }

  if (req.method === 'GET' && req.url.includes('/api/collateralassets')) {
    const full = (req as any).urlWithParams ?? req.url;
    const u = new URL(full, 'http://localhost');
    const m = String(u.searchParams.get('marketId') ?? '');

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(seedIfNeeded(db)).pipe(switchMap(() => from(listByStore(db, 'collateralAssets', m)))),
      ),
      map(rows => ({ statusCode: 200, data: { rows } })),
      map(body => new HttpResponse({ status: 200, body })),
      delay(150),
    );
  }

  if (req.method === 'GET' && req.url.includes('/api/financialasset')) {
    const full = (req as any).urlWithParams ?? req.url;
    const u = new URL(full, 'http://localhost');
    const page = Number(u.searchParams.get('page') ?? '0');
    const limit = Number(u.searchParams.get('limit') ?? '12');
    const marketId = String(u.searchParams.get('marketId') ?? '');

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(zeroFinancialAssetsIfNeeded(db)).pipe(
          switchMap(() => from(listFinancialAssets(db, page, limit, marketId || undefined))),
        ),
      ),
      map(({ rows, total }) => ({ statusCode: 200, data: { rows, total } })),
      map(body => new HttpResponse({ status: 200, body })),
      delay(150),
    );
  }

  if (req.method === 'POST' && req.url.endsWith('/api/financialasset')) {
    const v = (req.body ?? {}) as Vinculo;

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(putFinancialAsset(db, v))),
      map(() => new HttpResponse({ status: 201, body: { statusCode: 201 } })),
      delay(150),
    );
  }

  if (req.method === 'DELETE' && req.url.includes('/api/financialasset')) {
    const full = (req as any).urlWithParams ?? req.url;
    const u = new URL(full, 'http://localhost');
    const mercadoId = String(u.searchParams.get('mercadoId') ?? '');
    const tipoGarantiaId = String(u.searchParams.get('tipoGarantiaId') ?? '');
    const subtipoGarantiaId = String(u.searchParams.get('subtipoGarantiaId') ?? '');
    const ativoId = String(u.searchParams.get('ativoId') ?? '');
    const custodiaBTG = String(u.searchParams.get('custodiaBTG') ?? 'false');

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        from(
          deleteFinancialAsset(
            db,
            mercadoId,
            tipoGarantiaId,
            subtipoGarantiaId,
            ativoId,
            custodiaBTG,
          ),
        ),
      ),
      map(() => new HttpResponse({ status: 204 })),
      delay(150),
    );
  }

  return next(req);
};
