import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';

const models = [
  { id: 'sprinter-250', label: 'Sprinter 250' },
  { id: 'crafter-max', label: 'Crafter Max' },
  { id: 'ducato-vip', label: 'Ducato VIP' },
  { id: 'transit-custom', label: 'Transit Custom' },
  { id: 'daily-35c', label: 'Daily 35C' },
  { id: 'master-van', label: 'Master Van' },
];

export const modelsMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/models/motorhome')) {
    let q = '';
    try {
      const url = new URL(req.url, 'http://localhost');
      q = (url.searchParams.get('q') || '').toLowerCase();
    } catch {
      // ignore parse errors; fall back to full list
    }

    const body = q ? models.filter(m => m.label.toLowerCase().includes(q)) : models;

    return of(
      new HttpResponse({
        status: 200,
        body,
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
