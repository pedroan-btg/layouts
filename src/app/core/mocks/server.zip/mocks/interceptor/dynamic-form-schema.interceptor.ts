import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { delay, defer, from, map, switchMap } from 'rxjs';
import motorHome from '../json/motor-home.json';
import imovel from '../json/imovel.json';
import veiculo from '../json/veiculo.json';
import aeronave from '../json/aeronave.json';
import embarcacao from '../json/embarcacao.json';
import maquinario from '../json/maquinario.json';
import terreno from '../json/terreno.json';
import caminhao from '../json/caminhao.json';
import moto from '../json/moto.json';
import equipamentoIndustrial from '../json/equipamento-industrial.json';
import joia from '../json/joia.json';
import obraArte from '../json/obra-arte.json';
import estoque from '../json/estoque.json';
import titulo from '../json/titulo.json';

export const dynamicFormSchemaMockInterceptor: HttpInterceptorFn = (req, next) => {
  let path = req.url;
  try {
    const fullUrl = (req as any).urlWithParams ?? req.url;
    const u = new URL(fullUrl, (globalThis as any).location?.origin ?? 'http://localhost');
    path = (u.pathname || '') + (u.search || '');
  } catch {}
  try {
    // no-op
  } catch (e) {
    // no-op
  }
  const lc = path.toLowerCase();
  const dbName = 'collateral-idb';

  const openDb = (): Promise<IDBDatabase> =>
    new Promise((resolve, reject) => {
      const reqOpen = indexedDB.open(dbName);
      reqOpen.onupgradeneeded = () => {
        const db = reqOpen.result;

        if (!db.objectStoreNames.contains('drafts')) {
          const store = db.createObjectStore('drafts', { keyPath: 'id' });
          store.createIndex('userId', 'userId', { unique: false });
          store.createIndex('formId', 'formId', { unique: false });
          store.createIndex('type', 'type', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        if (!db.objectStoreNames.contains('schemas')) {
          const store = db.createObjectStore('schemas', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: true });
        }

        if (!db.objectStoreNames.contains('seed')) {
          db.createObjectStore('seed', { keyPath: 'key' });
        }
      };
      reqOpen.onerror = () => reject(reqOpen.error);
      reqOpen.onsuccess = () => resolve(reqOpen.result);
    });

  const seedIfNeeded = (db: IDBDatabase): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(['seed', 'schemas'], 'readwrite');
        const seedStore = tx.objectStore('seed');
        const schemasStore = tx.objectStore('schemas');
        const getReq = seedStore.get('schemasSeed');
        getReq.onsuccess = () => {
          if (getReq.result) {
            resolve();

            return;
          }

          const map: { id: number; type: string; body: any }[] = [
            { id: 14, type: 'motor-home', body: motorHome },
            { id: 1, type: 'imovel', body: imovel },
            { id: 2, type: 'veiculo', body: veiculo },
            { id: 3, type: 'aeronave', body: aeronave },
            { id: 4, type: 'embarcacao', body: embarcacao },
            { id: 5, type: 'maquinario', body: maquinario },
            { id: 6, type: 'terreno', body: terreno },
            { id: 7, type: 'caminhao', body: caminhao },
            { id: 8, type: 'moto', body: moto },
            { id: 9, type: 'equipamento-industrial', body: equipamentoIndustrial },
            { id: 10, type: 'joia', body: joia },
            { id: 11, type: 'obra-arte', body: obraArte },
            { id: 12, type: 'estoque', body: estoque },
            { id: 13, type: 'titulo', body: titulo },
          ];
          let pending = map.length;

          if (pending === 0) {
            seedStore.put({ key: 'schemasSeed', value: 1 });
            resolve();

            return;
          }

          map.forEach(r => {
            const putReq = schemasStore.put({ id: r.id, type: r.type, schema: r.body });
            putReq.onsuccess = () => {
              pending -= 1;

              if (pending === 0) {
                seedStore.put({ key: 'schemasSeed', value: 1 });
                resolve();
              }
            };
            putReq.onerror = () => reject(putReq.error);
          });
        };
        getReq.onerror = () => reject(getReq.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const findByType = (db: IDBDatabase, type: string): Promise<any | null> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('schemas', 'readonly');
        const idx = tx.objectStore('schemas').index('type');
        const reqIdx = idx.openCursor(IDBKeyRange.only(type));
        reqIdx.onsuccess = () => {
          const cursor = reqIdx.result as IDBCursorWithValue | null;
          resolve(cursor ? (cursor.value as any).schema : null);
        };
        reqIdx.onerror = () => reject(reqIdx.error);
      } catch (e) {
        reject(e as any);
      }
    });


  const findById = (db: IDBDatabase, id: number): Promise<any | null> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('schemas', 'readonly');
        const store = tx.objectStore('schemas');
        const req = store.get(id);
        req.onsuccess = () => {
          const row = req.result as any | undefined;
          resolve(row ? row.schema : null);
        };
        req.onerror = () => reject(req.error);
      } catch (e) {
        reject(e as any);
      }
    });

  if (req.method === 'GET' && req.url.includes('/api/dynamic-form/')) {
    const type = req.url.split('/api/dynamic-form/')[1]?.split('?')[0] ?? '';

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(seedIfNeeded(db)).pipe(switchMap(() => from(findByType(db, type))))),
      map(body =>
        body
          ? new HttpResponse({ status: 200, body })
          : new HttpResponse({
              status: 404,
              body: { statusCode: 404, errors: ['Schema not found'] },
            }),
      ),
      delay(200),
    );
  }


  if (req.method === 'GET' && req.url.includes('/api/dynamic-form-by-id/')) {
    const idStr = req.url.split('/api/dynamic-form-by-id/')[1]?.split('?')[0] ?? '';
    const id = Number(idStr || '0');

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(seedIfNeeded(db)).pipe(switchMap(() => from(findById(db, id))))),
      map(body =>
        body
          ? new HttpResponse({ status: 200, body })
          : new HttpResponse({
              status: 404,
              body: { statusCode: 404, errors: ['Schema not found'] },
            }),
      ),
      delay(200),
    );
  }

  return next(req);
};
