import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';
import rawClients from '../json/collateral-clients.json';

type DocType = 'CPF' | 'CNPJ';
type ClientRow = { clientId: string; fullName: string; documentType: DocType };

const norm = (s: string): string =>
  String(s)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();

const pad = (n: number, size: number): string => n.toString().padStart(size, '0');

function cpfCheckDigits(base: number[]): [number, number] {
  const d1 =
    base.reduce((sum, digit, idx) => sum + digit * (10 - idx), 0) % 11;
  const cd1 = d1 < 2 ? 0 : 11 - d1;
  const d2 =
    [...base, cd1].reduce((sum, digit, idx) => sum + digit * (11 - idx), 0) % 11;
  const cd2 = d2 < 2 ? 0 : 11 - d2;
  return [cd1, cd2];
}

function buildCpfFromSeed(seed: number): string {
  const s = pad(seed % 999999999, 9);
  const base = s.split('').map(x => Number(x));
  const [cd1, cd2] = cpfCheckDigits(base);
  const full = `${s}${cd1}${cd2}`;
  return `${full.substring(0, 3)}.${full.substring(3, 6)}.${full.substring(6, 9)}-${full.substring(9)}`;
}

function cnpjCheckDigits(base: number[]): [number, number] {
  const w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const s1 = base.reduce((sum, d, i) => sum + d * w1[i], 0);
  const cd1 = s1 % 11 < 2 ? 0 : 11 - (s1 % 11);
  const w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const s2 = [...base, cd1].reduce((sum, d, i) => sum + d * w2[i], 0);
  const cd2 = s2 % 11 < 2 ? 0 : 11 - (s2 % 11);
  return [cd1, cd2];
}

function buildCnpjFromSeed(seed: number): string {
  const root = pad(seed % 99999999, 8);
  const branch = '0001';
  const baseDigits = `${root}${branch}`.split('').map(x => Number(x));
  const [cd1, cd2] = cnpjCheckDigits(baseDigits);
  const full = `${root}${branch}${cd1}${cd2}`;
  return `${full.substring(0, 2)}.${full.substring(2, 5)}.${full.substring(5, 8)}/${full.substring(8, 12)}-${full.substring(12)}`;
}

function attachDocuments(list: ClientRow[]): (ClientRow & { document: string })[] {
  return list.map(c => {
    const seed = Number(c.clientId.replace(/\D/g, ''));
    const doc = c.documentType === 'CPF' ? buildCpfFromSeed(seed) : buildCnpjFromSeed(seed);
    return { ...c, document: doc };
  });
}

export const collateralClientsMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/collateral-clients')) {
    let q = '';
    try {
      const u = new URL(req.url, 'http://localhost');
      q = (u.searchParams.get('q') || '').trim();
    } catch {}

    console.log('Mock collateral-clients q:', q);
    const rows = attachDocuments((rawClients as ClientRow[]));
    const filtered = q
      ? rows.filter(r => norm(r.fullName).includes(norm(q)) || norm(r.clientId).includes(norm(q)))
      : rows;

    const limited = filtered.slice(0, 20);

    console.log('Clients Response: ', limited);

    return of(
      new HttpResponse({
        status: 200,
        body: { data: { rows: limited } },
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
