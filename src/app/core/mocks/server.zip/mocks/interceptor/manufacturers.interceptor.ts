import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';

const manufacturers = [
  { id: 'mercedes', label: 'Mercedes-Benz' },
  { id: 'vw', label: 'Volkswagen' },
  { id: 'fiat', label: 'Fiat' },
  { id: 'ford', label: 'Ford' },
  { id: 'iveco', label: 'Iveco' },
  { id: 'renault', label: 'Renault' },
];

export const manufacturersMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/manufacturers')) {
    let q = '';
    try {
      const url = new URL(req.url, 'http://localhost');
      q = (url.searchParams.get('q') || '').toLowerCase();
    } catch {
      // ignore parse errors; fall back to full list
    }

    const body = q ? manufacturers.filter(m => m.label.toLowerCase().includes(q)) : manufacturers;

    return of(
      new HttpResponse({
        status: 200,
        body,
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
