import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';

const citiesByUf: Record<string, { id: string; name: string }[]> = {
  SP: [
    { id: 'sao-paulo', name: 'São Paulo' },
    { id: 'campinas', name: 'Campinas' },
    { id: 'santos', name: 'Santos' },
  ],
  RJ: [
    { id: 'rio-de-janeiro', name: 'Rio de Janeiro' },
    { id: 'niteroi', name: 'Niterói' },
    { id: 'petropolis', name: 'Petrópolis' },
  ],
  MG: [
    { id: 'belo-horizonte', name: 'Belo Horizonte' },
    { id: 'uberlandia', name: 'Uberlândia' },
    { id: 'juiz-de-fora', name: 'Juiz de Fora' },
  ],
  RS: [
    { id: 'porto-alegre', name: 'Porto Alegre' },
    { id: 'caxias-do-sul', name: 'Caxias do Sul' },
    { id: 'pelotas', name: 'Pelotas' },
  ],
};

export const citiesMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/cities')) {
    let uf = '';
    try {
      const url = new URL(req.url, 'http://localhost');
      uf = (url.searchParams.get('uf') || '').toUpperCase();
    } catch {
      // ignore
    }

    const list = citiesByUf[uf] || [];

    return of(
      new HttpResponse({
        status: 200,
        body: list,
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
