import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay, defer, from, switchMap, map } from 'rxjs';

import listData from '../json/dynamic-forms-schemas.json';

interface RowJson {
  id: number;
  type: string;
  name: string;
  version: string;
  status: 'draft' | 'published' | 'deprecated';
  fieldsCount: number;
  createdAt: string | null;
  updatedAt: string | null;
  meta?: Record<string, unknown> | null;
}

export const dynamicFormsListMockInterceptor: HttpInterceptorFn = (req, next) => {
  const dbName = 'collateral-idb';

  const openDb = (): Promise<IDBDatabase> =>
    new Promise((resolve, reject) => {
      const reqOpen = indexedDB.open(dbName);
      reqOpen.onupgradeneeded = () => {
        const db = reqOpen.result;

        if (!db.objectStoreNames.contains('drafts')) {
          const store = db.createObjectStore('drafts', { keyPath: 'id' });
          store.createIndex('userId', 'userId', { unique: false });
          store.createIndex('formId', 'formId', { unique: false });
          store.createIndex('type', 'type', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        if (!db.objectStoreNames.contains('forms')) {
          const store = db.createObjectStore('forms', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: false });
          store.createIndex('name', 'name', { unique: false });
          store.createIndex('version', 'version', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        if (!db.objectStoreNames.contains('schemas')) {
          const store = db.createObjectStore('schemas', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: true });
        }

        if (!db.objectStoreNames.contains('seed')) {
          db.createObjectStore('seed', { keyPath: 'key' });
        }
      };
      reqOpen.onerror = () => reject(reqOpen.error);
      reqOpen.onsuccess = () => resolve(reqOpen.result);
    });

  const seedIfNeeded = (db: IDBDatabase): Promise<void> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(['seed', 'forms'], 'readwrite');
        const seedStore = tx.objectStore('seed');
        const formsStore = tx.objectStore('forms');
        const getReq = seedStore.get('formsSeed');
        getReq.onsuccess = () => {
          if (getReq.result) {
            resolve();

            return;
          }

          const arr = listData as RowJson[];
          let pending = arr.length;

          if (pending === 0) {
            seedStore.put({ key: 'formsSeed', value: 1 });
            resolve();

            return;
          }

          arr.forEach(r => {
            const putReq = formsStore.put(r);
            putReq.onsuccess = () => {
              pending -= 1;

              if (pending === 0) {
                seedStore.put({ key: 'formsSeed', value: 1 });
                resolve();
              }
            };
            putReq.onerror = () => reject(putReq.error);
          });
        };
        getReq.onerror = () => reject(getReq.error);
      } catch (e) {
        reject(e as any);
      }
    });

  const getAllForms = (db: IDBDatabase): Promise<RowJson[]> =>
    new Promise((resolve, reject) => {
      try {
        const tx = db.transaction('forms', 'readonly');
        const store = tx.objectStore('forms');
        const reqAll = store.getAll();
        reqAll.onsuccess = () => resolve((reqAll.result ?? []) as RowJson[]);
        reqAll.onerror = () => reject(reqAll.error);
      } catch (e) {
        reject(e as any);
      }
    });

  if (req.method === 'GET' && req.url.includes('/api/dynamic-forms/schemas')) {
    const fullUrl = (req as any).urlWithParams ?? req.url;
    const url = new URL(fullUrl, 'http://localhost');
    const qp = url.searchParams;
    const name = (qp.get('name') ?? '').trim().toLowerCase();
    const jsonKey = (qp.get('jsonKey') ?? qp.get('jsonkey') ?? '').trim();
    const jsonValue = (qp.get('jsonValue') ?? qp.get('jsonvalue') ?? '').trim().toLowerCase();
    const version = (qp.get('version') ?? '').trim();
    const createdAt = (qp.get('createdAt') ?? qp.get('createdat') ?? '').trim();
    const updatedAt = (qp.get('updatedAt') ?? qp.get('updatedat') ?? '').trim();
    const showDeprecatedParam = (qp.get('showDeprecated') ?? qp.get('showdeprecated') ?? '').trim();
    const showDeprecated = ['1', 'true', 'yes'].includes(showDeprecatedParam.toLowerCase());

    const createdDates = createdAt ? createdAt.split(',').map(x => new Date(x)) : [];
    const updatedDates = updatedAt ? updatedAt.split(',').map(x => new Date(x)) : [];

    const inRange = (d: Date, range: Date[]): boolean => {
      if (!range || range.length === 0) return true;

      const [from, to] = range.length === 1 ? [range[0], range[0]] : [range[0], range[1]];
      const ts = d.getTime();

      return ts >= from.getTime() && ts <= to.getTime();
    };

    const inRangeSafe = (d: Date | null, range: Date[]): boolean => {
      if (!range || range.length === 0) return true;

      if (!d) return false;

      return inRange(d, range);
    };

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(seedIfNeeded(db)).pipe(switchMap(() => from(getAllForms(db))))),
      map(arr =>
        arr
          .filter(r => (name ? r.name.toLowerCase().includes(name) : true))
          .filter(r => (version ? r.version === version : true))
          .filter(r => inRangeSafe(r.createdAt ? new Date(r.createdAt) : null, createdDates))
          .filter(r => inRangeSafe(r.updatedAt ? new Date(r.updatedAt) : null, updatedDates))
          .filter(r => (showDeprecated ? true : r.status !== 'deprecated'))
          .filter(r => {
            if (!jsonKey) return true;

            const val = jsonValue;
            const metaVal = (r.meta ?? {})[jsonKey];

            if (metaVal && (!val || String(metaVal).toLowerCase().includes(val))) return true;

            const topVal = (r as unknown as Record<string, unknown>)[jsonKey];

            if (topVal && (!val || String(topVal).toLowerCase().includes(val))) return true;

            return false;
          })
          .map(r => ({
            id: r.id,
            type: r.type,
            name: r.name,
            version: r.version,
            status: r.status,
            fieldsCount: r.fieldsCount,
            createdAt: r.createdAt,
            updatedAt: r.updatedAt,
          })),
      ),
      map(rows => ({ data: { rows, skip: 0, total: rows.length }, statusCode: 200 }) as const),
      map(body => new HttpResponse({ status: 200, body })),
      delay(250),
    );
  }

  if (req.method === 'POST' && req.url.endsWith('/api/dynamic-forms')) {
    const payload = (req.body ?? {}) as Partial<RowJson>;
    const now = new Date().toISOString();
    const id = Date.now() + Math.floor(Math.random() * 1000);
    const type = (() => {
      const t = (payload.type ?? '').toString().trim();

      return t ? t : `custom-${id}`;
    })();
    const name = (payload.name ?? 'Novo Formulário') as string;
    const version = (payload.version ?? '1') as string;
    const status: RowJson['status'] = 'draft';
    const createdAt = now;
    const updatedAt = now;

    const createBoth = (db: IDBDatabase): Promise<RowJson> =>
      new Promise((resolve, reject) => {
        try {
          const tx = db.transaction(['forms', 'schemas'], 'readwrite');
          const formsStore = tx.objectStore('forms');
          const schemasStore = tx.objectStore('schemas');
          const row: RowJson = {
            id,
            type,
            name,
            version,
            status,
            fieldsCount: 0,
            createdAt,
            updatedAt,
          };
          const schema = { id, type, schema: { type, version, name, fields: [] } } as any;
          const put1 = formsStore.put(row);
          const put2 = schemasStore.put(schema);
          let done = 0;
          const ok = () => {
            done += 1;

            if (done === 2) resolve(row);
          };
          put1.onsuccess = ok;
          put2.onsuccess = ok;
          put1.onerror = () => reject(put1.error);
          put2.onerror = () => reject(put2.error);
        } catch (e) {
          reject(e as any);
        }
      });

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(createBoth(db))),
      map(row => new HttpResponse({ status: 201, body: { statusCode: 201, data: { row } } })),
      delay(150),
    );
  }

  if (req.method === 'DELETE' && req.url.includes('/api/dynamic-forms/')) {
    const tail = req.url.split('/api/dynamic-forms/')[1] ?? '';
    const idNum = Number(tail);
    const byType = isNaN(idNum) ? tail : '';
    const removeById = (db: IDBDatabase, id: number): Promise<void> =>
      new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('forms', 'readwrite');
          const store = tx.objectStore('forms');
          const del = store.delete(id);
          del.onsuccess = () => resolve();
          del.onerror = () => reject(del.error);
        } catch (e) {
          reject(e as any);
        }
      });

    const findIdByType = (db: IDBDatabase, type: string): Promise<number | null> =>
      new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('forms', 'readonly');
          const idx = tx.objectStore('forms').index('type');
          const reqIdx = idx.openCursor(IDBKeyRange.only(type));
          reqIdx.onsuccess = () => {
            const cursor = reqIdx.result as IDBCursorWithValue | null;
            resolve(cursor ? (cursor.value as RowJson).id : null);
          };
          reqIdx.onerror = () => reject(reqIdx.error);
        } catch (e) {
          reject(e as any);
        }
      });

    return defer(() => from(openDb())).pipe(
      switchMap(db =>
        isNaN(idNum)
          ? from(findIdByType(db, byType)).pipe(
              switchMap(found => (found ? from(removeById(db, found)) : of(void 0))),
            )
          : from(removeById(db, idNum)),
      ),
      map(() => new HttpResponse({ status: 204 })),
      delay(150),
    );
  }

  if (
    req.method === 'PATCH' &&
    req.url.includes('/api/dynamic-forms/') &&
    req.url.endsWith('/deprecate')
  ) {
    const tail = req.url.split('/api/dynamic-forms/')[1] ?? '';
    const type = tail.replace('/deprecate', '');

    const updateByType = (db: IDBDatabase, t: string): Promise<void> =>
      new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('forms', 'readwrite');
          const store = tx.objectStore('forms');
          const idx = store.index('type');
          const reqIdx = idx.openCursor(IDBKeyRange.only(t));
          reqIdx.onsuccess = () => {
            const cursor = reqIdx.result as IDBCursorWithValue | null;

            if (!cursor) {
              resolve();

              return;
            }

            const row = cursor.value as any;
            const now = new Date().toISOString();
            const updated = { ...row, status: 'deprecated', updatedAt: now };
            const put = store.put(updated);
            put.onsuccess = () => resolve();
            put.onerror = () => reject(put.error);
          };
          reqIdx.onerror = () => reject(reqIdx.error);
        } catch (e) {
          reject(e as any);
        }
      });

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(updateByType(db, type))),
      map(() => new HttpResponse({ status: 200 })),
      delay(150),
    );
  }

  if (
    req.method === 'PATCH' &&
    req.url.includes('/api/dynamic-forms/') &&
    req.url.endsWith('/restore')
  ) {
    const tail = req.url.split('/api/dynamic-forms/')[1] ?? '';
    const type = tail.replace('/restore', '');

    const updateByType = (db: IDBDatabase, t: string): Promise<void> =>
      new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('forms', 'readwrite');
          const store = tx.objectStore('forms');
          const idx = store.index('type');
          const reqIdx = idx.openCursor(IDBKeyRange.only(t));
          reqIdx.onsuccess = () => {
            const cursor = reqIdx.result as IDBCursorWithValue | null;

            if (!cursor) {
              resolve();

              return;
            }

            const row = cursor.value as any;
            const now = new Date().toISOString();
            const updated = { ...row, status: 'published', updatedAt: now };
            const put = store.put(updated);
            put.onsuccess = () => resolve();
            put.onerror = () => reject(put.error);
          };
          reqIdx.onerror = () => reject(reqIdx.error);
        } catch (e) {
          reject(e as any);
        }
      });

    return defer(() => from(openDb())).pipe(
      switchMap(db => from(updateByType(db, type))),
      map(() => new HttpResponse({ status: 200 })),
      delay(150),
    );
  }

  return next(req);
};
