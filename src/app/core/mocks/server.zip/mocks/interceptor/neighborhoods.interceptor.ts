import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';

const hoodsByCity: Record<string, { nome: string }[]> = {
  'São Paulo': [{ nome: 'Moema' }, { nome: 'Pinheiros' }, { nome: 'Vila Mariana' }],
  Campinas: [{ nome: 'Cambuí' }, { nome: 'Taquaral' }, { nome: 'Barão Geraldo' }],
  Santos: [{ nome: 'Gonzaga' }, { nome: 'Boqueirão' }, { nome: 'Ponta da Praia' }],
  'Rio de Janeiro': [{ nome: 'Copacabana' }, { nome: 'Ipanema' }, { nome: 'Leblon' }],
  Niterói: [{ nome: 'Icaraí' }, { nome: 'Santa Rosa' }, { nome: 'Boa Viagem' }],
  Petrópolis: [{ nome: 'Centro' }, { nome: 'Quitandinha' }, { nome: 'Bingen' }],
  'Belo Horizonte': [{ nome: 'Savassi' }, { nome: 'Lourdes' }, { nome: 'Pampulha' }],
  Uberlândia: [{ nome: 'Centro' }, { nome: 'Santa Mônica' }, { nome: 'Tubar' }],
  'Juiz de Fora': [{ nome: 'Cascatinha' }, { nome: 'São Mateus' }, { nome: 'Santa Catarina' }],
  'Porto Alegre': [{ nome: 'Moinhos de Vento' }, { nome: 'Cidade Baixa' }, { nome: 'Petrópolis' }],
  'Caxias do Sul': [{ nome: 'Centro' }, { nome: 'Madureira' }, { nome: 'Panazzolo' }],
  Pelotas: [{ nome: 'Areal' }, { nome: 'Fragata' }, { nome: 'Três Vendas' }],
};

export const neighborhoodsMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/neighborhoods')) {
    let city = '';
    try {
      const url = new URL(req.url, 'http://localhost');
      city = url.searchParams.get('city') || '';
    } catch {
      // ignore
    }

    const norm = (s: string): string =>
      s
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();

    const key = Object.keys(hoodsByCity).find(k => norm(k) === norm(city)) || city;
    const list = hoodsByCity[key] || [];

    return of(
      new HttpResponse({
        status: 200,
        body: list,
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
