import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { of, delay } from 'rxjs';

const states = [
  { code: 'SP', name: 'São Paulo' },
  { code: 'RJ', name: 'Rio de Janeiro' },
  { code: 'MG', name: 'Minas Gerais' },
  { code: 'RS', name: 'Rio Grande do Sul' },
];

export const statesMockInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/api/states')) {
    return of(
      new HttpResponse({
        status: 200,
        body: states,
      }),
    ).pipe(delay(200));
  }

  return next(req);
};
